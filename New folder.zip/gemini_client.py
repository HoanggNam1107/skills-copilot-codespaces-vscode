# gemini_client.py (Phiên bản Nâng cấp: Tin cậy & Linh hoạt)
# -*- coding: utf-8 -*-
import google.generativeai as genai
import asyncio
from config import GEMINI_API_KEY, GEMINI_MODEL, GENERATION_CONFIG, SAFETY_SETTINGS

# --- NÂNG CẤP: Thêm các hằng số để kiểm soát việc thử lại ---
MAX_RETRIES = 3
RETRY_DELAY_SECONDS = 5

gemini_model = None

def initialize_gemini():
    """Khởi tạo và cấu hình mô hình Gemini từ file config."""
    global gemini_model
    try:
        genai.configure(api_key=GEMINI_API_KEY)
        # NÂNG CẤP: Tải mô hình và cấu hình từ file config
        gemini_model = genai.GenerativeModel(
            model_name=GEMINI_MODEL,
            generation_config=GENERATION_CONFIG,
            safety_settings=SAFETY_SETTINGS
        )
        print(f"🤖 Module Gemini đã sẵn sàng với mô hình '{GEMINI_MODEL}'.")
        return True
    except Exception as e:
        print(f"❌ Lỗi cấu hình Gemini: {e}")
        return False

async def gemini_get_response(prompt: str) -> str:
    """
    Gửi prompt đến Gemini và nhận phản hồi.
    NÂNG CẤP: Tích hợp cơ chế tự động thử lại khi gặp lỗi.
    """
    if gemini_model is None:
        return f'{{"error": "Mô hình Gemini chưa được khởi tạo."}}'
    
    # NÂNG CẤP: Vòng lặp thử lại
    for attempt in range(MAX_RETRIES):
        try:
            # NÂNG CẤP: Thêm thời gian chờ (timeout)
            response = await asyncio.wait_for(
                gemini_model.generate_content_async(prompt),
                timeout=60.0
            )
            return response.text
        except Exception as e:
            print(f"🔥 Lỗi khi giao tiếp với Gemini (Lần {attempt + 1}/{MAX_RETRIES}): {e}")
            if attempt < MAX_RETRIES - 1:
                print(f"⏳ Thử lại sau {RETRY_DELAY_SECONDS} giây...")
                await asyncio.sleep(RETRY_DELAY_SECONDS)
            else:
                print("❌ Đã thử lại nhiều lần nhưng vẫn thất bại. Bỏ qua yêu cầu này.")
                return f'{{"error": "Lỗi nghiêm trọng khi giao tiếp với Gemini sau nhiều lần thử: {e}"}}'

# Khởi tạo ngay khi module được import
initialize_gemini()