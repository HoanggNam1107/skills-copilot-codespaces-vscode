# news_impact_analyzer.py (Phiên bản Nâng cấp Định tính + Actual vs. Previous)
# -*- coding: utf-8 -*-
import news_event_rules as ner # Import file quy tắc

def analyze_surprise(event_data: dict) -> dict:
    """
    Phân tích kết quả sự kiện, kết hợp định lượng (Actual vs Forecast vs Previous)
    và định tính (Ý nghĩa tin) để đưa ra hàm ý cho Vàng (XAUUSD).
    """
    if event_data is None:
         return {"surprise_level": "Lỗi Dữ liệu", "implication": "Không thể lấy kết quả sự kiện.",
                 "details": "N/A", "xau_impact_bias": "NEUTRAL"}

    # Đọc key từ scraper (country, prev)
    actual = event_data.get('actual')
    forecast = event_data.get('forecast')
    currency = event_data.get('country')
    event_name = event_data.get('event')
    previous = event_data.get('prev') # Lấy 'prev'

    details_str = f"Actual: {actual if actual is not None else 'N/A'}, Forecast: {forecast if forecast is not None else 'N/A'}"
    if previous is not None: details_str += f", Previous: {previous}"

    # Cố gắng chuyển đổi sang số
    try: actual_f = float(actual) if actual is not None else None
    except (ValueError, TypeError): actual_f = None
    try: forecast_f = float(forecast) if forecast is not None else None
    except (ValueError, TypeError): forecast_f = None
    # --- NÂNG CẤP: Chuyển đổi 'previous' sang số ---
    try: previous_f = float(previous) if previous is not None else None
    except (ValueError, TypeError): previous_f = None
    # --- Kết thúc nâng cấp ---

    if actual_f is None or forecast_f is None:
        return {"surprise_level": "Thiếu dữ liệu Số", "implication": f"Thiếu Actual/Forecast dạng số cho {event_name}.",
                "details": details_str, "xau_impact_bias": "NEUTRAL"}

    # Lấy quy tắc định tính
    rule = ner.get_qualitative_rule(currency, event_name)
    if rule is None:
        return {"surprise_level": "Không rõ Quy tắc", "implication": f"Không có quy tắc định tính cho {event_name} ({currency}).",
                "details": details_str, "xau_impact_bias": "NEUTRAL"}
    if rule.get("qualitative", False):
         return {"surprise_level": "Định tính (Qualitative)", "implication": f"Tin {event_name} là tin định tính (Statement, Speech).",
                 "details": "N/A", "xau_impact_bias": "NEUTRAL"}

    # --- Phân tích Định lượng (Actual vs Forecast) ---
    surprise_forecast = actual_f - forecast_f
    threshold = max(abs(forecast_f * 0.20), 0.1) if forecast_f != 0 else 0.1 # Ngưỡng 20%
    surprise_type_forecast = "NEUTRAL"; surprise_level_str = "Như dự kiến"
    if surprise_forecast > threshold: surprise_type_forecast = "POSITIVE"; surprise_level_str = "Tốt hơn Dự báo (Lớn)"
    elif surprise_forecast > 0: surprise_type_forecast = "POSITIVE"; surprise_level_str = "Tốt hơn Dự báo (Nhẹ)"
    elif surprise_forecast < -threshold: surprise_type_forecast = "NEGATIVE"; surprise_level_str = "Xấu hơn Dự báo (Lớn)"
    elif surprise_forecast < 0: surprise_type_forecast = "NEGATIVE"; surprise_level_str = "Xấu hơn Dự báo (Nhẹ)"

    # --- NÂNG CẤP: Phân tích Định lượng (Actual vs Previous) ---
    surprise_type_previous = "NEUTRAL"; previous_str = ""
    if previous_f is not None:
        surprise_previous = actual_f - previous_f
        # Dùng ngưỡng tương tự hoặc nhỏ hơn cho previous
        threshold_prev = max(abs(previous_f * 0.10), 0.1) if previous_f != 0 else 0.1 # Ngưỡng 10%
        if surprise_previous > threshold_prev: surprise_type_previous = "POSITIVE"; previous_str = ", Tốt hơn Kỳ trước"
        elif surprise_previous < -threshold_prev: surprise_type_previous = "NEGATIVE"; previous_str = ", Xấu hơn Kỳ trước"
        else: previous_str = ", Tương đương Kỳ trước"
    # --- Kết thúc nâng cấp ---

    # --- Kết hợp Định tính và Định lượng (Actual vs Forecast) ---
    final_implication = f"Tin {event_name} ra {surprise_level_str.lower()}{previous_str}."
    currency_impact = "NEUTRAL" # Tác động lên tiền tệ
    xau_impact_bias = "NEUTRAL" # Tác động lên Vàng

    rule_higher_is = rule.get("higher_is") # Ví dụ: "GOOD_FOR_CURRENCY"
    
    if surprise_type_forecast == "POSITIVE": # Actual > Forecast
        if rule_higher_is == "GOOD_FOR_CURRENCY": currency_impact = "GOOD"
        elif rule_higher_is == "BAD_FOR_CURRENCY": currency_impact = "BAD"
    elif surprise_type_forecast == "NEGATIVE": # Actual < Forecast
        if rule_higher_is == "GOOD_FOR_CURRENCY": currency_impact = "BAD"
        elif rule_higher_is == "BAD_FOR_CURRENCY": currency_impact = "GOOD"

    # --- NÂNG CẤP: Điều chỉnh tác động dựa trên so sánh với Previous ---
    # Nếu Forecast và Previous ngược dấu nhau (ví dụ: Tốt hơn Forecast nhưng Xấu hơn Previous)
    if (surprise_type_forecast == "POSITIVE" and surprise_type_previous == "NEGATIVE") or \
       (surprise_type_forecast == "NEGATIVE" and surprise_type_previous == "POSITIVE"):
        final_implication += " Tác động HỖN LOẠN/TRUNG LẬP."
        currency_impact = "MIXED" # Đánh dấu là hỗn loạn
    
    # Áp dụng tác động cuối cùng
    if currency == "USD": # Chỉ áp dụng cho Vàng nếu tin là USD
        if currency_impact == "GOOD": # Tốt cho USD
            final_implication += f" (TỐT cho {currency}) => Tác động TIÊU CỰC đến XAUUSD."
            xau_impact_bias = "NEGATIVE"
        elif currency_impact == "BAD": # Xấu cho USD
            final_implication += f" (XẤU cho {currency}) => Tác động TÍCH CỰC đến XAUUSD."
            xau_impact_bias = "POSITIVE"
        elif currency_impact == "MIXED":
             xau_impact_bias = "NEUTRAL" # Giữ trung lập nếu tin hỗn loạn
        # (Nếu NEUTRAL thì giữ nguyên)
    else: # Tin không phải USD
         if currency_impact == "GOOD": final_implication += f" (Tốt cho {currency})."
         elif currency_impact == "BAD": final_implication += f" (Xấu cho {currency})."
         # Không đặt XAU bias nếu tin không phải USD (trừ khi bạn thêm logic EURUSD vs XAUUSD...)


    return {
        "surprise_level": surprise_level_str,
        "implication": final_implication,
        "details": details_str,
        "xau_impact_bias": xau_impact_bias
    }