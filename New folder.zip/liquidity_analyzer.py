# liquidity_analyzer.py (Phiên bản Cuối++: Mitigation Levels, OB Wick Refinement)
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
try:
    from scipy.signal import find_peaks
except ImportError:
    print("Cảnh báo: scipy chưa được cài đặt. pip install scipy")
    # Cung cấp hàm find_peaks giả lập nếu thiếu
    def find_peaks(series, **kwargs):
        return np.array([]), {} # Trả về tuple hợp lệ

def analyze_liquidity(
    price_data_h4: pd.DataFrame, # Dữ liệu H4 (chính)
    d1_price_data: pd.DataFrame = None, # Dữ liệu D1 (cho Old H/L)
    volume_ma_h4: float = None, # Volume MA H4 (cho OB Quality)
    lookback: int = 100 # Số nến H4 để phân tích
) -> dict:
    """
    Phân tích hành động giá H4, tích hợp các nâng cấp mới nhất:
    - NÂNG CẤP: Phân biệt mức độ Mitigation OB (Edge, MT).
    - NÂNG CẤP: Tinh chỉnh OB (OB Wick Zone).
    - Đã có: FVG CE Mitigation Status.
    - Đã có: OB Quality (Body Ratio, Volume Confirmation).
    - Đã có: Old Highs/Lows (Previous Day).
    - Đã có: Multiple Equal Highs/Lows.
    - Đã có: Mitigation Status (basic), IDM, Sweep Signal.
    """
    # --- Khởi tạo và Kiểm tra Đầu vào ---
    default_result = {
        "bullish_obs": [], "bearish_obs": [],
        "buy_side_liquidity_eqh": None, "sell_side_liquidity_eql": None,
        "multiple_eqh": [], "multiple_eql": [],
        "structural_buy_liq": [], "structural_sell_liq": [],
        "inducement_buy_side": None, "inducement_sell_side": None,
        "previous_day_high": None, "previous_day_low": None,
        "fvgs": [], "recent_liquidity_event": None, "error": None
    }
    min_bars_needed = 50

    if not isinstance(price_data_h4, pd.DataFrame) or price_data_h4.empty or len(price_data_h4) < min_bars_needed:
        default_result["error"] = f"Không đủ dữ liệu H4 ({len(price_data_h4) if isinstance(price_data_h4, pd.DataFrame) else 0}/{min_bars_needed})"
        return default_result
    required_cols = ['time', 'open', 'high', 'low', 'close', 'tick_volume']
    if not all(col in price_data_h4.columns for col in required_cols):
         default_result["error"] = f"Thiếu cột dữ liệu OHLCV cần thiết trong H4 data: {required_cols}"
         return default_result

    df = price_data_h4.tail(lookback).copy()
    digits = 5 # Mặc định
    try: # Ước tính digits
         price_str = f"{df['close'].iloc[-1]}";
         if '.' in price_str: digits = len(price_str.split('.')[-1])
    except: pass

    # --- Tính toán các giá trị phụ trợ (ATR, Volume MA) ---
    last_atr = 0.0001 # Fallback ATR
    try:
        if 'atr' not in df.columns:
             df['tr'] = pd.DataFrame([ df['high'] - df['low'], abs(df['high'] - df['close'].shift()), abs(df['low'] - df['close'].shift()) ]).max(axis=0)
             df['atr'] = df['tr'].ewm(span=14, adjust=False).mean()
        calculated_atr = df['atr'].iloc[-1]
        if pd.notna(calculated_atr) and calculated_atr > 1e-9: last_atr = calculated_atr
        else: # Fallback nếu ATR vẫn = 0 hoặc NaN
             atr_fallback = (df['high'].iloc[-20:].max() - df['low'].iloc[-20:].min()) * 0.1
             if atr_fallback > 1e-9: last_atr = atr_fallback
    except Exception as e_atr: print(f"⚠️ Lỗi tính ATR H4: {e_atr}")

    if volume_ma_h4 is None:
        try:
            calculated_vol_ma = df['tick_volume'].rolling(window=20, min_periods=10).mean().iloc[-1]
            if pd.notna(calculated_vol_ma) and calculated_vol_ma > 0: volume_ma_h4 = calculated_vol_ma
            else: # Fallback mean
                 vol_tail_mean = df['tick_volume'].tail(20).mean()
                 volume_ma_h4 = vol_tail_mean if pd.notna(vol_tail_mean) and vol_tail_mean > 0 else 1
        except Exception as e_vol_ma: print(f"⚠️ Lỗi tính Volume MA H4: {e_vol_ma}"); volume_ma_h4 = 1

    results = default_result.copy() # Bắt đầu với dict default

    # --- Lấy Previous Day High/Low ---
    if isinstance(d1_price_data, pd.DataFrame) and not d1_price_data.empty and len(d1_price_data) >= 2:
        try:
            prev_day_candle = d1_price_data.iloc[-2] # Nến ngày hôm qua
            # Đảm bảo có cột high/low
            if 'high' in prev_day_candle and 'low' in prev_day_candle:
                results['previous_day_high'] = round(prev_day_candle['high'], digits)
                results['previous_day_low'] = round(prev_day_candle['low'], digits)
        except Exception as e_pdhl: print(f"⚠️ Lỗi lấy PDH/L: {e_pdhl}")


    # --- 1. TÌM THANH KHOẢN CẤU TRÚC & IDM ---
    try:
        prominence_level = max(last_atr * 0.5, df['close'].iloc[-1] * 0.0005)
        high_peaks_idx, _ = find_peaks(df['high'], distance=3, prominence=prominence_level)
        low_peaks_idx, _ = find_peaks(-df['low'], distance=3, prominence=prominence_level)

        if high_peaks_idx.size > 0:
            all_highs = sorted([round(p, digits) for p in df['high'].iloc[high_peaks_idx]], reverse=True)
            results['structural_buy_liq'] = all_highs
            results['inducement_buy_side'] = round(df['high'].iloc[high_peaks_idx[-1]], digits)

        if low_peaks_idx.size > 0:
            all_lows = sorted([round(p, digits) for p in df['low'].iloc[low_peaks_idx]])
            results['structural_sell_liq'] = all_lows
            results['inducement_sell_side'] = round(df['low'].iloc[low_peaks_idx[-1]], digits)
    except Exception as e_struct:
         print(f"⚠️ Lỗi tìm Structural Liq/IDM: {e_struct}")
         results["error"] = "Lỗi tìm Structural Liq/IDM"


    # --- 2. QUÉT NGƯỢC TÌM POI (OBs / FVGs) ---
    for i in range(len(df) - 3, 2, -1):
        # Đảm bảo index hợp lệ
        if i-1 < 0 or i+2 >= len(df): continue
        try:
            prev_candle = df.iloc[i-1]; candle = df.iloc[i]; next_candle = df.iloc[i+1]; next2_candle = df.iloc[i+2]
        except IndexError: continue # Bỏ qua nếu không lấy được nến

        # --- Phân tích OB ---
        ob_score = 5; ob_reasons = []; ob_volume = candle.get('tick_volume', 0) # Lấy volume an toàn
        ob_high = candle['high']; ob_low = candle['low']; ob_open = candle['open']; ob_close = candle['close']
        ob_range = ob_high - ob_low
        ob_body_ratio = abs(ob_close - ob_open) / ob_range if ob_range > 1e-9 else 0
        # NÂNG CẤP: Tính Mean Threshold (50% của toàn bộ range nến OB)
        ob_mean_threshold = round((ob_high + ob_low) / 2, digits)
        # NÂNG CẤP: Tính Wick Zones
        upper_wick = ob_high - max(ob_open, ob_close)
        lower_wick = min(ob_open, ob_close) - ob_low
        ob_wick_zone = None # Mặc định không có wick zone đặc biệt

        # Bearish OB
        if ob_close > ob_open and next_candle['close'] < ob_low:
            ob_type = "bearish"; ob_top = round(ob_high, digits); ob_bottom = round(ob_low, digits)
            if ob_high > prev_candle['high']: ob_score += 2; ob_reasons.append("Sweep High")
            if ob_low > next2_candle['high']: ob_score += 3; ob_reasons.append("Creates FVG")

            # NÂNG CẤP: Xác định Mitigation Level
            status = "unmitigated"; mt_mitigated = False
            for j in range(i + 2, len(df)):
                candle_j = df.iloc[j]
                # Kiểm tra chạm MT (giá low của nến j chạm hoặc vượt qua MT)
                if candle_j['high'] > ob_mean_threshold: mt_mitigated = True
                # Kiểm tra chạm mép (giá high của nến j chạm hoặc vượt qua đáy OB)
                if candle_j['high'] > ob_bottom:
                    # Nếu đã chạm mép, xác định là edge hay mt mitigated
                    status = "mt_mitigated" if mt_mitigated else "edge_mitigated"
                    # Không cần break ngay, tiếp tục check MT cho các nến sau
                # (Có thể thêm check 'fully_violated' nếu close > ob_top)

            # Chỉ giữ trạng thái cuối cùng sau khi quét hết
            if status == "unmitigated": pass # Giữ nguyên unmitigated
            elif mt_mitigated: status = "mt_mitigated" # Ưu tiên MT
            else: status = "edge_mitigated" # Nếu chỉ chạm mép

            # Điều chỉnh điểm theo IDM
            if results['inducement_buy_side'] and ob_bottom > results['inducement_buy_side']: ob_score -= 3; ob_reasons.append("Decisional (Post-IDM)")
            elif results['inducement_buy_side'] and ob_top < results['inducement_buy_side']: ob_score += 3; ob_reasons.append("Extreme (Pre-IDM)")
            # Điều chỉnh điểm theo OB Quality
            if ob_body_ratio > 0.6: ob_score += 1; ob_reasons.append("Good Body")
            elif ob_body_ratio < 0.3: ob_score -= 1; ob_reasons.append("Weak Body (Wick)")
            if ob_volume > volume_ma_h4 * 1.5: ob_score += 1; ob_reasons.append("High Volume Confirm")
            elif ob_volume < volume_ma_h4 * 0.7: ob_score -= 1; ob_reasons.append("Low Volume OB")

            # NÂNG CẤP: Xác định OB Wick Zone nếu wick trên đáng kể
            if upper_wick / ob_range > 0.5: # Ví dụ: bấc trên chiếm > 50%
                ob_wick_zone = {"top": ob_top, "bottom": round(max(ob_open, ob_close), digits)}
                ob_reasons.append("Refined Wick Zone (Upper)")


            results['bearish_obs'].append({"top": ob_top, "bottom": ob_bottom, "score": min(10, max(0, ob_score)),
                                           "reasons": ob_reasons, "status": status,
                                           "mean_threshold": ob_mean_threshold, # <-- NÂNG CẤP
                                           "wick_zone": ob_wick_zone, # <-- NÂNG CẤP
                                           "body_ratio": round(ob_body_ratio, 2), "volume": int(ob_volume)}) # Chuyển Volume về int


        # Bullish OB
        elif ob_close < ob_open and next_candle['close'] > ob_high:
            ob_type = "bullish"; ob_top = round(ob_high, digits); ob_bottom = round(ob_low, digits)
            if ob_low < prev_candle['low']: ob_score += 2; ob_reasons.append("Sweep Low")
            if i>0 and df.iloc[i-1]['high'] < next_candle['low']: ob_score += 3; ob_reasons.append("Creates FVG") # Check lại logic FVG create

            # NÂNG CẤP: Xác định Mitigation Level
            status = "unmitigated"; mt_mitigated = False
            for j in range(i + 2, len(df)):
                candle_j = df.iloc[j]
                # Kiểm tra chạm MT (giá high của nến j chạm hoặc vượt qua MT)
                if candle_j['low'] < ob_mean_threshold: mt_mitigated = True
                # Kiểm tra chạm mép (giá low của nến j chạm hoặc vượt qua đỉnh OB)
                if candle_j['low'] < ob_top:
                    status = "mt_mitigated" if mt_mitigated else "edge_mitigated"
                # (Có thể thêm check 'fully_violated' nếu close < ob_bottom)

            if status == "unmitigated": pass
            elif mt_mitigated: status = "mt_mitigated"
            else: status = "edge_mitigated"


            # Điều chỉnh điểm theo IDM
            if results['inducement_sell_side'] and ob_top < results['inducement_sell_side']: ob_score -= 3; ob_reasons.append("Decisional (Post-IDM)")
            elif results['inducement_sell_side'] and ob_bottom > results['inducement_sell_side']: ob_score += 3; ob_reasons.append("Extreme (Pre-IDM)")
            # Điều chỉnh điểm theo OB Quality
            if ob_body_ratio > 0.6: ob_score += 1; ob_reasons.append("Good Body")
            elif ob_body_ratio < 0.3: ob_score -= 1; ob_reasons.append("Weak Body (Wick)")
            if ob_volume > volume_ma_h4 * 1.5: ob_score += 1; ob_reasons.append("High Volume Confirm")
            elif ob_volume < volume_ma_h4 * 0.7: ob_score -= 1; ob_reasons.append("Low Volume OB")

            # NÂNG CẤP: Xác định OB Wick Zone nếu wick dưới đáng kể
            if lower_wick / ob_range > 0.5: # Ví dụ: bấc dưới chiếm > 50%
                ob_wick_zone = {"top": round(min(ob_open, ob_close), digits), "bottom": ob_bottom}
                ob_reasons.append("Refined Wick Zone (Lower)")

            results['bullish_obs'].append({"top": ob_top, "bottom": ob_bottom, "score": min(10, max(0, ob_score)),
                                           "reasons": ob_reasons, "status": status,
                                           "mean_threshold": ob_mean_threshold, # <-- NÂNG CẤP
                                           "wick_zone": ob_wick_zone, # <-- NÂNG CẤP
                                           "body_ratio": round(ob_body_ratio, 2), "volume": int(ob_volume)})


        # --- Phân tích FVG (Thêm check CE Mitigation) ---
        # Bullish FVG
        if prev_candle['high'] < next_candle['low']:
            fvg_top = round(next_candle['low'], digits); fvg_bottom = round(prev_candle['high'], digits)
            fvg_size = fvg_top - fvg_bottom; ce = round(fvg_bottom + fvg_size / 2, digits)
            status = "Unfilled"; ce_mitigated = False
            for j in range(i + 2, len(df)):
                candle_j = df.iloc[j]
                if candle_j['low'] <= ce: ce_mitigated = True # Đã chạm HOẶC vượt qua CE
                if candle_j['low'] < fvg_top: status = "Partially Filled"
                if candle_j['low'] < fvg_bottom: status = "Fully Filled"; break
            # Chỉ ghi nhận CE mitigated nếu FVG chưa bị lấp đầy hoàn toàn
            ce_mitigated_final = ce_mitigated if status != "Fully Filled" else False
            results['fvgs'].append({"type": "bullish", "top": fvg_top, "bottom": fvg_bottom,
                                    "consequent_encroachment": ce, "status": status,
                                    "ce_mitigated": ce_mitigated_final, # <-- NÂNG CẤP
                                    "size_vs_atr": round(fvg_size / last_atr, 2) if last_atr > 0 else 0})

        # Bearish FVG
        elif prev_candle['low'] > next_candle['high']:
            fvg_top = round(prev_candle['low'], digits); fvg_bottom = round(next_candle['high'], digits)
            fvg_size = fvg_top - fvg_bottom; ce = round(fvg_bottom + fvg_size / 2, digits)
            status = "Unfilled"; ce_mitigated = False
            for j in range(i + 2, len(df)):
                candle_j = df.iloc[j]
                if candle_j['high'] >= ce: ce_mitigated = True # Đã chạm HOẶC vượt qua CE
                if candle_j['high'] > fvg_bottom: status = "Partially Filled"
                if candle_j['high'] > fvg_top: status = "Fully Filled"; break
            ce_mitigated_final = ce_mitigated if status != "Fully Filled" else False
            results['fvgs'].append({"type": "bearish", "top": fvg_top, "bottom": fvg_bottom,
                                    "consequent_encroachment": ce, "status": status,
                                    "ce_mitigated": ce_mitigated_final, # <-- NÂNG CẤP
                                    "size_vs_atr": round(fvg_size / last_atr, 2) if last_atr > 0 else 0})

    # --- 3. TÌM BỂ THANH KHOẢN (EQUAL & MULTIPLE HIGHS/LOWS) ---
    try:
        num_swings_to_check = 15 # Tăng số lượng swing để check multi
        recent_all_swings = df.tail(lookback // 2)
        if last_atr > 0:
             prom_eq = max(last_atr * 0.3, df['close'].iloc[-1] * 0.0003) # Prominence nhỏ hơn
             # Tăng distance để tránh các đỉnh/đáy quá gần nhau
             high_peaks_idx_eq, _ = find_peaks(recent_all_swings['high'], distance=3, prominence=prom_eq)
             low_peaks_idx_eq, _ = find_peaks(-recent_all_swings['low'], distance=3, prominence=prom_eq)

             # Kiểm tra Multiple EQH/L (>=3 đỉnh/đáy gần bằng nhau)
             multi_eq_tolerance = last_atr * 0.1 # Ngưỡng bằng nhau (10% ATR)
             if high_peaks_idx_eq.size >= 3:
                  high_prices = recent_all_swings['high'].iloc[high_peaks_idx_eq].tolist()
                  # Tìm các cụm giá gần bằng nhau
                  clusters = []
                  high_prices.sort()
                  current_cluster = [high_prices[0]]
                  for k in range(1, len(high_prices)):
                      if high_prices[k] - current_cluster[-1] <= multi_eq_tolerance:
                          current_cluster.append(high_prices[k])
                      else:
                          if len(current_cluster) >= 3: clusters.append(round(np.mean(current_cluster), digits))
                          current_cluster = [high_prices[k]]
                  if len(current_cluster) >= 3: clusters.append(round(np.mean(current_cluster), digits))
                  results['multiple_eqh'] = sorted(list(set(clusters)), reverse=True) # Lưu các mức giá trung bình của cụm >= 3

             if low_peaks_idx_eq.size >= 3:
                  low_prices = recent_all_swings['low'].iloc[low_peaks_idx_eq].tolist()
                  clusters = []
                  low_prices.sort()
                  current_cluster = [low_prices[0]]
                  for k in range(1, len(low_prices)):
                       if low_prices[k] - current_cluster[-1] <= multi_eq_tolerance:
                           current_cluster.append(low_prices[k])
                       else:
                           if len(current_cluster) >= 3: clusters.append(round(np.mean(current_cluster), digits))
                           current_cluster = [low_prices[k]]
                  if len(current_cluster) >= 3: clusters.append(round(np.mean(current_cluster), digits))
                  results['multiple_eql'] = sorted(list(set(clusters)))

             # Kiểm tra EQH/L (>=2 đỉnh/đáy) - Logic cũ đơn giản hơn
             if high_peaks_idx_eq.size >= 2:
                  swing_highs_eq_counts = recent_all_swings['high'].iloc[high_peaks_idx_eq].round(digits).value_counts()
                  eqh_levels = swing_highs_eq_counts[swing_highs_eq_counts >= 2].index.tolist()
                  if eqh_levels: results['buy_side_liquidity_eqh'] = max(eqh_levels)

             if low_peaks_idx_eq.size >= 2:
                  swing_lows_eq_counts = recent_all_swings['low'].iloc[low_peaks_idx_eq].round(digits).value_counts()
                  eql_levels = swing_lows_eq_counts[swing_lows_eq_counts >= 2].index.tolist()
                  if eql_levels: results['sell_side_liquidity_eql'] = min(eql_levels)
    except Exception as e_eqhl: print(f"⚠️ Lỗi tìm EQH/L: {e_eqhl}")

    # --- 4. KIỂM TRA TÍN HIỆU SWEEP/GRAB GẦN NHẤT ---
    try:
        if len(df) >= 3:
            last_closed_candle = df.iloc[-2]
            prev_candle_sweep = df.iloc[-3]
            # Bearish Sweep
            if last_closed_candle['high'] > prev_candle_sweep['high'] and last_closed_candle['close'] < prev_candle_sweep['high']:
                results['recent_liquidity_event'] = {"type": "Bearish Sweep (Buy-side Grab)", "price": round(prev_candle_sweep['high'], digits), "implication": "Tín hiệu Đảo chiều Giảm (Reversal) rất mạnh."}
            # Bullish Sweep
            elif last_closed_candle['low'] < prev_candle_sweep['low'] and last_closed_candle['close'] > prev_candle_sweep['low']:
                results['recent_liquidity_event'] = {"type": "Bullish Sweep (Sell-side Grab)", "price": round(prev_candle_sweep['low'], digits), "implication": "Tín hiệu Đảo chiều Tăng (Reversal) rất mạnh."}
    except Exception as e_sweep: print(f"⚠️ Lỗi kiểm tra Sweep: {e_sweep}")

    # Sắp xếp OBs theo điểm số giảm dần
    try:
        results['bullish_obs'].sort(key=lambda x: x.get('score', 0), reverse=True)
        results['bearish_obs'].sort(key=lambda x: x.get('score', 0), reverse=True)
        # Sắp xếp FVG: unmitigated/unfilled lên đầu, sau đó theo giá gần nhất
        results['fvgs'].sort(key=lambda x: (x.get('status') == 'Fully Filled', x.get('status') == 'Partially Filled', x.get('status') == 'Unfilled',
                                           min(abs(df['close'].iloc[-1] - x.get('top', np.inf)), abs(df['close'].iloc[-1] - x.get('bottom', -np.inf)))))
    except Exception as e_sort: print(f"⚠️ Lỗi sắp xếp POI: {e_sort}")


    return results