# session_analyzer.py
# -*- coding: utf-8 -*-
from datetime import datetime, time
import pytz # Cần cài đặt: pip install pytz
import pandas as pd
import MetaTrader5 as mt5
from data_handler import mt5_get_rates
import asyncio

# --- Định nghĩa Giờ Phiên Giao Dịch (Theo giờ UTC) ---
# (Cần kiểm tra lại giờ mùa hè/đông nếu muốn chính xác tuyệt đối)
ASIA_START_UTC = time(22, 0) # Khoảng 10 PM UTC Chủ Nhật / 5 AM Thứ Hai giờ VN
ASIA_END_UTC = time(7, 0)    # Khoảng 7 AM UTC / 2 PM giờ VN
LONDON_START_UTC = time(7, 0) # Khoảng 7 AM UTC / 2 PM giờ VN
LONDON_END_UTC = time(16, 0)  # Khoảng 4 PM UTC / 11 PM giờ VN
NY_START_UTC = time(12, 0)   # Khoảng 12 PM UTC / 7 PM giờ VN (Bắt đầu giao thoa)
NY_END_UTC = time(21, 0)     # Khoảng 9 PM UTC / 4 AM sáng hôm sau giờ VN

async def get_session_info(symbol: str, timeframe=mt5.TIMEFRAME_H1) -> dict:
    """
    Xác định phiên giao dịch hiện tại và lấy các mức cao/thấp quan trọng
    của phiên Á (Asia Range) gần nhất.
    """
    try:
        utc_tz = pytz.utc
        now_utc = datetime.now(utc_tz)
        current_time_utc = now_utc.time()
        current_weekday = now_utc.weekday() # Thứ Hai = 0, Chủ Nhật = 6

        session = "CLOSED" # Mặc định là đóng cửa (cuối tuần)
        if current_weekday < 5 or (current_weekday == 6 and current_time_utc < ASIA_START_UTC) or (current_weekday == 5 and current_time_utc < NY_END_UTC): # Chỉ chạy trong tuần
            # Xác định phiên hiện tại
            if LONDON_START_UTC <= current_time_utc < NY_START_UTC:
                session = "London"
            elif NY_START_UTC <= current_time_utc < NY_END_UTC:
                session = "London/NY Overlap" if current_time_utc < LONDON_END_UTC else "New York"
            elif ASIA_START_UTC <= current_time_utc or current_time_utc < ASIA_END_UTC: # Bao gồm cả qua đêm UTC
                 session = "Asia"
            elif ASIA_END_UTC <= current_time_utc < LONDON_START_UTC: # Khoảng nghỉ giữa Á và Âu
                 session = "Asia Close / London Open"
            else:
                 session = "NY Close / Asia Open" # Khoảng nghỉ cuối ngày

        # --- Lấy Asia Range (Đỉnh/Đáy Phiên Á) ---
        asia_high = None
        asia_low = None
        # Chỉ tìm khi đang trong hoặc sau phiên Á
        if session != "CLOSED" and (session != "Asia" or current_time_utc >= time(0, 0)): # Đảm bảo đã qua nửa đêm UTC
            # Lấy dữ liệu H1 của 24h qua để bao phủ phiên Á
            df_h1 = await mt5_get_rates(symbol, timeframe, count=24)
            if not df_h1.empty:
                df_h1['utc_time'] = df_h1['time'].dt.tz_localize('UTC')
                df_h1['hour_utc'] = df_h1['utc_time'].dt.hour

                # Xác định nến thuộc phiên Á hôm nay hoặc hôm qua gần nhất
                # Tìm ngày giao dịch hiện tại (hoặc ngày thứ 6 nếu đang là cuối tuần)
                today_trading_day = now_utc.date()
                if current_weekday == 5 and current_time_utc >= NY_END_UTC: # Thứ 6 sau khi đóng cửa NY
                    today_trading_day = now_utc.date()
                elif current_weekday == 6 or (current_weekday == 0 and current_time_utc < ASIA_START_UTC): # Thứ 7, CN, hoặc sáng sớm T2
                     today_trading_day = now_utc.date() - pd.Timedelta(days=current_weekday-4) # Lùi về thứ 6

                # Lọc nến trong khoảng giờ phiên Á của ngày giao dịch đó
                asia_candles = df_h1[
                    (df_h1['utc_time'].dt.date == today_trading_day) &
                    ( (df_h1['hour_utc'] >= ASIA_START_UTC.hour) | (df_h1['hour_utc'] < ASIA_END_UTC.hour) )
                ]
                # Nếu không có nến Á hôm nay (ví dụ đang sáng sớm), lấy ngày hôm trước
                if asia_candles.empty and today_trading_day > df_h1['utc_time'].dt.date.min():
                     prev_trading_day = today_trading_day - pd.Timedelta(days=1)
                     # Điều chỉnh nếu hôm trước là cuối tuần
                     while prev_trading_day.weekday() >= 5: prev_trading_day -= pd.Timedelta(days=1)
                     asia_candles = df_h1[
                        (df_h1['utc_time'].dt.date == prev_trading_day) &
                        ( (df_h1['hour_utc'] >= ASIA_START_UTC.hour) | (df_h1['hour_utc'] < ASIA_END_UTC.hour) )
                     ]


                if not asia_candles.empty:
                    asia_high = round(asia_candles['high'].max(), 3) # Làm tròn cho Vàng
                    asia_low = round(asia_candles['low'].min(), 3)

        return {
            "current_session": session,
            "current_time_utc": now_utc.strftime("%H:%M:%S UTC"),
            "asia_range_high": asia_high,
            "asia_range_low": asia_low
        }
    except Exception as e:
        print(f"❌ Lỗi xác định phiên giao dịch: {e}")
        return {"current_session": "ERROR", "current_time_utc": "", "asia_range_high": None, "asia_range_low": None}