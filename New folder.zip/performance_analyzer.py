# performance_analyzer.py
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import database as db

INITIAL_CAPITAL = 10000 # Giả định vốn ban đầu, bạn có thể thay đổi

def analyze_performance() -> dict:
    """
    Phân tích lịch sử giao dịch để tính toán các chỉ số hiệu suất
    và tạo biểu đồ equity curve.
    """
    trades = db.get_all_closed_trades()
    if not trades or len(trades) < 2:
        return {"error": "Không có đủ dữ liệu giao dịch đã đóng để phân tích."}

    df = pd.DataFrame(trades)
    
    # --- Tính toán các chỉ số cơ bản ---
    num_trades = len(df)
    net_profit = df['profit'].sum()
    gross_profit = df[df['profit'] > 0]['profit'].sum()
    gross_loss = abs(df[df['profit'] < 0]['profit'].sum())
    
    winning_trades = df[df['profit'] > 0]
    losing_trades = df[df['profit'] < 0]
    
    win_rate = (len(winning_trades) / num_trades) * 100 if num_trades > 0 else 0
    avg_win = winning_trades['profit'].mean() if len(winning_trades) > 0 else 0
    avg_loss = abs(losing_trades['profit'].mean()) if len(losing_trades) > 0 else 0
    
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
    
    # --- Tính toán Equity Curve và Max Drawdown ---
    df['equity'] = INITIAL_CAPITAL + df['profit'].cumsum()
    df['peak'] = df['equity'].cummax()
    df['drawdown'] = (df['equity'] - df['peak']) / df['peak']
    max_drawdown = abs(df['drawdown'].min()) * 100
    
    # --- Tính Sharpe Ratio (phiên bản đơn giản) ---
    returns = df['profit'] / INITIAL_CAPITAL # Tỷ suất lợi nhuận mỗi giao dịch
    sharpe_ratio = returns.mean() / returns.std() * np.sqrt(252) if returns.std() > 0 else 0 # Giả định 252 ngày giao dịch/năm

    # --- Vẽ Biểu đồ Equity Curve ---
    plt.style.use('dark_background')
    fig, ax = plt.subplots(figsize=(12, 7))
    df['close_time'] = pd.to_datetime(df['close_time'])
    ax.plot(df['close_time'], df['equity'], label='Equity Curve', color='cyan')
    
    ax.set_title('Biểu đồ Đường cong Vốn (Equity Curve)', fontsize=16)
    ax.set_xlabel('Thời gian')
    ax.set_ylabel('Vốn ($)')
    ax.grid(True, linestyle='--', alpha=0.3)
    ax.legend()
    fig.autofmt_xdate() # Tự động xoay ngày cho đẹp
    
    image_path = "equity_curve.png"
    plt.savefig(image_path, bbox_inches='tight', dpi=100)
    plt.close(fig)

    return {
        "num_trades": num_trades,
        "net_profit": round(net_profit, 2),
        "win_rate": round(win_rate, 2),
        "profit_factor": round(profit_factor, 2),
        "avg_win": round(avg_win, 2),
        "avg_loss": round(avg_loss, 2),
        "max_drawdown": round(max_drawdown, 2),
        "sharpe_ratio": round(sharpe_ratio, 2),
        "image_path": image_path
    }