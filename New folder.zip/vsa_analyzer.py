# vsa_analyzer.py (Phiên bản Cuối: Context, Effort, Relative, Sequence, Background, Climax)
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np

def analyze_vsa_with_context(
    price_data: pd.DataFrame,
    trend_status: str = "ĐI NGANG", # Nhận từ technical_analyzer
    key_support: float = 0.0,    # Nhận từ technical_analyzer
    key_resistance: float = 0.0, # Nhận từ technical_analyzer
    background_lookback: int = 10 # <-- NÂNG CẤP: Số nến để phân tích bối cảnh
) -> dict:
    """
    Phân tích VSA kết hợp Ngữ cảnh, Nỗ lực vs. Kết quả, Tương quan Nỗ lực,
    Sequence, Bối cảnh (Background), và Hành động Cao trào (Climax).
    """
    required_bars = max(21, background_lookback + 3) # Cần đủ nến cho MA và background
    # Kiểm tra đầu vào
    if not isinstance(price_data, pd.DataFrame) or price_data.empty:
        return {"signal": "Lỗi: Dữ liệu đầu vào không hợp lệ", "implication": "", "confidence": "Low", "background": "UNKNOWN"}
    if 'tick_volume' not in price_data.columns or 'high' not in price_data.columns or \
       'low' not in price_data.columns or 'close' not in price_data.columns or 'open' not in price_data.columns:
        return {"signal": "Lỗi: Thiếu cột dữ liệu OHLCV", "implication": "", "confidence": "Low", "background": "UNKNOWN"}
    if len(price_data) < required_bars:
        return {"signal": f"Không đủ dữ liệu VSA ({len(price_data)}/{required_bars})", "implication": "", "confidence": "Low", "background": "UNKNOWN"}

    # Tính toán MA trên toàn bộ dữ liệu gốc để tránh lỗi lookahead
    try:
        # Sử dụng rolling với min_periods để xử lý đoạn đầu
        volume_ma20 = price_data['tick_volume'].rolling(window=20, min_periods=10).mean().iloc[-1]
        # Tính spread an toàn hơn
        price_data_copy = price_data.copy() # Tạo bản sao để tính spread
        price_data_copy['spread'] = price_data_copy['high'] - price_data_copy['low']
        spread_ma20 = price_data_copy['spread'].rolling(window=20, min_periods=10).mean().iloc[-1]

        # Xử lý NaN/Zero nếu MA chưa đủ dữ liệu hoặc giá trị không hợp lệ
        if not pd.notna(volume_ma20) or volume_ma20 <= 0:
            vol_tail_mean = price_data['tick_volume'].tail(20).mean()
            volume_ma20 = vol_tail_mean if pd.notna(vol_tail_mean) and vol_tail_mean > 0 else 1 # Fallback cuối
        if not pd.notna(spread_ma20) or spread_ma20 <= 0:
            spread_tail_mean = price_data_copy['spread'].tail(20).mean()
            spread_ma20 = spread_tail_mean if pd.notna(spread_tail_mean) and spread_tail_mean > 0 else 1e-5 # Fallback cuối

    except Exception as e_ma:
         print(f"⚠️ Lỗi tính MA VSA: {e_ma}")
         volume_ma20 = 1; spread_ma20 = 1e-5 # Fallback an toàn

    # Lấy các nến cần thiết (lấy nhiều hơn một chút để đảm bảo index)
    df_recent = price_data.copy().tail(background_lookback + 5) # Lấy dư vài nến
    df_recent['volume_ma20'] = volume_ma20 # Gán MA đã tính
    df_recent['spread_ma20'] = spread_ma20
    # Tính lại spread trên df_recent nếu chưa có hoặc để đảm bảo
    df_recent['spread'] = df_recent['high'] - df_recent['low']

    # Đảm bảo có đủ nến sau khi tail
    if len(df_recent) < 3: return {"signal": "Không đủ nến gần đây (<3)", "implication": "", "confidence": "Low", "background": "UNKNOWN"}

    # Xác định index an toàn
    last_idx = -1
    prev1_idx = -2
    prev2_idx = -3 # Cần cho background loop

    # Lấy nến bằng iloc
    try:
        last = df_recent.iloc[last_idx]
        prev1 = df_recent.iloc[prev1_idx]
        # prev2 = df_recent.iloc[prev2_idx] # Không cần ngay lập tức
    except IndexError:
         return {"signal": "Lỗi Index khi lấy nến cuối", "implication": "", "confidence": "Low", "background": "UNKNOWN"}


    # --- Phân tích Bối cảnh VSA (Background Analysis) ---
    background_strength_score = 0
    # Lấy N nến *trước* 2 nến cuối cùng làm background
    background_end_idx = prev1_idx # Kết thúc ở nến trước nến `last`
    background_start_idx = max(0, len(df_recent) - background_lookback - 2) # Bắt đầu đủ N nến trước đó
    df_background = df_recent.iloc[background_start_idx:background_end_idx]

    # Kiểm tra lại df_background
    if not df_background.empty and len(df_background) > 1:
        for i in range(1, len(df_background)): # Bỏ qua nến đầu tiên của background
            bg_candle = df_background.iloc[i]
            bg_prev = df_background.iloc[i-1]
            # Tính toán an toàn hơn
            bg_spread = bg_candle.get('spread', 0)
            bg_vol = bg_candle.get('tick_volume', 0)
            bg_is_up = bg_candle['close'] > bg_candle['open']
            bg_is_down = bg_candle['close'] < bg_candle['open']
            bg_vol_high = bg_vol > volume_ma20 * 1.5
            bg_vol_low = bg_vol < volume_ma20 * 0.7
            bg_spread_narrow = bg_spread < spread_ma20 * 0.7
            bg_close_pos = (bg_candle['close'] - bg_candle['low']) / (bg_spread + 1e-9) if bg_spread > 0 else 0.5

            # Tín hiệu Strength trong Background
            if bg_is_down and bg_spread_narrow and bg_vol_low: background_strength_score += 1 # No Supply
            if bg_is_down and bg_vol_high and bg_close_pos > 0.6: background_strength_score += 1 # Stopping Vol

            # Tín hiệu Weakness trong Background
            if bg_is_up and bg_spread_narrow and bg_vol_low: background_strength_score -= 1 # No Demand
            if bg_is_up and bg_vol_high and bg_close_pos < 0.4: background_strength_score -= 1 # Upthrust
    else:
        print("⚠️ [VSA BG] Không đủ nến background.")


    background_status = "MIXED_BG" # Mặc định
    if background_strength_score >= 2: background_status = "STRONG_BUY_BG"
    elif background_strength_score > 0: background_status = "WEAK_BUY_BG"
    elif background_strength_score <= -2: background_status = "STRONG_SELL_BG"
    elif background_strength_score < 0: background_status = "WEAK_SELL_BG"
    # --- Kết thúc Background Analysis ---

    # --- Phân tích Nến Cuối (last) ---
    last_vol = last.get('tick_volume', 0)
    last_spread = last.get('spread', 0)
    is_up_bar = last['close'] > last['open']
    is_down_bar = last['close'] < last['open']
    volume_is_ultra_high = last_vol > volume_ma20 * 3.0 # Ngưỡng cho Climax
    volume_is_very_high = last_vol > volume_ma20 * 2.0
    volume_is_high = last_vol > volume_ma20 * 1.5
    volume_is_low = last_vol < volume_ma20 * 0.7
    spread_is_very_wide = last_spread > spread_ma20 * 1.8 # Ngưỡng cho Climax
    spread_is_wide = last_spread > spread_ma20 * 1.2
    spread_is_narrow = last_spread < spread_ma20 * 0.7
    close_pos = (last['close'] - last['low']) / (last_spread + 1e-9) if last_spread > 0 else 0.5 # Vị trí đóng cửa (0-1)

    signal = "Không có tín hiệu VSA rõ ràng"
    implication = f"Thị trường cân bằng. Bối cảnh: {background_status}"
    confidence = "Low"

    # --- Nhận diện Hành động Cao trào (Climactic Action) ---
    is_buying_climax = False
    if trend_status == "TĂNG" and is_up_bar and spread_is_very_wide and volume_is_ultra_high and close_pos < 0.5:
         signal = "BUYING CLIMAX (Potential)"
         implication = "Dấu hiệu Kiệt sức Mua Rõ ràng. Có thể sắp đảo chiều hoặc đi ngang."
         confidence = "High"
         is_buying_climax = True

    is_selling_climax = False
    if trend_status == "GIẢM" and is_down_bar and spread_is_very_wide and volume_is_ultra_high and close_pos > 0.5:
         signal = "SELLING CLIMAX (Potential)"
         implication = "Dấu hiệu Kiệt sức Bán Rõ ràng. Có thể sắp đảo chiều hoặc đi ngang."
         confidence = "High"
         is_selling_climax = True

    # --- Kiểm tra các tín hiệu VSA khác (nếu không phải Climax) ---
    if not is_buying_climax and not is_selling_climax:
        # Upthrust
        if is_up_bar and spread_is_wide and volume_is_very_high and close_pos < 0.3:
            signal = "UPTHRUST"; implication = "Dấu hiệu Yếu. Áp lực Bán mạnh cuối nến tăng."; confidence = "Medium"
            # Tăng độ tin cậy nếu khớp ngữ cảnh
            if trend_status == "GIẢM" or (key_resistance > 0 and abs(last['high'] - key_resistance) / (key_resistance+1e-9) < 0.005): confidence = "High"; implication += " tại Kháng cự/Xu hướng Giảm."
        # No Demand
        elif is_up_bar and spread_is_narrow and volume_is_low:
            signal = "NO DEMAND"; implication = "Dấu hiệu Yếu. Nỗ lực đẩy giá lên thất bại."; confidence = "Medium"
            if trend_status == "GIẢM" or (key_resistance > 0 and abs(last['close'] - key_resistance) / (key_resistance+1e-9) < 0.005): confidence = "High"; implication += " gần Kháng cự/Xu hướng Giảm."
        # Effort to Rise Fails
        elif is_up_bar and volume_is_high and (spread_is_narrow or last['close'] <= prev1['close']):
             signal = "EFFORT TO RISE FAILED"; implication = "Dấu hiệu Yếu. Vol Mua cao nhưng giá không tăng/bị đẩy xuống."; confidence = "Medium"
             if trend_status == "GIẢM" or (key_resistance > 0 and abs(last['high'] - key_resistance) / (key_resistance+1e-9) < 0.005): confidence = "High"
        # Stopping Volume
        elif is_down_bar and spread_is_wide and volume_is_very_high and close_pos > 0.7:
            signal = "STOPPING VOLUME"; implication = "Dấu hiệu Mạnh. Áp lực Mua hấp thụ lực Bán."; confidence = "Medium"
            if trend_status == "TĂNG" or (key_support > 0 and abs(last['low'] - key_support) / (key_support+1e-9) < 0.005): confidence = "High"; implication += " tại Hỗ trợ/Xu hướng Tăng."
        # No Supply / Test
        elif is_down_bar and spread_is_narrow and volume_is_low:
            signal = "NO SUPPLY / TEST"; implication = "Dấu hiệu Mạnh. Nỗ lực đẩy giá xuống thất bại, phe Bán cạn kiệt."; confidence = "Medium"
            if trend_status == "TĂNG" or (key_support > 0 and abs(last['close'] - key_support) / (key_support+1e-9) < 0.005): confidence = "High"; implication += " gần Hỗ trợ/Xu hướng Tăng."
        # Effort to Fall Fails / Absorption
        elif is_down_bar and volume_is_high and (spread_is_narrow or last['close'] >= prev1['close']):
             signal = "EFFORT TO FALL FAILED / ABSORPTION"; implication = "Dấu hiệu Mạnh. Vol Bán cao nhưng giá không giảm/bị đẩy lên."; confidence = "Medium"
             if trend_status == "TĂNG" or (key_support > 0 and abs(last['low'] - key_support) / (key_support+1e-9) < 0.005): confidence = "High"

    # --- Phân tích Tương quan Nỗ lực (Relative Effort) ---
    relative_effort_implication = ""
    # Đảm bảo prev1 có đủ dữ liệu
    if isinstance(prev1, pd.Series):
        volume_change = last_vol - prev1.get('tick_volume', 0)
        spread_change = last_spread - prev1.get('spread', 0)
        price_movement = last['close'] - last['open']
        prev_price_movement = prev1['close'] - prev1['open']
        if is_up_bar and volume_change > 0 and (spread_change < 0 or price_movement < prev_price_movement * 0.5): relative_effort_implication = " (Nỗ lực tăng kém hiệu quả so với nến trước)."
        elif is_down_bar and volume_change > 0 and (spread_change < 0 or abs(price_movement) < abs(prev_price_movement) * 0.5): relative_effort_implication = " (Nỗ lực giảm kém hiệu quả so với nến trước)."
        elif is_up_bar and volume_change < 0 and (spread_change > 0 or price_movement > prev_price_movement * 1.5): relative_effort_implication = " (Phe Mua kiểm soát dễ dàng)."
        elif is_down_bar and volume_change < 0 and (spread_change > 0 or abs(price_movement) > abs(prev_price_movement) * 1.5): relative_effort_implication = " (Phe Bán kiểm soát dễ dàng)."
        # Thêm vào diễn giải và điều chỉnh confidence
        if relative_effort_implication:
            implication += relative_effort_implication
            if confidence == "High" and ("kém hiệu quả" in relative_effort_implication): confidence = "Medium"
            elif confidence == "Medium" and ("kiểm soát dễ dàng" in relative_effort_implication): confidence = "High"

    # --- Sequence Analysis (Test Confirmation) ---
    # Kiểm tra lại prev1 là Series hợp lệ
    if isinstance(prev1, pd.Series):
        prev1_is_down = prev1['close'] < prev1['open']
        prev1_spread_narrow = prev1.get('spread', 0) < spread_ma20 * 0.7
        prev1_volume_low = prev1.get('tick_volume', 0) < volume_ma20 * 0.7
        last_is_strong_up = is_up_bar and close_pos > 0.6 and not spread_is_narrow

        if prev1_is_down and prev1_spread_narrow and prev1_volume_low and last_is_strong_up:
            signal = "TEST CONFIRMED"; implication = "Dấu hiệu Mạnh Rõ Ràng. 'No Supply' nến trước được xác nhận bởi lực Mua mạnh nến này."; confidence = "High"
            if trend_status == "TĂNG" or (key_support > 0 and abs(prev1['low'] - key_support) / (key_support+1e-9) < 0.005): implication += " gần Hỗ trợ/Xu hướng Tăng."

    # (Có thể thêm Upthrust Confirmation tương tự)

    # Kết hợp diễn giải cuối cùng với Background
    final_implication = implication
    # Chỉ thêm background nếu tín hiệu chính không rõ ràng hoặc để bổ sung ngữ cảnh
    if signal == "Không có tín hiệu VSA rõ ràng" and background_status != "MIXED_BG":
        final_implication = f"Không có tín hiệu tức thời. Bối cảnh gần đây: {background_status.replace('_BG','')}"
    elif signal != "Không có tín hiệu VSA rõ ràng" and background_status != "MIXED_BG":
         final_implication += f" Bối cảnh: {background_status.replace('_BG','')}" # Thêm vào cuối

    # Trả về kết quả cuối cùng
    return {"signal": signal, "implication": final_implication, "confidence": confidence, "background": background_status}