﻿# -*- coding: utf-8 -*-

# --- CONFIGURATION MODULE ---

# --- Discord Bot Token ---
# Lấy token từ trang Discord Developer Portal của bạn.
DISCORD_BOT_TOKEN = "MTQyMjk1NjE0OTY3Nzg4MzUwNQ.GkxI6c.e1kRCp_n4stZj-XTt_xYAcQHAV2JPoM6EhFAtQ"

# -*- coding: utf-8 -*-

# --- CONFIGURATION MODULE ---

# --- NÂNG CẤP: Telegram Bot Token ---
# Lấy token từ BotFather trên Telegram.
TELEGRAM_BOT_TOKEN = "ĐIỀN_TOKEN_BOT_TELEGRAM_CỦA_BẠN_VÀO_ĐÂY"

# --- Gemini API Configuration ---
# Lấy API Key từ Google AI Studio.
GEMINI_API_KEY = "AIzaSyDQpFwaIGmkSRr4w2i28vWFXQDIO74rpxc"
GEMINI_MODEL = "models/gemini-2.5-pro"

# Cài đặt an toàn
SAFETY_SETTINGS = {
    "HARM_CATEGORY_HARASSMENT": "BLOCK_NONE",
    "HARM_CATEGORY_HATE_SPEECH": "BLOCK_NONE",
    "HARM_CATEGORY_SEXUALLY_EXPLICIT": "BLOCK_NONE",
    "HARM_CATEGORY_DANGEROUS_CONTENT": "BLOCK_NONE",
}

# Cài đặt cho việc sinh nội dung
GENERATION_CONFIG = {
    "temperature": 0.6,
    "top_p": 1,
    "top_k": 32,
    "max_output_tokens": 8192,
    "response_mime_type": "text/plain",
}

# --- MetaTrader 5 Account Details ---
MT5_ACCOUNT = 206367566
MT5_PASSWORD = "Ho@ngnam2012"
MT5_SERVER = "Exness-MT5Trial7"

# --- API Keys ---
# Lấy API Key từ trang newsapi.org.
NEWS_API_KEY = "e323e9a689d949ce927f95b044d8d9a4"

# --- NÂNG CẤP: Alpha Vantage API Key ---
ALPHA_VANTAGE_API_KEY = "UWHN9QS5OYFKW93Z"

# Lấy API Key từ trang finnhub.io
FINNHUB_API_KEY = "d3j65hhr01qkv9ju9j90d3j65hhr01qkv9ju9j9g"

# --- NÂNG CẤP: PROXY CONFIGURATION ---
PROXY_ENABLED = True
PROXY_IP = "166.0.152.217"
PROXY_PORT = "26092"
PROXY_USER = "uRThtu"
PROXY_PASS = "jpYapO"

# --- Database Configuration ---
# Tên file cơ sở dữ liệu SQLite.
DATABASE_FILE = "trading_entity.db"

# --- Gemini API Configuration ---
# Lấy API Key từ Google AI Studio.
GEMINI_API_KEY = "AIzaSyDQpFwaIGmkSRr4w2i28vWFXQDIO74rpxc"
GEMINI_MODEL = "models/gemini-2.5-pro"

# Cài đặt an toàn
SAFETY_SETTINGS = {
    "HARM_CATEGORY_HARASSMENT": "BLOCK_NONE",
    "HARM_CATEGORY_HATE_SPEECH": "BLOCK_NONE",
    "HARM_CATEGORY_SEXUALLY_EXPLICIT": "BLOCK_NONE",
    "HARM_CATEGORY_DANGEROUS_CONTENT": "BLOCK_NONE",
}

# Cài đặt cho việc sinh nội dung
GENERATION_CONFIG = {
    "temperature": 0.6,
    "top_p": 1,
    "top_k": 32,
    "max_output_tokens": 8192,
    "response_mime_type": "text/plain",
}

# --- MetaTrader 5 Account Details ---
MT5_ACCOUNT = 206367566
MT5_PASSWORD = "Ho@ngnam2012"
MT5_SERVER = "Exness-MT5Trial7"

# --- API Keys ---
# Lấy API Key từ trang newsapi.org.
NEWS_API_KEY = "e323e9a689d949ce927f95b044d8d9a4"

# --- NÂNG CẤP: Alpha Vantage API Key ---
ALPHA_VANTAGE_API_KEY = "UWHN9QS5OYFKW93Z"

# Lấy API Key từ trang finnhub.io
FINNHUB_API_KEY = "d3j65hhr01qkv9ju9j90d3j65hhr01qkv9ju9j9g"

# --- NÂNG CẤP: PROXY CONFIGURATION ---
PROXY_ENABLED = True
PROXY_IP = "166.0.152.217"
PROXY_PORT = "26092"
PROXY_USER = "uRThtu"
PROXY_PASS = "jpYapO"

# --- Database Configuration ---
# Tên file cơ sở dữ liệu SQLite.
DATABASE_FILE = "trading_entity.db"