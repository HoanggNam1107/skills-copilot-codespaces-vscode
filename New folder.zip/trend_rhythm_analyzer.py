# trend_rhythm_analyzer.py (Phiên bản Nâng cấp Key Structural Levels)
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np # Import numpy
try:
    from scipy.signal import find_peaks
except ImportError:
    print("Cảnh báo: scipy chưa cài đặt. pip install scipy")
    # Cung cấp hàm find_peaks giả lập nếu thiếu
    def find_peaks(series, **kwargs):
        # Trả về mảng rỗng và dict rỗng để tránh lỗi khi giải nén tuple
        return np.array([]), {}

async def analyze_trend_rhythm(price_data: pd.DataFrame, prominence_atr_multiplier=0.5, distance_bars=3) -> dict:
    """
    Phân tích cấu trúc thị trường để xác định xu hướng, các sự kiện BOS/CHoCH,
    VÀ NÂNG CẤP: Xác định các mức cấu trúc chủ chốt (Protected & Target High/Low).
    """
    default_result = {"structure": "UNKNOWN", "last_event": "UNKNOWN", "details": {}, "error": None}
    min_bars_needed = 50 # Số nến tối thiểu để phân tích

    if price_data.empty or len(price_data) < min_bars_needed:
        default_result["error"] = f"Không đủ dữ liệu ({len(price_data)}/{min_bars_needed} nến)"
        return default_result

    # Sao chép để tránh thay đổi DataFrame gốc
    df = price_data.copy()
    highs = df['high']
    lows = df['low']

    # --- Tính toán Prominence động dựa trên ATR ---
    try:
        if 'atr' not in df.columns: # Tính ATR nếu chưa có
             df['tr'] = pd.DataFrame([ df['high'] - df['low'], abs(df['high'] - df['close'].shift()), abs(df['low'] - df['close'].shift()) ]).max(axis=0)
             df['atr'] = df['tr'].ewm(span=14, adjust=False).mean()
        last_atr = df['atr'].iloc[-1] if pd.notna(df['atr'].iloc[-1]) else (highs.iloc[-20:].max() - lows.iloc[-20:].min()) * 0.1 # Fallback ATR
        if last_atr <= 1e-9: last_atr = (highs.iloc[-20:].max() - lows.iloc[-20:].min()) * 0.1 # Fallback nữa nếu ATR=0
        if last_atr <= 1e-9: # Nếu vẫn bằng 0 (thị trường đứng im)
             default_result["structure"] = "Đi ngang tuyệt đối"; default_result["last_event"] = "Không biến động"
             return default_result

        # Prominence là một phần của ATR hoặc % giá, lấy giá trị lớn hơn
        prominence_level = max(last_atr * prominence_atr_multiplier, df['close'].iloc[-1] * 0.0005) # 0.5 ATR hoặc 0.05% giá
    except Exception as e_atr_prom:
        print(f"⚠️ Lỗi tính Prominence: {e_atr_prom}")
        default_result["error"] = "Lỗi tính Prominence"
        return default_result

    # --- Tìm đỉnh/đáy xoay bằng find_peaks ---
    try:
        high_peaks_indices, _ = find_peaks(highs, prominence=prominence_level, distance=distance_bars)
        low_peaks_indices, _ = find_peaks(-lows, prominence=prominence_level, distance=distance_bars)
    except Exception as e_peaks:
        print(f"⚠️ Lỗi find_peaks: {e_peaks}")
        default_result["error"] = "Lỗi tìm đỉnh/đáy"
        return default_result

    # Tạo DataFrame các điểm xoay
    swing_highs_df = pd.DataFrame({'price': highs.iloc[high_peaks_indices], 'type': 'high'}, index=df.index[high_peaks_indices])
    swing_lows_df = pd.DataFrame({'price': lows.iloc[low_peaks_indices], 'type': 'low'}, index=df.index[low_peaks_indices])

    # Kết hợp, sắp xếp và loại bỏ các điểm trùng loại liền kề
    swings = pd.concat([swing_highs_df, swing_lows_df]).sort_index()
    swings = swings.loc[swings['type'] != swings['type'].shift()] # Loại bỏ đỉnh/đỉnh hoặc đáy/đáy liền kề

    if len(swings) < 4: # Cần ít nhất 2 đỉnh và 2 đáy để xác định cấu trúc ban đầu
        default_result["structure"] = "Đang hình thành"
        default_result["last_event"] = f"Chờ đủ đỉnh/đáy ({len(swings)}/4)"
        return default_result

    # --- NÂNG CẤP: Xác định Key Structural Levels ---
    protected_high = None
    protected_low = None
    target_high = None
    target_low = None

    swing_highs = swings[swings['type'] == 'high']
    swing_lows = swings[swings['type'] == 'low']

    # Xác định cấu trúc tổng thể dựa trên 2 đỉnh/2 đáy cuối cùng (như logic cũ)
    structure = "Đi ngang (Choppy)"
    last_event = "Tích lũy/Phân phối" # Default event
    current_price = df['close'].iloc[-1]
    digits = df.attrs.get('digits', 5) # Lấy digits nếu có, mặc định 5

    if len(swing_highs) >= 2 and len(swing_lows) >= 2:
        last_h1 = swing_highs.iloc[-1]; last_h2 = swing_highs.iloc[-2]
        last_l1 = swing_lows.iloc[-1]; last_l2 = swing_lows.iloc[-2]

        is_hh = last_h1['price'] > last_h2['price']
        is_hl = last_l1['price'] > last_l2['price']
        is_lh = last_h1['price'] < last_h2['price']
        is_ll = last_l1['price'] < last_l2['price']

        # Xác định cấu trúc
        if is_hh and is_hl:
            structure = "Xu hướng Tăng (Bullish Structure)"
            protected_low = last_l1['price'] # HL gần nhất tạo ra HH mới nhất
            target_high = last_h1['price'] # HH gần nhất là mục tiêu cần phá
        elif is_lh and is_ll:
            structure = "Xu hướng Giảm (Bearish Structure)"
            protected_high = last_h1['price'] # LH gần nhất tạo ra LL mới nhất
            target_low = last_l1['price'] # LL gần nhất là mục tiêu cần phá
        # (Có thể thêm các trường hợp phức tạp hơn: D1 ngang H4 tăng...)

        # Xác định Sự kiện Cuối cùng (BOS/CHoCH) dựa trên mức Protected/Target
        if "Tăng" in structure:
            if current_price > target_high: last_event = "Phá vỡ Cấu trúc Tăng (Bullish BOS)"
            elif current_price < protected_low: last_event = "Thay đổi Đặc tính Giảm (Bearish CHoCH)"
        elif "Giảm" in structure:
            if current_price < target_low: last_event = "Phá vỡ Cấu trúc Giảm (Bearish BOS)"
            elif current_price > protected_high: last_event = "Thay đổi Đặc tính Tăng (Bullish CHoCH)"
        # Nếu đang Đi ngang, kiểm tra phá vỡ range gần nhất
        elif structure == "Đi ngang (Choppy)":
             recent_high = last_h1['price']
             recent_low = last_l1['price']
             if current_price > recent_high: last_event = "Phá vỡ Ngang Lên (Potential Bullish)"
             elif current_price < recent_low: last_event = "Phá vỡ Ngang Xuống (Potential Bearish)"


    # --- Chuẩn bị kết quả ---
    details = {
        "last_swing_high": round(swing_highs.iloc[-1]['price'], digits) if not swing_highs.empty else None,
        "last_swing_low": round(swing_lows.iloc[-1]['price'], digits) if not swing_lows.empty else None,
        # <-- NÂNG CẤP: Thêm Key Levels vào details -->
        "protected_high": round(protected_high, digits) if protected_high is not None else None,
        "protected_low": round(protected_low, digits) if protected_low is not None else None,
        "target_high": round(target_high, digits) if target_high is not None else None,
        "target_low": round(target_low, digits) if target_low is not None else None,
        # Giữ lại swing points để debug hoặc dùng cho trailing stop
        "swing_points": swings.reset_index().to_dict('records') # Chuyển thành list dict
    }

    return {
        "structure": structure,
        "last_event": last_event,
        "details": details,
        "error": None
    }