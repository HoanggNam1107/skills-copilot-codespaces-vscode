# news_event_rules.py
# -*- coding: utf-8 -*-

# Định nghĩa ý nghĩa của tin tức.
# "higher_is": "GOOD_FOR_CURRENCY" / "BAD_FOR_CURRENCY"
# "lower_is": "GOOD_FOR_CURRENCY" / "BAD_FOR_CURRENCY"
#
# Đối với Vàng (XAUUSD), quy tắc thường là:
# GOOD_FOR_CURRENCY (cho USD) -> BAD_FOR_XAUUSD
# BAD_FOR_CURRENCY (cho USD) -> GOOD_FOR_XAUUSD

# Áp dụng cho USD (có thể mở rộng cho EUR, GBP...)
USD_EVENT_RULES = {
    # --- Lạm phát (Inflation) ---
    "CPI": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"}, # Lạm phát cao -> Lãi suất cao -> Tốt cho tiền tệ
    "Core CPI": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"},
    "PPI": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"},
    "Inflation Rate": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"},
    "PCE Price Index": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"},

    # --- Lãi suất (Interest Rates) ---
    "Interest Rate Decision": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"}, # Lãi suất cao hơn dự kiến -> Rất tốt
    "FOMC Statement": {"qualitative": True}, # Tin định tính, dựa vào AI
    "FOMC Press Conference": {"qualitative": True},

    # --- Việc làm (Employment) ---
    "Non-Farm Payrolls": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"}, # NFP cao -> Kinh tế mạnh -> Tốt
    "NFP": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"},
    "Unemployment Rate": {"higher_is": "BAD_FOR_CURRENCY", "lower_is": "GOOD_FOR_CURRENCY"}, # Thất nghiệp cao -> Xấu
    "Jobless Claims": {"higher_is": "BAD_FOR_CURRENCY", "lower_is": "GOOD_FOR_CURRENCY"}, # Số đơn xin trợ cấp cao -> Xấu
    "Average Hourly Earnings": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"}, # Thu nhập tăng -> Lạm phát -> Tốt

    # --- Tăng trưởng (Growth) ---
    "GDP": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"}, # Tăng trưởng cao -> Tốt
    "Retail Sales": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"}, # Bán lẻ cao -> Tốt
    "Core Retail Sales": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"},

    # --- Sản xuất & Dịch vụ (PMI) ---
    "PMI": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"}, # Trên 50 là mở rộng
    "ISM Manufacturing PMI": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"},
    "ISM Services PMI": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"},

    # --- Niềm tin (Sentiment) ---
    "Consumer Sentiment": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"},
    "Consumer Confidence": {"higher_is": "GOOD_FOR_CURRENCY", "lower_is": "BAD_FOR_CURRENCY"},
}

# (Bạn có thể thêm EUR_EVENT_RULES, GBP_EVENT_RULES... ở đây)
CURRENCY_RULES_MAP = {
    "USD": USD_EVENT_RULES,
    # "EUR": EUR_EVENT_RULES,
    # "GBP": GBP_EVENT_RULES,
}

def get_qualitative_rule(currency: str, event_name: str) -> dict:
    """
    Tìm quy tắc định tính cho một sự kiện dựa trên tiền tệ và từ khóa.
    """
    if not currency or not event_name:
        return None
    
    # Chuẩn hóa (ví dụ: 'USD' hoặc 'US' đều là USD)
    currency_norm = currency.upper()
    if currency_norm == "US": currency_norm = "USD"
    # (Thêm các chuẩn hóa khác nếu cần, ví dụ 'EU' -> 'EUR')
    if currency_norm == "EU": currency_norm = "EUR"


    # Lấy bộ quy tắc cho tiền tệ đó
    rules = CURRENCY_RULES_MAP.get(currency_norm)
    if not rules:
        return None # Không có quy tắc cho tiền tệ này

    event_lower = event_name.lower()

    # Tìm quy tắc khớp chính xác hoặc khớp từ khóa
    for keyword, rule in rules.items():
        if keyword.lower() in event_lower:
            return rule # Trả về quy tắc (ví dụ: {"higher_is": "GOOD_FOR_CURRENCY"})

    return None # Không tìm thấy quy tắc nào khớp