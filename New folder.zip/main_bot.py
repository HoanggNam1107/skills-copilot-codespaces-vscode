# main_bot.py (Phiên bản Telegram - Sửa lỗi Proxy)
# -*- coding: utf-8 -*-
import json
import asyncio
import sys
import os
import MetaTrader5 as mt5
from datetime import datetime
import logging

# --- KÍCH HOẠT PROXY TOÀN HỆ THỐNG ---
import config
if hasattr(config, 'PROXY_ENABLED') and config.PROXY_ENABLED and hasattr(config, 'PROXY_IP') and config.PROXY_IP:
    proxy_url = f"http://{config.PROXY_USER}:{config.PROXY_PASS}@{config.PROXY_IP}:{config.PROXY_PORT}" if hasattr(config, 'PROXY_USER') and config.PROXY_USER else f"http://{config.PROXY_IP}:{config.PROXY_PORT}"
    os.environ['HTTP_PROXY'] = proxy_url
    os.environ['HTTPS_PROXY'] = proxy_url
    print(f"✅ Đã kích hoạt Proxy toàn hệ thống qua địa chỉ: {config.PROXY_IP}")
# ----------------------------------------

# --- NÂNG CẤP: Import thư viện Telegram ---
from telegram import Update, BotCommand
from telegram.constants import ParseMode
from telegram.ext import Application, CommandHandler, ContextTypes, JobQueue

# Import các module của hệ thống
import database as db
import data_handler as dh
import autonomous_engine as engine
import trade_manager as tm
import system_state
import tactical_trader
import strategy_cache
import performance_analyzer as pa
import journaler # <-- Đã thêm file journaler từ lần sửa trước

# Tắt bớt log rác từ thư viện telegram
logging.getLogger("httpx").setLevel(logging.WARNING)

# --- Biến toàn cục ---
mandate = {}
TELEGRAM_CHAT_ID = None

# --- CÁC HÀM TÁC VỤ (TASKS) ---
# Các hàm này sẽ được gọi bởi JobQueue của Telegram

async def economic_events_update_cycle(context: ContextTypes.DEFAULT_TYPE):
    if not TELEGRAM_CHAT_ID: return
    if mandate and system_state.get_status() != "PAUSED":
        await engine.update_economic_events(mandate, context, TELEGRAM_CHAT_ID)

async def context_update_cycle(context: ContextTypes.DEFAULT_TYPE):
    if not TELEGRAM_CHAT_ID: return
    if mandate and system_state.get_status() != "PAUSED":
        await engine.update_context_cache(mandate)

async def strategic_analysis_cycle(context: ContextTypes.DEFAULT_TYPE):
    if not TELEGRAM_CHAT_ID: return
    if mandate and system_state.get_status() != "PAUSED":
        await engine.engine_run_cycle(mandate, context, TELEGRAM_CHAT_ID)

async def tactical_execution_cycle(context: ContextTypes.DEFAULT_TYPE):
    if not TELEGRAM_CHAT_ID: return
    if mandate and system_state.get_status() == "ACTIVE_TRADING":
        await tactical_trader.run_tactical_cycle(mandate, context, TELEGRAM_CHAT_ID)

async def trade_management_cycle(context: ContextTypes.DEFAULT_TYPE):
    if not TELEGRAM_CHAT_ID: return
    if mandate and system_state.get_status() != "PAUSED":
        await tm.manage_open_trades(mandate, context, TELEGRAM_CHAT_ID)

async def journaler_sync_cycle(context: ContextTypes.DEFAULT_TYPE):
    if mandate and system_state.get_status() != "PAUSED":
        await asyncio.to_thread(asyncio.run, journaler.sync_closed_trades())


# --- CÁC LỆNH TELEGRAM (COMMAND HANDLERS) ---

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Gửi tin nhắn chào mừng và hướng dẫn."""
    user_name = update.effective_user.first_name
    await update.message.reply_html(
        f"👋 Chào {user_name}!\n\n"
        f"Tôi là Bot Giao dịch Gemini-SMC. Tôi đã được kết nối và đang chạy.\n"
        f"ID Chat này là: <code>{update.message.chat_id}</code>\n"
        f"Vui lòng sao chép ID này và dán vào file <code>mandate.json</code> (trường 'telegram_chat_id').\n\n"
        f"Các lệnh có sẵn:\n"
        f"/dashboard - Hiển thị bảng điều khiển trạng thái.\n"
        f"/performance_report - Báo cáo hiệu suất giao dịch.\n"
        f"/set_status [STATE] - Thay đổi trạng thái bot (ví dụ: /set_status PAUSED).\n"
        f"/portfolio - Hiển thị các lệnh đang mở."
    )

async def dashboard_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Hiển thị bảng điều khiển trạng thái hệ thống."""
    trading_status = system_state.get_status()
    status_emoji = {"ACTIVE_TRADING": "✅ Giao dịch Kích hoạt", "CLOSE_ONLY": "🔒 Chỉ Đóng lệnh", "PAUSED": "🔴 Tạm dừng"}
    status_color = {"ACTIVE_TRADING": "🟩", "CLOSE_ONLY": "🟧", "PAUSED": "🟥"}
    
    try:
        account_info = await asyncio.to_thread(mt5.account_info)
        if not account_info:
            await update.message.reply_text("❌ Lỗi: Không thể lấy thông tin tài khoản MT5.")
            return

        text = f"<b>📊 Bảng điều khiển Hệ thống</b> {status_color.get(trading_status, '⬜️')}\n"
        text += f"-----------------------------------\n"
        text += f"<b>Trạng thái: {status_emoji.get(trading_status)}</b>\n\n"
        text += f"<b>Balance:</b> {account_info.balance:,.2f} {account_info.currency}\n"
        text += f"<b>Equity:</b> {account_info.equity:,.2f} {account_info.currency}\n"
        text += f"<b>Lợi nhuận Thả nổi:</b> {account_info.profit:,.2f} {account_info.currency}\n\n"
        text += f"<i>MT5: {account_info.login} | {account_info.server}</i>"
        
        await update.message.reply_html(text)

    except Exception as e:
        print(f"❌ Lỗi trong lệnh /dashboard: {e}")
        await update.message.reply_text(f"❌ Lỗi: Có thể MT5 terminal đã bị treo. Lỗi: {e}")

async def performance_report_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Phân tích và báo cáo hiệu suất giao dịch của bot."""
    await update.message.reply_text("Đang truy xuất và phân tích nhật ký... Vui lòng đợi ⏳")
    report = await asyncio.to_thread(pa.analyze_performance)
    
    if "error" in report:
        await update.message.reply_text(f"⚠️ <b>Lỗi:</b> {report['error']}", parse_mode=ParseMode.HTML)
        return

    profit_emoji = "📈" if report['net_profit'] > 0 else "📉"
    caption = f"<b>{profit_emoji} Báo cáo Hiệu suất Giao dịch</b>\n"
    caption += f"<i>Phân tích dựa trên <b>{report['num_trades']}</b> giao dịch đã đóng.</i>\n"
    caption += f"-----------------------------------\n"
    caption += f"<b>Tổng Lợi nhuận:</b> ${report['net_profit']}\n"
    caption += f"<b>Tỷ lệ Thắng:</b> {report['win_rate']}%\n"
    caption += f"<b>Profit Factor:</b> {report['profit_factor']}\n"
    caption += f"<b>Sụt giảm Tối đa:</b> {report['max_drawdown']}%\n"
    caption += f"<b>Tỷ lệ Sharpe:</b> {report['sharpe_ratio']}\n"

    try:
        await update.message.reply_photo(
            photo=open(report['image_path'], 'rb'),
            caption=caption,
            parse_mode=ParseMode.HTML
        )
    except Exception as e:
        await update.message.reply_text(f"❌ Lỗi khi gửi báo cáo: {e}")

async def set_status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """[QUAN TRỌNG] Thay đổi trạng thái hoạt động của bot."""
    args = context.args
    if not args:
        await update.message.reply_html(
            "Bạn phải cung cấp trạng thái. Ví dụ:\n"
            "<code>/set_status ACTIVE_TRADING</code>\n"
            "<code>/set_status CLOSE_ONLY</code>\n"
            "<code>/set_status PAUSED</code>"
        )
        return

    new_status = args[0].upper()
    if new_status not in system_state.POSSIBLE_STATES:
        await update.message.reply_text(f"❌ Lỗi: Trạng thái '{new_status}' không hợp lệ.")
        return

    if system_state.set_status(new_status):
        await update.message.reply_html(f"✅ <b>Trạng thái hệ thống đã được cập nhật thành: <code>{new_status}</code></b>")
    else:
        await update.message.reply_text(f"❌ Lỗi: Không thể cập nhật trạng thái.")

async def portfolio_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Hiển thị tất cả các lệnh đang mở."""
    positions = await asyncio.to_thread(mt5.positions_get)
    if not positions:
        await update.message.reply_text("ℹ️ Không có lệnh nào đang mở.")
        return

    text = "<b>📁 Danh mục Lệnh đang Mở</b>\n-----------------------------------\n"
    total_profit = 0
    for pos in positions:
        pos_type = "BUY" if pos.type == 0 else "SELL"
        profit_emoji = "🟢" if pos.profit >= 0 else "🔴"
        profit_str = f"+{pos.profit:,.2f}" if pos.profit >= 0 else f"{pos.profit:,.2f}"
        total_profit += pos.profit
        
        text += f"<b>{pos.symbol}</b> - Lệnh <code>#{pos.ticket}</code>\n"
        text += f"  {pos_type} {pos.volume} lots | {profit_emoji} <b>{profit_str}</b>\n"
        text += f"  Giá mở: {pos.price_open} | SL: {pos.sl} | TP: {pos.tp}\n\n"

    text += f"<b>Tổng lợi nhuận thả nổi: {total_profit:,.2f}</b>"
    await update.message.reply_html(text)

async def post_init(application: Application):
    """Hàm chạy sau khi bot khởi động, dùng để thiết lập JobQueue và Menu Lệnh."""
    global mandate, TELEGRAM_CHAT_ID
    
    print("--- [TELEGRAM BOT] Bắt đầu quy trình khởi động ---")
    
    db.db_initialize()
    print(f"ℹ️ Trạng thái ban đầu của hệ thống: {system_state.get_status()}")

    try:
        with open("mandate.json", "r", encoding="utf-8") as f:
            mandate = json.load(f)
        print("📜 Đã tải Hiến pháp (mandate.json).")
        
        chat_id_str = mandate.get("reporting_schedule", {}).get("telegram_chat_id")
        if chat_id_str and "ĐIỀN" not in chat_id_str:
            TELEGRAM_CHAT_ID = chat_id_str
            print(f"📢 CHAT ID báo cáo được thiết lập: {TELEGRAM_CHAT_ID}")
        else:
            print("❌ CẢNH BÁO: 'telegram_chat_id' chưa được cấu hình trong mandate.json.")
            print("Bot sẽ chạy, nhưng không thể gửi báo cáo tự động.")
            
    except Exception as e:
        print(f"❌ LỖI: Không thể tải hoặc xử lý tệp mandate.json: {e}"); return
        
    if not dh.mt5_initialize():
        print("❌ LỖI NGHIÊM TRỌNG: Không thể kết nối MT5."); return

    # --- NÂNG CẤP: Lên lịch các vòng lặp (tasks) ---
    job_queue = application.job_queue
    
    job_queue.run_repeating(economic_events_update_cycle, interval=300, first=10) # 5 phút
    job_queue.run_repeating(context_update_cycle, interval=39600, first=20) # 11 giờ
    job_queue.run_repeating(strategic_analysis_cycle, interval=900, first=30) # 15 phút
    job_queue.run_repeating(tactical_execution_cycle, interval=15, first=40) # 15 giây
    job_queue.run_repeating(trade_management_cycle, interval=20, first=50) # 20 giây
    job_queue.run_repeating(journaler_sync_cycle, interval=60, first=60) # 1 phút
    
    print("✅ Tất cả các chu trình (Jobs) đã được lên lịch.")

    # --- NÂNG CẤP: Thiết lập menu lệnh cho Telegram ---
    commands = [
        BotCommand("start", "Khởi động lại bot và xem Chat ID"),
        BotCommand("dashboard", "Hiển thị bảng điều khiển trạng thái"),
        BotCommand("performance_report", "Báo cáo hiệu suất giao dịch"),
        BotCommand("set_status", "Đặt trạng thái bot (ACTIVE/CLOSE_ONLY/PAUSED)"),
        BotCommand("portfolio", "Xem các lệnh đang mở")
    ]
    await application.bot.set_my_commands(commands)
    
    print(f"✅ Bot {application.bot.username} đã sẵn sàng!")
    if TELEGRAM_CHAT_ID:
        await application.bot.send_message(
            chat_id=TELEGRAM_CHAT_ID,
            text=f"✅ <b>Hệ thống khởi động thành công!</b>\nTrạng thái hiện tại: <code>{system_state.get_status()}</code>",
            parse_mode=ParseMode.HTML
        )

# --- HÀM CHẠY BOT CHÍNH ---
def main():
    if not config.TELEGRAM_BOT_TOKEN or "ĐIỀN_TOKEN_BOT_TELEGRAM_CỦA_BẠN_VÀO_ĐÂY" in config.TELEGRAM_BOT_TOKEN:
        print("❌ LỖI: Vui lòng điền TELEGRAM_BOT_TOKEN vào file config.py.")
        return

    # Khởi tạo Application
    application = Application.builder().token(config.TELEGRAM_BOT_TOKEN).post_init(post_init).build()

    # Đăng ký các Command Handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("dashboard", dashboard_command))
    application.add_handler(CommandHandler("performance_report", performance_report_command))
    application.add_handler(CommandHandler("set_status", set_status_command))
    application.add_handler(CommandHandler("portfolio", portfolio_command))

    # Chạy bot
    print("--- [TELEGRAM BOT] Bắt đầu chạy Polling... ---")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    main()