# technical_analyzer.py (Nâng cấp S/R tĩnh bằng Peaks)
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import MetaTrader5 as mt5
from data_handler import mt5_get_rates
# --- NÂNG CẤP: Import find_peaks ---
try:
    from scipy.signal import find_peaks
except ImportError:
    print("Cảnh báo: scipy chưa cài đặt (technical_analyzer). pip install scipy")
    find_peaks = None # Đặt là None nếu không import được
# --- Kết thúc nâng cấp ---

async def analyze_technicals(symbol: str, timeframe=mt5.TIMEFRAME_H4, price_data: pd.DataFrame = None) -> dict:
    """
    Thực hiện phân tích kỹ thuật: Xu hướng EMA, Động lượng RSI,
    VÀ NÂNG CẤP: Xác định Hỗ trợ/Kháng cự Cấu trúc (Structure S/R) bằng find_peaks.
    """
    default_result = {"error": None, "details": {}, "symbol_info": None} # Thêm symbol_info vào default
    min_bars_needed = 200 # Cần đủ nến cho EMA chậm và tìm peaks

    # Lấy hoặc kiểm tra dữ liệu đầu vào
    df_full = pd.DataFrame() # Khởi tạo df_full
    if price_data is None or not isinstance(price_data, pd.DataFrame) or len(price_data) < min_bars_needed:
        # print(f"ℹ️ [TECH] Lấy dữ liệu mới cho {symbol} {mt5.timeframe_to_string(timeframe)}") # Debug log
        df_full = await mt5_get_rates(symbol, timeframe, count=min_bars_needed + 50) # Lấy dư
    else:
        # print(f"ℹ️ [TECH] Sử dụng dữ liệu H4 đã có cho {symbol}") # Debug log
        df_full = price_data.copy() # Sử dụng data đã có

    # Kiểm tra dữ liệu sau khi lấy/copy
    if df_full.empty or len(df_full) < min_bars_needed:
        default_result["error"] = f"Không đủ dữ liệu ({len(df_full) if not df_full.empty else 0}/{min_bars_needed})"
        return default_result
    # Đảm bảo có đủ cột
    required_cols = ['time', 'open', 'high', 'low', 'close', 'tick_volume']
    if not all(col in df_full.columns for col in required_cols):
         default_result["error"] = f"Thiếu cột dữ liệu OHLCV: {required_cols}"
         return default_result

    df = df_full.copy() # Làm việc trên bản sao

    # Lấy thông tin symbol (digits)
    symbol_info = mt5.symbol_info(symbol)
    digits = symbol_info.digits if symbol_info else 5
    # Lưu symbol_info để trả về
    symbol_info_dict = {"digits": digits} if symbol_info else None

    # --- 1. Phân tích Xu hướng với EMA ---
    ema_slow_period = 200
    trend = "LỖI EMA"; last_ema_slow = None; last_close = df['close'].iloc[-1] if not df.empty else 0
    try:
        # Tính toán an toàn hơn
        if 'close' in df.columns and len(df) >= ema_slow_period:
             df['ema_slow'] = df['close'].ewm(span=ema_slow_period, adjust=False, min_periods=ema_slow_period//2).mean() # Thêm min_periods
             # Lấy giá trị cuối, kiểm tra NaN
             ema_val = df['ema_slow'].iloc[-1]
             if pd.notna(ema_val):
                  last_ema_slow = round(ema_val, digits)
                  trend = "TĂNG" if last_close > last_ema_slow else "GIẢM" if last_close < last_ema_slow else "ĐI NGANG"
             else: trend = "EMA NaN" # Đánh dấu nếu EMA là NaN
        else: trend = "Ít dữ liệu EMA"
    except Exception as e_ema:
        print(f"⚠️ Lỗi tính EMA {symbol}: {e_ema}")


    # --- 2. Phân tích Động lượng với RSI ---
    rsi_period = 14; last_rsi = None; momentum_status = "LỖI RSI"
    try:
        # Tính toán an toàn hơn
        if 'close' in df.columns and len(df) >= rsi_period + 1:
             delta = df['close'].diff()
             gain = delta.where(delta > 0, 0).rolling(window=rsi_period, min_periods=rsi_period//2+1).mean()
             loss = (-delta.where(delta < 0, 0)).rolling(window=rsi_period, min_periods=rsi_period//2+1).mean()
             # Xử lý chia cho 0 và NaN
             loss_safe = loss.replace(0, 1e-9).fillna(1e-9)
             gain_safe = gain.fillna(0)
             rs = gain_safe / loss_safe
             rsi = 100 - (100 / (1 + rs))
             rsi_val = rsi.iloc[-1]
             if pd.notna(rsi_val):
                  last_rsi = round(rsi_val, 2)
                  momentum_status = "QUÁ MUA" if last_rsi > 70 else "QUÁ BÁN" if last_rsi < 30 else "TRUNG TÍNH"
             else: momentum_status = "NaN RSI"
        else: momentum_status = "Ít dữ liệu RSI"
    except Exception as e_rsi:
        print(f"⚠️ Lỗi tính RSI {symbol}: {e_rsi}")


    # --- 3. NÂNG CẤP: Xác định Hỗ trợ & Kháng cự Cấu trúc ---
    key_support = None; key_resistance = None
    if find_peaks: # Chỉ chạy nếu import thành công
        try:
            # Lấy khoảng 100 nến cuối
            recent_data = df.tail(100).copy() # Tạo bản sao để tính ATR
            highs_recent = recent_data['high']
            lows_recent = recent_data['low']
            close_recent = recent_data['close']

            # Tính prominence động dựa trên ATR của khoảng thời gian này
            recent_atr = 1e-5 # Default nhỏ
            try: # Tính ATR an toàn
                 if 'atr' not in recent_data.columns:
                      tr1 = recent_data['high'] - recent_data['low']
                      tr2 = abs(recent_data['high'] - recent_data['close'].shift())
                      tr3 = abs(recent_data['low'] - recent_data['close'].shift())
                      tr_df = pd.concat([tr1, tr2, tr3], axis=1)
                      recent_data['tr'] = tr_df.max(axis=1, skipna=True)
                      recent_data['atr'] = recent_data['tr'].ewm(span=14, adjust=False, min_periods=10).mean()
                 atr_val = recent_data['atr'].iloc[-1]
                 if pd.notna(atr_val) and atr_val > 0: recent_atr = atr_val
                 else: # Fallback nếu ATR vẫn lỗi
                      atr_fallback = (highs_recent.max()-lows_recent.min())*0.1
                      if atr_fallback > 0: recent_atr = atr_fallback
            except Exception as e_atr_sr: print(f"⚠️ Lỗi tính ATR cho S/R: {e_atr_sr}")

            prominence_sr = max(recent_atr * 1.0, close_recent.iloc[-1] * 0.001) if not close_recent.empty else recent_atr * 1.0 # 1.0 ATR hoặc 0.1% giá

            # Tìm các đỉnh/đáy đáng kể
            res_peaks_idx, _ = find_peaks(highs_recent, prominence=prominence_sr, distance=5)
            sup_peaks_idx, _ = find_peaks(-lows_recent, prominence=prominence_sr, distance=5)

            # Lấy mức kháng cự cao nhất và hỗ trợ thấp nhất
            if res_peaks_idx.size > 0:
                key_resistance = round(highs_recent.iloc[res_peaks_idx].max(), digits)
            else: key_resistance = round(highs_recent.max(), digits) # Fallback

            if sup_peaks_idx.size > 0:
                key_support = round(lows_recent.iloc[sup_peaks_idx].min(), digits)
            else: key_support = round(lows_recent.min(), digits) # Fallback

        except Exception as e_sr:
            print(f"⚠️ Lỗi tìm S/R Peaks {symbol}: {e_sr}")
            # Fallback về logic cũ nếu lỗi
            lookback_period = 50
            recent_data_fallback = df.tail(lookback_period)
            if not recent_data_fallback.empty:
                 key_support = round(recent_data_fallback['low'].min(), digits)
                 key_resistance = round(recent_data_fallback['high'].max(), digits)
    else: # Fallback nếu không có find_peaks
        print(f"⚠️ Không có thư viện scipy, dùng S/R min/max đơn giản cho {symbol}.")
        lookback_period = 50
        recent_data_fallback = df.tail(lookback_period)
        if not recent_data_fallback.empty:
             key_support = round(recent_data_fallback['low'].min(), digits)
             key_resistance = round(recent_data_fallback['high'].max(), digits)
    # --- Kết thúc nâng cấp S/R ---


    # Trả về kết quả
    default_result["trend_indicator"] = f"EMA({ema_slow_period})"
    default_result["trend_status"] = trend
    default_result["momentum_indicator"] = f"RSI({rsi_period})"
    default_result["momentum_status"] = momentum_status
    default_result["details"] = {
        "current_price": last_close,
        "ema_value": last_ema_slow,
        "rsi_value": last_rsi,
        "key_support": key_support, # S/R đã được nâng cấp
        "key_resistance": key_resistance, # S/R đã được nâng cấp
        "symbol_info": symbol_info_dict # Trả về thông tin symbol (chứa digits)
    }
    # Loại bỏ error nếu không có lỗi
    if default_result["error"] is None: del default_result["error"]
    return default_result