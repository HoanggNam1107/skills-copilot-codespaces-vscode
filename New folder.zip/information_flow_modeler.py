# -*- coding: utf-8 -*-
import pandas as pd
from statsmodels.tsa.stattools import grangercausalitytests

async def modeler_find_leading_asset(data_df: pd.DataFrame, target_asset: str, max_lag=5) -> str:
    """Tìm tài sản dẫn dắt cho một tài sản mục tiêu bằng Granger Causality."""
    if target_asset not in data_df.columns:
        return "Không xác định"
        
    lead_asset, min_p_value = "Không xác định", 0.05
    
    for col in data_df.columns:
        if col == target_asset:
            continue
            
        test_data = data_df[[target_asset, col]].pct_change().dropna()
        
        if len(test_data) < 30: # Cần đủ dữ liệu để kiểm định
            continue
            
        try:
            # Chạy kiểm định Granger
            result = grangercausalitytests(test_data, [max_lag], verbose=False)
            p_value = result[max_lag][0]['ssr_ftest'][1]
            
            if p_value < min_p_value:
                min_p_value, lead_asset = p_value, col
        except Exception:
            continue
            
    return lead_asset