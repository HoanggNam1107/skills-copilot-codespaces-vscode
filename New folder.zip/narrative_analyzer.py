# narrative_analyzer.py (Phiên bản Nâng cấp Đa nguồn tin)
# -*- coding: utf-8 -*-
import asyncio
from newsapi import NewsApiClient
import feedparser
import config
import gemini_client as gc
import json
import re

newsapi = NewsApiClient(api_key=config.NEWS_API_KEY)
RSS_FEEDS = {
    "Reuters Currencies": "https://www.reuters.com/markets/currencies/rss/",
    "ForexLive": "https://www.forexlive.com/feed",
}

async def get_news_from_api(search_query: str) -> list:
    """Sử dụng NewsAPI.org để lấy các tiêu đề tin tức."""
    try:
        all_articles = await asyncio.to_thread(
            newsapi.get_everything,
            q=search_query,
            language='en',
            sort_by='relevancy',
            page_size=15
        )
        if not all_articles or all_articles['totalResults'] == 0:
            return []
        return [article['title'] for article in all_articles['articles']]
    except Exception as e:
        print(f"⚠️ [NARRATIVE] Nguồn NewsAPI thất bại: {e}")
        return []

async def get_news_from_rss(feed_url: str) -> list:
    """Lấy các tiêu đề tin tức từ một nguồn cấp RSS."""
    try:
        feed = await asyncio.to_thread(feedparser.parse, feed_url)
        headlines = [entry.title for entry in feed.entries[:15]]
        return headlines
    except Exception as e:
        print(f"⚠️ [NARRATIVE] Nguồn RSS {feed_url} thất bại: {e}")
        return []

async def analyze_narrative_lifecycle(symbol: str) -> dict:
    """
    Phân tích vòng đời của câu chuyện thị trường bằng cách tổng hợp tin tức
    từ nhiều nguồn (NewsAPI và RSS Feeds).
    """
    print(f"📖 Phân tích tường thuật đa nguồn cho {symbol}...")
    tasks = []
    query = f'"{symbol[:3]}" OR "{symbol[3:]}"'
    tasks.append(get_news_from_api(query))
    for name, url in RSS_FEEDS.items():
        tasks.append(get_news_from_rss(url))
        
    results = await asyncio.gather(*tasks)
    
    all_headlines = []
    for headline_list in results:
        all_headlines.extend(headline_list)
        
    if not all_headlines:
        return {"success": False, "headlines": "Bot không thể lấy được tin tức từ bất kỳ nguồn nào."}

    unique_headlines = sorted(list(set(all_headlines)), key=lambda x: all_headlines.index(x))
    news_snippets = "\n".join([f"- {h}" for h in unique_headlines[:25]])
    
    # Thay vì gọi Gemini ở đây, chúng ta chỉ trả về dữ liệu thô
    # Gemini sẽ là người phân tích cuối cùng
    return {"success": True, "headlines": news_snippets}