# market_regime_analyzer.py (Phiên bản Nâng cấp Hurst & Ngưỡng Thông minh)
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from hurst import compute_Hc

def analyze_market_regime(price_data: pd.DataFrame, adx_period=14) -> dict:
    """
    Phân tích "tính cách" thị trường bằng cách kết hợp ADX (sức mạnh xu hướng)
    và Hurst Exponent (khả năng tiếp diễn/đảo chiều).
    """
    if price_data.empty or len(price_data) < 100: # Hurst cần nhiều dữ liệu hơn
        return {
            "regime": "Không xác định", 
            "details": {"error": "Không đủ dữ liệu."}
        }

    df = price_data.copy()

    # --- 1. NÂNG CẤP: Ngưỡng Biến động "Thông minh" (Adaptive Volatility) ---
    df['tr'] = pd.DataFrame([df['high'] - df['low'], 
                             abs(df['high'] - df['close'].shift()), 
                             abs(df['low'] - df['close'].shift())]).max(axis=0)
    df['atr'] = df['tr'].ewm(span=adx_period, adjust=False).mean()
    df['normalized_atr'] = (df['atr'] / df['close']) * 100
    
    # So sánh ATR hiện tại với chính nó trong quá khứ (100 nến)
    df['atr_percentile'] = df['normalized_atr'].rolling(window=100).apply(lambda x: pd.Series(x).rank(pct=True).iloc[-1], raw=False)
    last_atr_percentile = df['atr_percentile'].iloc[-1]
    
    volatility = "Trung bình (Medium)"
    if pd.notna(last_atr_percentile):
        if last_atr_percentile > 0.7:
            volatility = "Cao (High)"
        elif last_atr_percentile < 0.3:
            volatility = "Thấp (Low)"

    # --- 2. Tính toán ADX (giữ nguyên) ---
    df['plus_dm'] = df['high'].diff()
    df['minus_dm'] = df['low'].diff().apply(lambda x: -x)
    df['plus_dm_smooth'] = df['plus_dm'].ewm(alpha=1/adx_period, adjust=False).mean()
    df['minus_dm_smooth'] = df['minus_dm'].ewm(alpha=1/adx_period, adjust=False).mean()
    df['plus_di'] = 100 * (df['plus_dm_smooth'] / df['atr'])
    df['minus_di'] = 100 * (df['minus_dm_smooth'] / df['atr'])
    df['dx'] = 100 * (abs(df['plus_di'] - df['minus_di']) / (df['plus_di'] + df['minus_di'])).fillna(0)
    adx = df['dx'].ewm(alpha=1/adx_period, adjust=False).mean().iloc[-1]

    trendiness = "Đi ngang (Ranging)"
    if adx > 25:
        trendiness = "Có Xu hướng (Trending)"

    # --- 3. NÂNG CẤP: Tính toán Hurst Exponent ---
    try:
        series = df['close'].to_numpy()
        H, c, data = compute_Hc(series, kind='price', simplified=True)
    except Exception as e:
        H = 0.5 # Mặc định là ngẫu nhiên nếu có lỗi tính toán
        print(f"Lỗi khi tính Hurst: {e}")

    market_memory = "Ngẫu nhiên (Random)"
    if H > 0.55:
        market_memory = "Bền bỉ (Persistent)"
    elif H < 0.45:
        market_memory = "Đảo chiều (Mean-Reverting)"
    
    # --- 4. Kết hợp Kết quả ---
    final_regime = f"{trendiness}, thiên về {market_memory}"

    return {
        "regime": final_regime,
        "details": {
            "adx_value": round(adx, 2),
            "trendiness": trendiness,
            "volatility": volatility,
            "hurst_value": round(H, 3),
            "market_memory": market_memory
        }
    }