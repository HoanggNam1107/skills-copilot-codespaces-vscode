# -*- coding: utf-8 -*-
import MetaTrader5 as mt5
from datetime import datetime, timedelta
import database as db
import sqlite3
from config import DATABASE_FILE

def get_last_sync_time() -> datetime:
    """Lấy thời gian đồng bộ lịch sử gần nhất từ DB."""
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()
    # <-- SỬA ĐỔI: Đọc từ bảng sync_status (id=1)
    cursor.execute("SELECT last_sync_time FROM sync_status WHERE id = 1")
    result = cursor.fetchone()
    conn.close()
    
    last_sync_str = result[0] if result else (datetime.now() - timedelta(days=7)).isoformat()
    
    # Chuyển đổi từ string (nếu có) sang datetime
    try:
        return datetime.fromisoformat(last_sync_str)
    except:
        return datetime.now() - timedelta(days=7)

def update_last_sync_time(sync_time: datetime):
    """Cập nhật thời gian đồng bộ mới nhất vào DB."""
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()
    # <-- SỬA ĐỔI: Cập nhật bảng sync_status (id=1)
    cursor.execute("UPDATE sync_status SET last_sync_time = ? WHERE id = 1", (sync_time.isoformat(),))
    conn.commit()
    conn.close()

async def sync_closed_trades():
    """
    Quét lịch sử giao dịch từ MT5, tìm các lệnh đã đóng và cập nhật chi phí vào DB.
    """
    print("[Journaler] Bắt đầu chu trình đồng bộ hóa nhật ký giao dịch...")
    
    from_date = get_last_sync_time()
    to_date = datetime.now()

    # Lấy tất cả các giao dịch (deals) trong khoảng thời gian
    deals = mt5.history_deals_get(from_date, to_date)
    
    if not deals:
        print("[Journaler] Không có giao dịch mới nào để đồng bộ.")
        # <-- SỬA ĐỔI: Vẫn cập nhật thời gian để tránh quét lại
        update_last_sync_time(to_date)
        return

    print(f"[Journaler] Tìm thấy {len(deals)} deals mới. Đang xử lý...")
    
    # Lọc các deal liên quan đến việc đóng vị thế
    closed_deals = [d for d in deals if d.entry == mt5.DEAL_ENTRY_OUT or d.entry == mt5.DEAL_ENTRY_INOUT]
    
    closed_count = 0
    for deal in closed_deals:
        # MT5 sử dụng position_id để liên kết các deal của cùng một lệnh
        # ticket_id trong DB của chúng ta chính là position_id này
        ticket_id = deal.position_id
        
        # Chỉ cập nhật các lệnh có trạng thái 'open' trong DB của chúng ta
        trade_info = db.get_trade_by_ticket(ticket_id)
        
        if trade_info and trade_info['status'] == 'open':
            # <-- SỬA ĐỔI: Gọi hàm 'log_closed_trade' chính xác -->
            db.log_closed_trade(
                ticket_id=ticket_id,
                close_time=datetime.fromtimestamp(deal.time),
                close_price=deal.price,
                profit=deal.profit,
                commission=deal.commission,
                swap=deal.swap
            )
            closed_count += 1
            
    # Cập nhật thời gian đồng bộ thành công
    update_last_sync_time(to_date)
    print(f"[Journaler] Hoàn thành đồng bộ hóa. {closed_count} lệnh đã được cập nhật trạng thái 'closed'.")