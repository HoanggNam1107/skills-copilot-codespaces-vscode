# data_handler.py
# -*- coding: utf-8 -*-
import MetaTrader5 as mt5
import pandas as pd
from config import MT5_ACCOUNT, MT5_PASSWORD, MT5_SERVER
import asyncio
from datetime import datetime, timedelta

def mt5_initialize():
    """Khởi tạo và đăng nhập vào tài khoản MT5."""
    if not mt5.initialize():
        print(f"❌ Khởi tạo MT5 thất bại, lỗi: {mt5.last_error()}")
        return False
        
    authorized = mt5.login(MT5_ACCOUNT, password=MT5_PASSWORD, server=MT5_SERVER)
    if not authorized:
        print(f"❌ Kết nối MT5 thất bại, lỗi: {mt5.last_error()}")
        mt5.shutdown()
        return False
        
    print(f"✅ Đã kết nối MT5 tới tài khoản #{MT5_ACCOUNT}")
    return True

async def mt5_get_rates(symbol: str, timeframe, count: int) -> pd.DataFrame:
    """Lấy dữ liệu giá từ MT5 một cách bất đồng bộ an toàn."""
    try:
        selected = await asyncio.to_thread(mt5.symbol_select, symbol, True)
        if not selected:
            # Nếu không select được, thử lại sau 1 giây (có thể do kết nối)
            await asyncio.sleep(1)
            selected = await asyncio.to_thread(mt5.symbol_select, symbol, True)
            if not selected:
                print(f"⚠️ Không thể chọn symbol {symbol} sau khi thử lại.")
                return pd.DataFrame()
            
        rates = await asyncio.to_thread(mt5.copy_rates_from_pos, symbol, timeframe, 0, count)
        if rates is None or len(rates) == 0:
             # Thử lấy lại dữ liệu nếu lần đầu thất bại
             await asyncio.sleep(1)
             rates = await asyncio.to_thread(mt5.copy_rates_from_pos, symbol, timeframe, 0, count)
             if rates is None or len(rates) == 0:
                 print(f"⚠️ Không thể lấy rates cho {symbol} khung {timeframe} sau khi thử lại.")
                 return pd.DataFrame()
            
        df = pd.DataFrame(rates)
        df['time'] = pd.to_datetime(df['time'], unit='s')
        # Đổi tên cột chuẩn hóa
        df.rename(columns={
            'open': 'open', 'high': 'high', 'low': 'low', 'close': 'close',
            'tick_volume': 'tick_volume', 'real_volume': 'real_volume', 'spread': 'spread'
        }, inplace=True)
        return df[['time', 'open', 'high', 'low', 'close', 'tick_volume']] # Chỉ trả về các cột cần thiết
    except Exception as e:
        print(f"❌ Lỗi nghiêm trọng khi lấy dữ liệu giá cho {symbol}: {e}")
        return pd.DataFrame()

# --- NÂNG CẤP: HÀM MỚI ĐỂ LẤY DỮ LIỆU TICK (Đã bao gồm Flags) ---
async def mt5_get_ticks_range(symbol: str, hours_ago: int = 24, max_ticks: int = 200000) -> pd.DataFrame:
    """
    Lấy dữ liệu tick trong một khoảng thời gian nhất định để xây dựng Volume Profile.
    Đảm bảo lấy cờ (flags) để tính Delta.
    """
    try:
        from_date = datetime.now() - timedelta(hours=hours_ago)
        
        # Chạy hàm blocking trong thread riêng
        # mt5.COPY_TICKS_ALL đảm bảo lấy cột 'flags'
        ticks = await asyncio.to_thread(mt5.copy_ticks_from, symbol, from_date, max_ticks, mt5.COPY_TICKS_ALL)
        
        if ticks is None or len(ticks) == 0:
            # Thử lại nếu lần đầu thất bại
            await asyncio.sleep(1)
            ticks = await asyncio.to_thread(mt5.copy_ticks_from, symbol, from_date, max_ticks, mt5.COPY_TICKS_ALL)
            if ticks is None or len(ticks) == 0:
                print(f"⚠️ Không thể lấy ticks cho {symbol} trong {hours_ago} giờ qua sau khi thử lại.")
                return pd.DataFrame()
        
        df = pd.DataFrame(ticks)
        df['time'] = pd.to_datetime(df['time_msc'] / 1000, unit='s') # Sử dụng time_msc để có độ chính xác cao hơn
        # Đảm bảo các cột cần thiết tồn tại
        required_cols = ['time', 'bid', 'ask', 'last', 'volume', 'flags']
        for col in required_cols:
            if col not in df.columns:
                print(f"❌ Lỗi dữ liệu tick cho {symbol}: Thiếu cột '{col}'.")
                return pd.DataFrame()
        # Tính giá 'last' nếu không có (thường xảy ra với Forex)
        if 'last' not in df.columns or df['last'].isnull().all() or (df['last'] == 0).all():
             df['last'] = (df['bid'] + df['ask']) / 2

        return df[required_cols] # Chỉ trả về các cột cần thiết
    except Exception as e:
        print(f"❌ Lỗi nghiêm trọng khi lấy dữ liệu tick cho {symbol}: {e}")
        return pd.DataFrame()