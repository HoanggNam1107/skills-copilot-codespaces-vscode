# strategy_cache.py
# -*- coding: utf-8 -*-
from datetime import datetime, timedelta

# Cache cho các kế hoạch chiến lược từ Gemini
STRATEGY_CACHE = {}

# NÂNG CẤP: Cache cho các tác động tin tức gần đây
RECENT_NEWS_IMPACTS = []

def get_recent_impacts(minutes: int = 15) -> list:
    """Lấy các phân tích tác động tin tức trong khoảng thời gian gần nhất."""
    recent_impacts_formatted = []
    now = datetime.now()
    
    # Dọn dẹp cache cũ và lấy các tin mới
    global RECENT_NEWS_IMPACTS
    RECENT_NEWS_IMPACTS = [impact for impact in RECENT_NEWS_IMPACTS if now - impact.get('timestamp', now) < timedelta(minutes=minutes)]
    
    for impact in RECENT_NEWS_IMPACTS:
        recent_impacts_formatted.append(f"- {impact.get('implication', 'N/A')} ({impact.get('details', 'N/A')})")

    if recent_impacts_formatted:
        return recent_impacts_formatted
        
    return ["Không có tác động tin tức nào đáng chú ý gần đây."]