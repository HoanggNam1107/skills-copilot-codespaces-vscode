# autonomous_engine.py (Phiên bản cuối + gọi async news impact)
# -*- coding: utf-8 -*-
import json
import re
import asyncio
import market_network_analyzer as mna
import information_flow_modeler as ifm
import technical_analyzer as ta
import cycle_analyzer as ca
import market_regime_analyzer as mra
import trend_rhythm_analyzer as tra
import narrative_analyzer as na
import vsa_analyzer as vsa
import mtf_analyzer as mtf
import liquidity_analyzer as la
import volume_profile_analyzer as vpa
import volatility_analyzer as vola
import range_analyzer as ra
import session_analyzer as sa
import prompt_builder as pb
import gemini_client as gc
from data_handler import mt5_get_rates, mt5_get_ticks_range, mt5_initialize
from database import get_recent_trades
import strategy_cache
import economic_calendar
from datetime import datetime, timedelta
import MetaTrader5 as mt5
import news_impact_analyzer as nia # Import nia
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
import pandas as pd
import numpy as np

ANALYSIS_SEMAPHORE = asyncio.Semaphore(2)
CONTEXT_CACHE = {}
UPCOMING_EVENTS_CACHE = []

# --- CÁC HÀM XỬ LÝ SỰ KIỆN & BỐI CẢNH ---
async def run_post_event_analysis(delay_seconds: float, event: dict, context: ContextTypes.DEFAULT_TYPE, chat_id: str):
    """
    Chờ và sau đó phân tích tác động của một sự kiện kinh tế
    (Đã nâng cấp để gọi async analyze_event_impact).
    """
    await asyncio.sleep(delay_seconds)
    print(f"⚡️ [NEWS IMPACT] Đã đến lúc phân tích kết quả tin: {event.get('event', 'N/A')}")
    
    event_result_data = await economic_calendar.get_event_result(event)
    # event_result_data có thể là None nếu không tìm thấy

    # --- SỬA ĐỔI: Gọi hàm async mới ---
    # Hàm analyze_event_impact sẽ tự xử lý nếu event_result_data là None
    impact_analysis = await nia.analyze_event_impact(event_result_data)
    # --- Kết thúc sửa đổi ---

    # Gán thêm thông tin sự kiện gốc vào kết quả
    impact_analysis['timestamp'] = datetime.now()
    impact_analysis['event_name'] = event.get('event', 'N/A')
    impact_analysis['currency'] = event.get('currency', 'N/A')
    
    strategy_cache.RECENT_NEWS_IMPACTS.append(impact_analysis)
    strategy_cache.RECENT_NEWS_IMPACTS = strategy_cache.RECENT_NEWS_IMPACTS[-10:] # Giữ 10 tin cuối

    if context and chat_id:
        try:
            # Format lại thông báo để hiển thị cả 2 loại tin
            icon = "📊" if "Actual" in impact_analysis.get('details', '') else "🗣️" # Icon cho tin số / tin phát biểu
            text = (
                f"<b>{icon} BÁO CÁO TÁC ĐỘNG TIN TỨC {icon}</b>\n"
                f"<b>Sự kiện:</b> {impact_analysis['event_name']} ({impact_analysis['currency']})\n"
                f"<b>Cấp độ:</b> {impact_analysis.get('surprise_level', 'N/A')}\n"
                f"<b>Chi tiết:</b> {impact_analysis.get('details', 'N/A')}\n"
                f"<b>Hàm ý:</b> <i>{impact_analysis.get('implication', 'N/A')}</i>"
            )
            if len(text) > 4000: text = text[:4000] + "..."
            await context.bot.send_message(
                chat_id=chat_id, text=text, parse_mode=ParseMode.HTML, disable_notification=True
            )
        except Exception as e:
            print(f"Lỗi khi gửi báo cáo nhanh về tin tức: {e}")

async def update_economic_events(mandate: dict, context: ContextTypes.DEFAULT_TYPE, chat_id: str):
    """Cập nhật sự kiện kinh tế và lên lịch phân tích."""
    global UPCOMING_EVENTS_CACHE
    print("\n--- [CALENDAR] Đang kiểm tra lịch kinh tế theo quy tắc... ---")
    rules_config = mandate.get("economic_calendar_rules")
    if not rules_config:
        UPCOMING_EVENTS_CACHE = []
        return
    try:
        new_upcoming_events = await economic_calendar.get_upcoming_events(rules_config)
        if new_upcoming_events is not None:
             UPCOMING_EVENTS_CACHE = new_upcoming_events
        else:
             print("⚠️ [CALENDAR] Không thể lấy dữ liệu sự kiện mới, giữ lại cache cũ.")
    except Exception as e_cal:
         print(f"❌ [CALENDAR] Lỗi nghiêm trọng khi gọi get_upcoming_events: {e_cal}")

    if UPCOMING_EVENTS_CACHE:
        now = datetime.now()
        event_names = []
        current_tasks = asyncio.all_tasks()
        scheduled_event_ids = {t.get_name() for t in current_tasks if t.get_name().startswith("event_analysis_")}
        for event in UPCOMING_EVENTS_CACHE:
             if not isinstance(event, dict) or 'time' not in event: continue
             event_id = f"event_analysis_{int(event['time'].timestamp())}_{event.get('currency','NA')}_{event.get('event','UNKNOWN').replace(' ', '_')}"
             if event_id in scheduled_event_ids: continue
             event_names.append(f"{event.get('currency','NA')}-{event.get('event','UNKNOWN')}({event.get('impact', 'N/A')[0]})")
             time_to_event = (event['time'] - now).total_seconds()
             check_delay = max(0, time_to_event) + 120 # Chờ 2 phút sau tin
             print(f"🗓️  [SCHEDULER] Lên lịch phân tích '{event.get('event','UNKNOWN')}' sau ~{int(check_delay/60)} phút. ID: {event_id}")
             asyncio.create_task(run_post_event_analysis(check_delay, event, context, chat_id), name=event_id)
        if event_names: print(f"🔔 [CALENDAR] Cảnh báo sự kiện sắp tới: {', '.join(event_names)}")
        else: print("✅ [CALENDAR] Không có sự kiện mới nào cần lên lịch phân tích.")
    else:
        print("✅ [CALENDAR] Không có sự kiện quan trọng nào sắp diễn ra.")


async def update_context_cache(mandate: dict):
    """Cập nhật thông tin nền (tin tức)."""
    print("\n--- [CONTEXT] Bắt đầu cập nhật thông tin nền (11 giờ) ---")
    all_assets = mandate.get("investment_universe", {}).get("forex_pairs", []) + mandate.get("investment_universe", {}).get("intermarket_assets", [])
    if not all_assets: print("⚠️ [CONTEXT] Không có tài sản nào."); return
    for symbol in all_assets:
        try:
            narrative_analysis = await na.analyze_narrative_lifecycle(symbol)
            CONTEXT_CACHE[symbol] = {"narrative": narrative_analysis, "timestamp": datetime.now()}
            print(f"🌍 [CONTEXT] Đã cập nhật tin tức cho {symbol}.")
            await asyncio.sleep(3)
        except Exception as e:
            print(f"❌ [CONTEXT] Lỗi lấy thông tin nền {symbol}: {e}")
    print("\n--- ✅ [CONTEXT] Hoàn thành cập nhật thông tin nền ---")

# --- BỘ LỌC SƠ TUYỂN ---
async def screen_for_hot_pairs(assets: list) -> list:
    """Sơ tuyển các cặp tiền tiềm năng dựa trên xu hướng cấu trúc và biến động."""
    print("--- [SCREENER] Bắt đầu sơ tuyển các cặp tiền tiềm năng ---")
    async def get_hot_score(symbol):
        if not mt5.terminal_state():
            print("⚠️ [SCREENER] Mất kết nối MT5...");
            if not mt5_initialize(): return None
            await asyncio.sleep(1)
        price_data = await mt5_get_rates(symbol, mt5.TIMEFRAME_H4, count=250)
        if price_data.empty: return None
        vol_task = asyncio.to_thread(vola.analyze_volatility, price_data.copy())
        mtf_task = mtf.analyze_mtf(symbol, price_data)
        try:
            volatility_analysis, mtf_analysis = await asyncio.gather(vol_task, mtf_task)
        except Exception as gather_err:
             print(f"❌ [SCREENER] Lỗi gather MTF/Vol {symbol}: {gather_err}"); return None
        trend_strength = 0; final_bias = mtf_analysis.get('final_bias', 'NEUTRAL')
        if final_bias == "STRONG_BUY": trend_strength = 10
        elif final_bias == "BUY": trend_strength = 6
        elif final_bias == "STRONG_SELL": trend_strength = 10
        elif final_bias == "SELL": trend_strength = 6
        trend_strength = abs(trend_strength)
        volatility_score = 0; vol_regime = volatility_analysis.get('volatility_regime', 'MEDIUM')
        bbw_percentile = volatility_analysis.get('bbw_percentile')
        if bbw_percentile is not None: volatility_score = bbw_percentile / 10
        elif vol_regime == "HIGH": volatility_score = 8
        elif vol_regime == "MEDIUM": volatility_score = 5
        elif vol_regime == "LOW": volatility_score = 2
        is_squeeze = 1 if "SQUEEZE" in volatility_analysis.get('status', "") else 0
        is_breakout = 1 if volatility_analysis.get('is_volatility_breakout', False) else 0
        hot_score = (trend_strength * 0.6) + (volatility_score * 0.2) + (is_squeeze * 3) + (is_breakout * 5)
        return {"symbol": symbol, "hot_score": round(hot_score, 2), "price_data": price_data,
                "mtf_analysis": mtf_analysis, "volatility_analysis": volatility_analysis}
    tasks = [get_hot_score(symbol) for symbol in assets]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    valid_results = []
    for i, res in enumerate(results):
        asset_name = assets[i] if i < len(assets) else "UNKNOWN_ASSET"
        if isinstance(res, Exception): print(f"❌ [SCREENER] Lỗi xử lý {asset_name}: {res}")
        elif res is not None: valid_results.append(res)
    if not valid_results: print("⚠️ [SCREENER] Không có dữ liệu hợp lệ."); return []
    sorted_list = sorted(valid_results, key=lambda x: x['hot_score'], reverse=True)
    top_n = min(5, len(sorted_list)); top_pairs = sorted_list[:top_n]
    hot_pair_names = [p['symbol'] for p in top_pairs]
    print(f"--- [SCREENER] {top_n} cặp tiền nóng nhất: {', '.join(hot_pair_names)} ---")
    return top_pairs

# --- BỘ MÁY TỰ TRỊ (VALIDATOR) ---
def calculate_confidence_score(analyses: dict, events: list, mandate: dict) -> dict:
    """Bộ máy tự trị chấm điểm tín hiệu MUA/BÁN (Thang điểm: 0-100). EMA là phụ. Thêm Risk Sentiment."""
    buy_score = 0; sell_score = 0; veto_reason = None
    # Bộ lọc Tin tức Nâng cao
    symbol = analyses.get('symbol', ''); market_condition = analyses.get("market_condition", "TRENDING")
    if symbol:
        base_currency, quote_currency = symbol[:3], symbol[3:]; is_gold = "XAUUSD" in symbol.upper()
        currencies_to_check = {base_currency, quote_currency};
        if is_gold: currencies_to_check.add("USD")
        now = datetime.now(); no_fly_zone_cfg = mandate.get("economic_calendar_rules", {}).get("news_no_fly_zone_minutes", {"before": 15, "after": 30})
        before_minutes = no_fly_zone_cfg.get("before", 15); after_minutes = no_fly_zone_cfg.get("after", 30)
        for event in events:
            if event.get('currency') in currencies_to_check:
                impact = event.get('impact', 'LOW'); action = event.get('action', 'IGNORE')
                event_time = event.get('time')
                if not event_time: continue
                time_to_event_min = (event_time - now).total_seconds() / 60; time_since_event_min = (now - event_time).total_seconds() / 60
                if impact == "HIGH" and action == "PAUSE" and ((0 < time_to_event_min <= before_minutes) or (0 < time_since_event_min <= after_minutes)):
                    veto_reason = f"No-Fly Zone! Tin HIGH ({event['currency']}-{event.get('event','?')})"; break
                elif impact == "MEDIUM" and action == "FILTER":
                    if 0 < time_to_event_min <= 10: buy_score -= 15; sell_score -= 15; print(f"ℹ️ [SCORE FILTER] Giảm điểm: tin MEDIUM sắp tới.")
                    elif 0 < time_since_event_min <= 15: buy_score -= 5; sell_score -= 5
    if veto_reason: return {"buy_score": 0, "sell_score": 0, "veto_reason": veto_reason}

    # Chấm điểm các yếu tố khác
    liquidity_analysis = analyses.get('liquidity_analysis', {})
    mtf_result = analyses.get('mtf_analysis', {})
    cycle_analysis = analyses.get('cycle_analysis', {})
    rhythm = analyses.get('rhythm_analysis', {})
    vsa_h4 = analyses.get('vsa_analysis', {})
    vola = analyses.get('volatility_analysis', {})
    range_analysis = analyses.get('range_analysis', {})
    d1_vsa = analyses.get('d1_vsa_analysis', {})
    intermarket_trends = analyses.get('intermarket_trends', {})
    session_info = analyses.get('session_info', {})
    risk_sentiment_trends = analyses.get('risk_sentiment_trends', {})
    vp_analysis = analyses.get('volume_profile_analysis', {})
    tech_analysis_h4 = analyses.get('technical_analysis', {})
    tech_details_h4 = tech_analysis_h4.get('details', {})
    current_price = tech_details_h4.get('current_price', 0)
    symbol_info_score = mt5.symbol_info(symbol); digits = symbol_info_score.digits if symbol_info_score else 5
    price_data_h4_vp = analyses.get('price_data_h4') # Lấy data H4 để tính ATR
    atr_h4_vp = 0.0
    if isinstance(price_data_h4_vp, pd.DataFrame) and not price_data_h4_vp.empty:
        try: atr_h4_vp = calculate_atr(price_data_h4_vp.copy())
        except: pass
    if atr_h4_vp <= 0: atr_h4_vp = (tech_details_h4.get('key_resistance', current_price+0.001) - tech_details_h4.get('key_support', current_price-0.001)) * 0.1 # Fallback
    if atr_h4_vp <= 0: atr_h4_vp = 0.0001 # Fallback cuối

    # (Yếu tố 0: Sweep)
    sweep_event = liquidity_analysis.get('recent_liquidity_event')
    if sweep_event:
        if "Bullish Sweep" in sweep_event.get('type', ''): buy_score += 40
        elif "Bearish Sweep" in sweep_event.get('type', ''): sell_score += 40
    # (Yếu tố 1: MTF Bias D1/H4 - 20 điểm)
    final_bias = mtf_result.get('final_bias', 'NEUTRAL'); mtf_multiplier = 0.5 if market_condition == "SIDEWAYS" else 1.0
    if final_bias == "STRONG_BUY": buy_score += 20 * mtf_multiplier
    elif final_bias == "BUY": buy_score += 10 * mtf_multiplier
    elif final_bias == "STRONG_SELL": sell_score += 20 * mtf_multiplier
    elif final_bias == "SELL": sell_score += 10 * mtf_multiplier
    # (Yếu tố 2: Chu kỳ - 10 điểm)
    cycle = cycle_analysis.get('alignment_status', '')
    if cycle == "Đồng thuận TĂNG": buy_score += 10
    if cycle == "Đồng thuận GIẢM": sell_score += 10
    if "Cảnh báo" in cycle:
        if "TĂNG" in cycle_analysis.get('d1_zone', ''): buy_score -= 5
        if "GIẢM" in cycle_analysis.get('d1_zone', ''): sell_score -= 5
    # (Yếu tố 3: Cấu trúc Rhythm H4 - 15 điểm)
    if "Tăng" in rhythm.get('structure', ''): buy_score += 8
    if "Giảm" in rhythm.get('structure', ''): sell_score += 8
    if "Bullish BOS" in rhythm.get('last_event', ''): buy_score += 7
    elif "Bearish CHoCH" in rhythm.get('last_event', ''): sell_score += 7
    if "Bearish BOS" in rhythm.get('last_event', ''): sell_score += 7
    elif "Bullish CHoCH" in rhythm.get('last_event', ''): buy_score += 7
    # (Yếu tố 4: VSA H4 - 10 điểm)
    vsa_h4_signal = vsa_h4.get('signal', ''); vsa_h4_conf = vsa_h4.get('confidence', 'Low')
    vsa_h4_score = 10 if vsa_h4_conf == "High" else 5 if vsa_h4_conf == "Medium" else 0
    if vsa_h4_signal in ["NO SUPPLY / TEST", "STOPPING VOLUME", "EFFORT TO FALL FAILED / ABSORPTION", "TEST CONFIRMED"]: buy_score += vsa_h4_score
    if vsa_h4_signal in ["UPTHRUST", "NO DEMAND", "EFFORT TO RISE FAILED"]: sell_score += vsa_h4_score
    # (Yếu tố 5: Squeeze H4 - 5 điểm)
    if "SQUEEZE" in vola.get('status', '') and vola.get('potential_direction') == "UP": buy_score += 5
    if "SQUEEZE" in vola.get('status', '') and vola.get('potential_direction') == "DOWN": sell_score += 5
    # (Yếu tố 6: CRT D1 - 5 điểm)
    current_zone = range_analysis.get('current_zone', 'Không xác định')
    if current_zone == "Discount (Rẻ)": buy_score += 5
    elif current_zone == "Premium (Đắt)": sell_score += 5
    # (Yếu tố 7: VSA D1 - 15 điểm)
    d1_vsa_signal = d1_vsa.get('signal', ''); d1_vsa_conf = d1_vsa.get('confidence', 'Low')
    d1_vsa_score = 15 if d1_vsa_conf == "High" else 8 if d1_vsa_conf == "Medium" else 0
    if d1_vsa_signal in ["NO SUPPLY / TEST", "STOPPING VOLUME", "EFFORT TO FALL FAILED / ABSORPTION", "TEST CONFIRMED"]: buy_score += d1_vsa_score
    if d1_vsa_signal in ["UPTHRUST", "NO DEMAND", "EFFORT TO RISE FAILED"]: sell_score += d1_vsa_score
    # (Yếu tố 8: Vol Regime Filter)
    vol_regime = vola.get('volatility_regime', 'MEDIUM')
    if vol_regime == "HIGH": buy_score *= 0.8; sell_score *= 0.8
    elif vol_regime == "LOW":
        is_squeeze = "SQUEEZE" in vola.get('status', ''); is_bos = "BOS" in rhythm.get('last_event', '')
        if is_squeeze or is_bos: buy_score = min(100, buy_score + 5); sell_score = min(100, sell_score + 5)
    # (Yếu tố 9: Intermarket Filter - DXY/US10Y)
    if symbol and "XAUUSD" in symbol.upper():
        dxy_trend = intermarket_trends.get('DXY_Trend', 0); us10y_trend = intermarket_trends.get('US10Y_Trend', 0)
        if dxy_trend > 5: buy_score *= 0.7; sell_score = min(100, sell_score + 10)
        elif dxy_trend < -5: buy_score = min(100, buy_score + 10); sell_score *= 0.7
        if us10y_trend > 5: buy_score *= 0.8; sell_score = min(100, sell_score + 5)
        elif us10y_trend < -5: buy_score = min(100, buy_score + 5); sell_score *= 0.8
    # (Yếu tố 10: Session Filter - Asia Sweep)
    asia_high = session_info.get('asia_range_high'); asia_low = session_info.get('asia_range_low')
    current_session = session_info.get('current_session', '')
    if sweep_event and ("London" in current_session or "New York" in current_session):
        sweep_price = sweep_event.get('price'); tolerance = asia_high * 0.0005 if asia_high else 0.1
        if asia_high and "Bearish Sweep" in sweep_event.get('type', '') and abs(sweep_price - asia_high) < tolerance: sell_score = min(100, sell_score + 10)
        elif asia_low and "Bullish Sweep" in sweep_event.get('type', '') and abs(sweep_price - asia_low) < tolerance: buy_score = min(100, buy_score + 10)
    # (Yếu tố 11: Risk Sentiment - VIX/US30)
    if symbol and "XAUUSD" in symbol.upper():
        vix_trend = analyses.get('risk_sentiment_trends', {}).get('VIX_Trend', 0)
        us30_trend = analyses.get('risk_sentiment_trends', {}).get('US30_Trend', 0)
        risk_off_score = 0; risk_on_score = 0
        if vix_trend > 3 and us30_trend < -3: risk_off_score = 10
        elif vix_trend > 1 and us30_trend < -1: risk_off_score = 5
        if vix_trend < -3 and us30_trend > 3: risk_on_score = 10
        elif vix_trend < -1 and us30_trend > 1: risk_on_score = 5
        buy_score += risk_off_score; sell_score += risk_on_score
    # (Yếu tố 12: Volume Profile HVN/LVN Context - 10 điểm)
    hvns = vp_analysis.get('hvns', []); lvns = vp_analysis.get('lvns', []); poc = vp_analysis.get('poc')
    if current_price > 0 and hvns:
        hvn_above = min([h for h in hvns if h > current_price], default=None)
        hvn_below = max([h for h in hvns if h < current_price], default=None)
        bullish_poi = next((ob for ob in liquidity_analysis.get('bullish_obs', []) if ob.get('status') == 'unmitigated'), None)
        bearish_poi = next((ob for ob in liquidity_analysis.get('bearish_obs', []) if ob.get('status') == 'unmitigated'), None)
        hvn_proximity_threshold = atr_h4_vp * 0.3
        if bullish_poi and hvn_below and abs(bullish_poi.get('top', np.inf) - hvn_below) < hvn_proximity_threshold:
            buy_score = min(100, buy_score + 5); print(f"ℹ️ [SCORE VP] +5 Buy: Bullish POI near HVN below ({hvn_below:.{digits}f})")
        if bearish_poi and hvn_above and abs(bearish_poi.get('bottom', -np.inf) - hvn_above) < hvn_proximity_threshold:
            sell_score = min(100, sell_score + 5); print(f"ℹ️ [SCORE VP] +5 Sell: Bearish POI near HVN above ({hvn_above:.{digits}f})")
        if buy_score > sell_score:
            target_liq_buy = liquidity_analysis.get('inducement_buy_side') or min(liquidity_analysis.get('structural_buy_liq', [np.inf]))
            if target_liq_buy != np.inf and target_liq_buy > current_price and any(current_price < lvn < target_liq_buy for lvn in lvns):
                buy_score = min(100, buy_score + 5); print(f"ℹ️ [SCORE VP] +5 Buy: LVN towards Buy Liq ({target_liq_buy:.{digits}f})")
        elif sell_score > buy_score:
            target_liq_sell = liquidity_analysis.get('inducement_sell_side') or max(liquidity_analysis.get('structural_sell_liq', [-np.inf]))
            if target_liq_sell != -np.inf and target_liq_sell < current_price and any(target_liq_sell < lvn < current_price for lvn in lvns):
                sell_score = min(100, sell_score + 5); print(f"ℹ️ [SCORE VP] +5 Sell: LVN towards Sell Liq ({target_liq_sell:.{digits}f})")

    # Phạt nếu không có POI mới
    if buy_score > sell_score and not any(ob.get('status') == "unmitigated" for ob in liquidity_analysis.get("bullish_obs", [])): autonomous_buy_score = max(0, buy_score - 30)
    else: autonomous_buy_score = buy_score
    if sell_score > buy_score and not any(ob.get('status') == "unmitigated" for ob in liquidity_analysis.get("bearish_obs", [])): autonomous_sell_score = max(0, sell_score - 30)
    else: autonomous_sell_score = sell_score
    # Làm tròn
    final_buy_score = max(0, min(int(round(autonomous_buy_score)), 100))
    final_sell_score = max(0, min(int(round(autonomous_sell_score)), 100))
    return {"buy_score": final_buy_score, "sell_score": final_sell_score, "veto_reason": None}


# --- HÀM PHÂN TÍCH CHÍNH ---
async def analyze_single_symbol_strategy(symbol: str, mandate: dict, network_analysis: dict, pre_analyzed_data: dict):
    """Kết hợp AI (chính) và Tự trị (dự phòng/xác thực). Nhận diện Sideways và Risk Sentiment."""
    async with ANALYSIS_SEMAPHORE:
        print(f"--- [HYBRID] Bắt đầu phân tích kết hợp cho: {symbol.upper()} ---")
        try:
            # --- Bước 1: Thu thập tất cả dữ liệu ---
            price_data_h4 = pre_analyzed_data['price_data']
            mtf_analysis = pre_analyzed_data['mtf_analysis']
            volatility_analysis = pre_analyzed_data['volatility_analysis']

            tasks = {
                "tick_data": mt5_get_ticks_range(symbol, hours_ago=24),
                "cycle_analysis": ca.analyze_mtf_cycle(symbol),
                "range_analysis": ra.analyze_htf_range(symbol, price_data_h4['close'].iloc[-1], mt5.TIMEFRAME_D1),
                "d1_data": mt5_get_rates(symbol, mt5.TIMEFRAME_D1, count=250),
                "session_info": sa.get_session_info(symbol),
                "dxy_trend": calculate_simple_trend("DXY", mt5.TIMEFRAME_H4),
                "us10y_trend": calculate_simple_trend("US10Y", mt5.TIMEFRAME_H4),
                "vix_trend": calculate_simple_trend("VIX", mt5.TIMEFRAME_H4),
                "us30_trend": calculate_simple_trend("US30", mt5.TIMEFRAME_H4)
            }
            results = await asyncio.gather(*tasks.values(), return_exceptions=True)
            task_names = list(tasks.keys()); processed_results = {}
            for i, res in enumerate(results):
                task_name = task_names[i]
                if isinstance(res, Exception): print(f"❌ Lỗi task '{task_name}': {res}"); processed_results[task_name] = {} if task_name not in ["dxy_trend","us10y_trend","vix_trend","us30_trend"] else 0.0
                else: processed_results[task_name] = res
            tick_data=processed_results["tick_data"]; cycle_analysis=processed_results["cycle_analysis"]; range_analysis=processed_results["range_analysis"]
            d1_data=processed_results["d1_data"]; session_info=processed_results["session_info"]; dxy_trend=processed_results["dxy_trend"]; us10y_trend=processed_results["us10y_trend"]
            vix_trend = processed_results["vix_trend"]; us30_trend = processed_results["us30_trend"]

            if price_data_h4.empty: print(f"⚠️ Bỏ qua {symbol}: thiếu data H4."); return

            # Chạy các phân tích còn lại
            context_data = CONTEXT_CACHE.get(symbol, {}); narrative_analysis = context_data.get("narrative", {})
            recent_trades = await asyncio.to_thread(get_recent_trades, symbol, limit=3)
            analysis_tasks = {
                 "regime": asyncio.to_thread(mra.analyze_market_regime, price_data_h4.copy()),
                 "liquidity": asyncio.to_thread(la.analyze_liquidity, price_data_h4.copy(), d1_data.copy() if not d1_data.empty else None, volume_ma_h4=price_data_h4['tick_volume'].rolling(20).mean().iloc[-1] if 'tick_volume' in price_data_h4.columns else None),
                 "vp": asyncio.to_thread(vpa.analyze_volume_profile, tick_data.copy()),
                 "tech_h4": ta.analyze_technicals(symbol=symbol, price_data=price_data_h4), # Đã nâng cấp tech_analyzer
                 "rhythm": tra.analyze_trend_rhythm(price_data_h4.copy())
            }
            analysis_results = await asyncio.gather(*analysis_tasks.values(), return_exceptions=True)
            analysis_map = dict(zip(analysis_tasks.keys(), analysis_results))

            regime_analysis={}; liquidity_analysis={}; volume_profile_analysis={}; technical_analysis_h4={}; rhythm_analysis={}
            if isinstance(analysis_map['regime'], Exception): print(f"❌ Lỗi Regime: {analysis_map['regime']}") else: regime_analysis = analysis_map['regime']
            if isinstance(analysis_map['liquidity'], Exception): print(f"❌ Lỗi Liquidity: {analysis_map['liquidity']}") else: liquidity_analysis = analysis_map['liquidity']
            if isinstance(analysis_map['vp'], Exception): print(f"❌ Lỗi Vol Profile: {analysis_map['vp']}") else: volume_profile_analysis = analysis_map['vp']
            if isinstance(analysis_map['tech_h4'], Exception): print(f"❌ Lỗi Tech H4: {analysis_map['tech_h4']}") else: technical_analysis_h4 = analysis_map['tech_h4']
            if isinstance(analysis_map['rhythm'], Exception): print(f"❌ Lỗi Rhythm: {analysis_map['rhythm']}") else: rhythm_analysis = analysis_map['rhythm']

            tech_details_h4 = technical_analysis_h4.get('details', {})

            # Chạy VSA H4 và D1
            vsa_h4_task = asyncio.to_thread(vsa.analyze_vsa_with_context, price_data_h4.copy(), technical_analysis_h4.get('trend_status', 'ĐI NGANG'), tech_details_h4.get('key_support', 0.0), tech_details_h4.get('key_resistance', 0.0))
            vsa_d1_task = asyncio.to_thread(lambda: {"signal": "N/A D1 Data", "implication": "", "confidence": "Low"})
            if not d1_data.empty:
                 tech_d1_task = ta.analyze_technicals(symbol=symbol, timeframe=mt5.TIMEFRAME_D1, price_data=d1_data)
                 technical_analysis_d1 = await tech_d1_task; tech_details_d1 = technical_analysis_d1.get('details', {})
                 vsa_d1_task = asyncio.to_thread(vsa.analyze_vsa_with_context, d1_data.copy(), technical_analysis_d1.get('trend_status', 'ĐI NGANG'), tech_details_d1.get('key_support', 0.0), tech_details_d1.get('key_resistance', 0.0))

            leading_asset = "N/A"
            if network_analysis.get('price_dataframe') is not None and not network_analysis['price_dataframe'].empty:
                try: leading_asset = await ifm.modeler_find_leading_asset(network_analysis['price_dataframe'], symbol)
                except Exception as e_ifm: print(f"⚠️ Lỗi IFM {symbol}: {e_ifm}"); leading_asset = "Error"

            vsa_analysis_h4, vsa_analysis_d1 = await asyncio.gather(vsa_h4_task, vsa_d1_task, return_exceptions=True)
            if isinstance(vsa_analysis_h4, Exception): print(f"❌ Lỗi VSA H4: {vsa_analysis_h4}"); vsa_analysis_h4 = {}
            if isinstance(vsa_analysis_d1, Exception): print(f"❌ Lỗi VSA D1: {vsa_analysis_d1}"); vsa_analysis_d1 = {}

            # Xác định Market Condition & Range Type
            market_condition = "TRENDING"; range_type = "Static S/R Peaks"
            range_high = tech_details_h4.get('key_resistance'); range_low = tech_details_h4.get('key_support')
            if ("Đi ngang" in rhythm_analysis.get('structure', '')) or ("Phân kỳ" in mtf_analysis.get('structure_alignment', '')) or (volatility_analysis.get('volatility_regime') == "LOW"):
                market_condition = "SIDEWAYS"; print(f"🚦 [CONDITION] {symbol}: SIDEWAYS.")
                if volume_profile_analysis and volume_profile_analysis.get('vah') and volume_profile_analysis.get('val'):
                    range_high = volume_profile_analysis.get('vah'); range_low = volume_profile_analysis.get('val'); range_type = "Volume Profile VA"
                    print(f"    -> Using VA Range: {range_low} - {range_high}")

            # --- Bước 2: Đưa tất cả vào 'hồ sơ' ---
            all_analyses = {
                "symbol": symbol, "network_analysis": network_analysis, "flow_analysis": leading_asset,
                "technical_analysis": technical_analysis_h4, "cycle_analysis": cycle_analysis,
                "narrative_analysis": narrative_analysis, "regime_analysis": regime_analysis,
                "rhythm_analysis": rhythm_analysis, "recent_trades": recent_trades,
                "vsa_analysis": vsa_analysis_h4, "d1_vsa_analysis": vsa_analysis_d1,
                "mtf_analysis": mtf_analysis, "liquidity_analysis": liquidity_analysis,
                "volume_profile_analysis": volume_profile_analysis,
                "volatility_analysis": volatility_analysis, "range_analysis": range_analysis,
                "session_info": session_info,
                "intermarket_trends": {"DXY_Trend": dxy_trend, "US10Y_Trend": us10y_trend},
                "risk_sentiment_trends": {"VIX_Trend": vix_trend, "US30_Trend": us30_trend},
                "market_condition": market_condition,
                "price_data_h4": price_data_h4 # Truyền data H4 vào để scoring dùng ATR
            }

            # --- Bước 3: Chạy Bộ máy Tự trị (Validator) ---
            min_confidence = mandate.get("risk_parameters", {}).get("min_confidence_score_percent", 75)
            scores = calculate_confidence_score(all_analyses, UPCOMING_EVENTS_CACHE, mandate)
            autonomous_buy_score = scores.get('buy_score', 0); autonomous_sell_score = scores.get('sell_score', 0)
            veto_reason_score = scores.get('veto_reason')
            if autonomous_buy_score > autonomous_sell_score and not any(ob.get('status') == "unmitigated" for ob in liquidity_analysis.get("bullish_obs", [])): autonomous_buy_score = max(0, autonomous_buy_score - 30)
            if autonomous_sell_score > autonomous_buy_score and not any(ob.get('status') == "unmitigated" for ob in liquidity_analysis.get("bearish_obs", [])): autonomous_sell_score = max(0, autonomous_sell_score - 30)

            # --- Bước 4: Thử gọi Bộ não AI (Gemini) ---
            ai_action = "STAND_ASIDE"; ai_decision_json = {}; ai_failed = False; ai_thesis = "N/A"
            final_veto_reason = veto_reason_score
            if final_veto_reason: ai_failed = True; ai_thesis = f"AI skipped: {final_veto_reason}"
            else:
                try:
                    prompt_analyses = {k: v for k, v in all_analyses.items() if k != 'price_data_h4'}
                    prompt = pb.prompt_create_ultimate(**prompt_analyses, upcoming_events=UPCOMING_EVENTS_CACHE)
                    response_str = await gc.gemini_get_response(prompt)
                    if not response_str or '"error":' in response_str: raise Exception(f"Gemini error/empty: {response_str}")
                    match = re.search(r'```json\s*([\s\S]+?)\s*```', response_str, re.DOTALL)
                    if match: ai_decision_json = json.loads(match.group(1))
                    else: ai_decision_json = json.loads(response_str)
                    ai_action = ai_decision_json.get('trade_plan', {}).get('action', 'STAND_ASIDE').upper()
                    ai_thesis = ai_decision_json.get('primary_thesis', 'AI Thesis.')
                except Exception as e:
                    print(f"⚠️ [HYBRID/FAILSAFE] Gemini failed: {e}. Switching to autonomous."); ai_failed = True
                    ai_thesis = f"Gemini failed, fallback."; final_veto_reason = f"Gemini Error: {e}"

            # --- Bước 5: Logic "Hybrid-Failsafe" ---
            final_action = "STAND_ASIDE"; validation_result = ""
            if ai_failed: # FAILSAFE
                validation_result = f"Failsafe Mode ({ai_thesis})."
                if autonomous_buy_score > autonomous_sell_score and autonomous_buy_score >= min_confidence: final_action = "BUY"; validation_result += f" Auto approved BUY (Score: {autonomous_buy_score}%)."
                elif autonomous_sell_score > autonomous_buy_score and autonomous_sell_score >= min_confidence: final_action = "SELL"; validation_result += f" Auto approved SELL (Score: {autonomous_sell_score}%)."
                else: validation_result += f" Auto score low (B:{autonomous_buy_score}% S:{autonomous_sell_score}%), stand aside."
            else: # VALIDATOR
                if ai_action == "BUY":
                    if autonomous_buy_score >= min_confidence: final_action = "BUY"; validation_result = f"VALIDATED: AI(BUY)+Auto(Score:{autonomous_buy_score}%) agree."
                    else: validation_result = f"VETOED: AI(BUY) but Auto score low (Score:{autonomous_buy_score}%<{min_confidence}%)."
                elif ai_action == "SELL":
                    if autonomous_sell_score >= min_confidence: final_action = "SELL"; validation_result = f"VALIDATED: AI(SELL)+Auto(Score:{autonomous_sell_score}%) agree."
                    else: validation_result = f"VETOED: AI(SELL) but Auto score low (Score:{autonomous_sell_score}%<{min_confidence}%)."
                else: validation_result = "AI recommended STAND_ASIDE."

            # --- Bước 6: Xây dựng Kế hoạch cuối cùng ---
            decision = ai_decision_json if not ai_failed else { "asset": symbol.upper(), "primary_thesis": ai_thesis }
            if 'trade_plan' not in decision: decision['trade_plan'] = {}
            if 'confidence_analysis' not in decision: decision['confidence_analysis'] = {}
            decision['trade_plan']['action'] = final_action
            decision['confidence_analysis']['autonomous_buy_score_percent'] = autonomous_buy_score
            decision['confidence_analysis']['autonomous_sell_score_percent'] = autonomous_sell_score
            decision['confidence_analysis']['validation_result'] = validation_result
            decision['technical_analysis_details'] = tech_details_h4
            decision['liquidity_analysis_h4'] = liquidity_analysis
            decision['volatility_analysis'] = volatility_analysis
            decision['market_condition'] = market_condition
            decision['identified_range'] = {"high": range_high, "low": range_low, "poc": volume_profile_analysis.get('poc'), "type": range_type}
            decision['volume_profile_h4'] = volume_profile_analysis # Thêm full VP

            # --- Bước 7: Lưu vào Cache ---
            strategy_cache.STRATEGY_CACHE[symbol] = {"plan": decision, "timestamp": datetime.now()}
            print(f"📝 [HYBRID] Saved plan for {symbol}. [Cond:{market_condition}({range_type})] [AI:{ai_action}] [Score:B{autonomous_buy_score}%/S{autonomous_sell_score}%] [Final:{final_action}]")

        except Exception as e:
            print(f"❌ [HYBRID] Critical error analyzing {symbol}: {e}")
            strategy_cache.STRATEGY_CACHE[symbol] = {"plan": {"error": f"Engine Error: {e}"}, "timestamp": datetime.now() - timedelta(minutes=15)}


# --- HÀM ĐIỀU PHỐI CHU TRÌNH ---
async def engine_run_cycle(mandate: dict, context: ContextTypes.DEFAULT_TYPE, chat_id: str):
    """Điều phối chu trình chiến lược kết hợp."""
    print("\n--- Bắt đầu Chu trình Chiến lược Kết hợp (Hybrid) ---")
    if not mt5.terminal_state():
        print("🔴 [ENGINE] Mất kết nối MT5. Thử init...");
        if not mt5_initialize(): print("❌ Không thể init MT5."); return
        await asyncio.sleep(2)

    all_forex_pairs = mandate.get("investment_universe", {}).get("forex_pairs", [])
    if not all_forex_pairs: print("⚠️ [ENGINE] Không có forex_pairs."); return

    hot_pairs_data = await screen_for_hot_pairs(all_forex_pairs)
    if not hot_pairs_data: print("ℹ️ [ENGINE] Không có cặp tiền nóng."); return

    hot_symbols = [p['symbol'] for p in hot_pairs_data]
    intermarket_assets = mandate.get("investment_universe", {}).get("intermarket_assets", [])
    needed_intermarket = {"DXY", "US10Y", "VIX", "US30"}
    symbols_for_network = list(set(hot_symbols + intermarket_assets + list(needed_intermarket)))
    network_analysis = await mna.analyzer_market_network(symbols_for_network, timeframe=mt5.TIMEFRAME_H4, period=100)

    if network_analysis.get("image_path") and context and chat_id:
        try:
            caption = f"<b>Bản đồ Mạng lưới Thị trường</b> - {datetime.now().strftime('%H:%M')}"
            with open(network_analysis["image_path"], 'rb') as photo_file:
                 await context.bot.send_photo(chat_id=chat_id, photo=photo_file, caption=caption, parse_mode=ParseMode.HTML, disable_notification=True)
        except FileNotFoundError: print(f"⚠️ Không tìm thấy ảnh mạng lưới: {network_analysis['image_path']}")
        except Exception as e: print(f"❌ Lỗi gửi ảnh mạng lưới: {e}")

    chunk_size = 2
    asset_chunks = [hot_pairs_data[i:i + chunk_size] for i in range(0, len(hot_pairs_data), chunk_size)]
    total_chunks = len(asset_chunks)
    for i, chunk in enumerate(asset_chunks):
        symbols_in_chunk = [data['symbol'] for data in chunk]
        print(f"\n--- Xử lý lô {i+1}/{total_chunks}: {', '.join(symbols_in_chunk)} ---")
        tasks = [analyze_single_symbol_strategy(data['symbol'], mandate, network_analysis, data) for data in chunk]
        await asyncio.gather(*tasks)
        if i < total_chunks - 1:
            print(f"--- Hoàn thành lô {i+1}. Nghỉ 65 giây... ---")
            await asyncio.sleep(65)

    print("\n--- ✅ [HYBRID] Hoàn thành Chu trình Chiến lược ---")