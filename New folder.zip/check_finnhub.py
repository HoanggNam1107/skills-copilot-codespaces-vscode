# check_finnhub.py
import finnhub
from config import FINNHUB_API_KEY

print("--- Bắt đầu kiểm tra thư viện Finnhub ---")

if not FINNHUB_API_KEY or "KEY_BẠN_VỪA_LẤY_TỪ_FINNHUB" in FINNHUB_API_KEY:
    print("Lỗi: Vui lòng điền FINNHUB_API_KEY vào file config.py trước.")
else:
    try:
        finnhub_client = finnhub.Client(api_key=FINNHUB_API_KEY)
        print("✅ Khởi tạo Finnhub Client thành công.")
        
        print("\n--- Liệt kê các hàm có sẵn trong 'finnhub_client' ---")
        
        # Lấy danh sách tất cả các thuộc tính và phương thức
        all_attributes = dir(finnhub_client)
        
        # Lọc ra các phương thức public (không có dấu gạch dưới ở đầu)
        public_methods = [method for method in all_attributes if not method.startswith('_')]
        
        # In ra để kiểm tra
        print("Các hàm tìm thấy:")
        for method in sorted(public_methods):
            print(f"- {method}")

        print("\n--- KIỂM TRA HÀM QUAN TRỌNG ---")
        if 'economic_calendar' in public_methods:
            print("✅ HÀM 'economic_calendar' CÓ TỒN TẠI!")
        else:
            print("❌ HÀM 'economic_calendar' KHÔNG TỒN TẠI!")
            # Gợi ý tên có thể đúng
            for method in public_methods:
                if 'calendar' in method and 'economic' in method:
                    print(f"Gợi ý: Có một hàm tên là '{method}', có thể đây là hàm đúng?")


    except Exception as e:
        print(f"Đã xảy ra lỗi trong quá trình kiểm tra: {e}")

print("\n--- Kiểm tra hoàn tất ---")