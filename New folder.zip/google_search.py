# File: google_search.py
# Nội dung này định nghĩa hàm search để chương trình có thể import.

def search(query, num=5):
    """
    Hàm này tồn tại để chương trình không bị lỗi import.
    Nó sẽ không làm gì cả và trả về một danh sách rỗng.
    """
    print(f"⚠️  Tạm thời bỏ qua tìm kiếm Google cho: '{query}'")
    return [] # Luôn trả về một danh sách rỗng