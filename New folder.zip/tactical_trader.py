# tactical_trader.py (Phiên bản cuối: Refined M1 Entry + Confirmation + News/Vol Filter + Sideways + Adaptive M1 Vol)
# -*- coding: utf-8 -*-
import asyncio
from datetime import datetime, timedelta
import pandas as pd
import MetaTrader5 as mt5
import strategy_cache
import data_handler as dh
import trade_executor as te
import system_state
import json
from autonomous_engine import UPCOMING_EVENTS_CACHE # Import cache tin tức
import trend_rhythm_analyzer as tra
from liquidity_analyzer import analyze_liquidity
# --- NÂNG CẤP: Import VSA ---
import vsa_analyzer as vsa
# import volume_profile_analyzer as vpa # Tạm thời chưa dùng VPA trong tactical
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
import pandas_ta as ta # Import pandas_ta
import numpy as np # Import numpy

MIN_OB_SCORE_H4 = 7.0
MIN_OB_SCORE_M1 = 5.0

# --- Hàm kiểm tra nến xác nhận ---
def is_confirmation_candle(df_m1: pd.DataFrame, direction: str) -> tuple[bool, str]:
    """Kiểm tra xem 2 nến M1 cuối cùng có tạo thành mẫu xác nhận không."""
    if len(df_m1) < 2: return False, "Thiếu dữ liệu nến M1"
    candles_to_check = df_m1.tail(2).copy()
    ohlc_map = {'open': 'Open', 'high': 'High', 'low': 'Low', 'close': 'Close'}
    candles_to_check.rename(columns={k: v for k, v in ohlc_map.items() if k in candles_to_check.columns}, inplace=True)
    if not all(col in candles_to_check.columns for col in ['Open', 'High', 'Low', 'Close']): return False, "Thiếu cột OHLC"
    try:
        cdl_names = ["ENGULFING", "HAMMER", "SHOOTINGSTAR", "MORNINGSTAR", "EVENINGSTAR"]
        candles_to_check.ta.cdl_pattern(name=cdl_names, append=True)
    except Exception as e_cdl: print(f"⚠️ Lỗi cdl_pattern: {e_cdl}"); return False, "Lỗi nhận diện nến"
    last_candle_patterns = candles_to_check.iloc[-1]; last_c = candles_to_check.iloc[-1]; prev_c = candles_to_check.iloc[-2]
    body_size = abs(last_c['Close'] - last_c['Open']); range_size = last_c['High'] - last_c['Low']
    is_marubozu = range_size > 1e-9 and body_size / range_size > 0.9 # Thêm kiểm tra range_size > 0 nhỏ
    if direction == "BUY":
        if last_candle_patterns.get("CDL_ENGULFING", 0) > 0 and last_c['Close'] > prev_c['High']: return True, "Bullish Engulfing M1"
        if last_candle_patterns.get("CDL_HAMMER", 0) > 0: return True, "Hammer M1"
        if last_candle_patterns.get("CDL_MORNINGSTAR", 0) > 0: return True, "Morning Star M1"
        if is_marubozu and last_c['Close'] > last_c['Open']: return True, "Bullish Marubozu M1"
    elif direction == "SELL":
        if last_candle_patterns.get("CDL_ENGULFING", 0) < 0 and last_c['Close'] < prev_c['Low']: return True, "Bearish Engulfing M1"
        if last_candle_patterns.get("CDL_SHOOTINGSTAR", 0) < 0: return True, "Shooting Star M1"
        if last_candle_patterns.get("CDL_EVENINGSTAR", 0) < 0: return True, "Evening Star M1"
        if is_marubozu and last_c['Close'] < last_c['Open']: return True, "Bearish Marubozu M1"
    return False, "Không có nến xác nhận M1"


# --- Hàm kiểm tra xác nhận Delta/VSA tại biên độ ---
async def check_sideways_confirmation(symbol: str, sweep_direction: str, trigger_candle_index: int, m1_data: pd.DataFrame) -> tuple[bool, str]:
    """Kiểm tra VSA trên M1 tại thời điểm quét biên độ."""
    if len(m1_data) < trigger_candle_index + 1 or trigger_candle_index < 2: return False, "Dữ liệu M1 không đủ"
    start_idx = max(0, trigger_candle_index - 2); end_idx = trigger_candle_index + 1
    relevant_m1_data_vsa = m1_data.iloc[start_idx:end_idx].copy()
    vsa_signal = ""; vsa_confidence = "Low"
    try:
        # Chạy VSA trong thread
        vsa_result_trigger = await asyncio.to_thread(
            vsa.analyze_vsa_with_context, relevant_m1_data_vsa
        )
        vsa_signal = vsa_result_trigger.get("signal", ""); vsa_confidence = vsa_result_trigger.get("confidence", "Low")
    except Exception as e_vsa_m1: print(f"⚠️ Lỗi VSA M1 confirm: {e_vsa_m1}")
    delta_confirmation = True; delta_reason = "(Delta chưa check)" # Tạm thời bỏ qua Delta check
    confirmation_met = False; confirmation_reason = ""
    if sweep_direction == "SELL":
        if vsa_signal in ["UPTHRUST", "EFFORT TO RISE FAILED", "NO DEMAND"] and vsa_confidence != "Low": confirmation_met = True; confirmation_reason = f"VSA Weakness ({vsa_signal}) {delta_reason}"
    elif sweep_direction == "BUY":
        if vsa_signal in ["STOPPING VOLUME", "EFFORT TO FALL FAILED / ABSORPTION", "NO SUPPLY / TEST", "TEST CONFIRMED"] and vsa_confidence != "Low": confirmation_met = True; confirmation_reason = f"VSA Strength ({vsa_signal}) {delta_reason}"
    return confirmation_met, confirmation_reason


async def run_tactical_cycle(mandate: dict, context: ContextTypes.DEFAULT_TYPE, chat_id: str):
    """Chu trình Phân tích Nhẹ (Forex), chạy mỗi 15 giây."""
    if system_state.get_status() != "ACTIVE_TRADING": return
    if not strategy_cache.STRATEGY_CACHE: return
    try:
        # Tải lại mandate trong mỗi chu kỳ để cập nhật thay đổi (nếu có)
        with open("mandate.json", "r", encoding="utf-8") as f: current_mandate = json.load(f)
    except Exception as e: print(f"❌ [TACTICAL] Lỗi tải mandate.json: {e}"); return
    symbols_to_check = list(strategy_cache.STRATEGY_CACHE.items())
    # Chạy tuần tự để giảm tải API MT5
    for symbol, data in symbols_to_check:
        if symbol in strategy_cache.STRATEGY_CACHE: # Kiểm tra lại cache
            current_data = strategy_cache.STRATEGY_CACHE[symbol]
            await check_and_execute_fractal_entry(symbol, current_data, current_mandate, context, chat_id)
            await asyncio.sleep(0.5) # Nghỉ ngắn


async def check_and_execute_fractal_entry(symbol: str, strategy_data: dict, mandate: dict, context: ContextTypes.DEFAULT_TYPE, chat_id: str):
    """Thực hiện logic Fractal Entry HOẶC Range Deviation với Bộ lọc Tin tức/Biến động Thích ứng."""
    try:
        # --- Bước 0: Kiểm tra Cache, Plan, Action, Tin tức ---
        if datetime.now() - strategy_data.get('timestamp', datetime.min) > timedelta(hours=2):
            if symbol in strategy_cache.STRATEGY_CACHE: del strategy_cache.STRATEGY_CACHE[symbol]; return
        plan = strategy_data.get('plan', {}); action = plan.get('trade_plan', {}).get('action', 'STAND_ASIDE').upper()
        if plan.get("error") or action not in ["BUY", "SELL"]:
             if plan.get("error") and symbol in strategy_cache.STRATEGY_CACHE: del strategy_cache.STRATEGY_CACHE[symbol]
             return
        # Bộ lọc No-Fly Zone
        now = datetime.now(); no_fly_zone_cfg = mandate.get("economic_calendar_rules", {}).get("news_no_fly_zone_minutes", {"before": 15, "after": 30})
        before_minutes = no_fly_zone_cfg.get("before", 15); after_minutes = no_fly_zone_cfg.get("after", 30)
        base_currency, quote_currency = symbol[:3], symbol[3:]; is_gold = "XAUUSD" in symbol.upper()
        currencies_to_check = {base_currency, quote_currency};
        if is_gold: currencies_to_check.add("USD")
        for event in UPCOMING_EVENTS_CACHE: # Cache này chứa cả impact và action
            if event.get('currency') in currencies_to_check:
                impact = event.get('impact', 'LOW'); event_time = event.get('time')
                if not event_time: continue # Bỏ qua nếu event không có time
                time_to_event_min = (event_time - now).total_seconds() / 60; time_since_event_min = (now - event_time).total_seconds() / 60
                if impact == "HIGH" and ((0 < time_to_event_min <= before_minutes) or (0 < time_since_event_min <= after_minutes)):
                    print(f"🚫 [TACTICAL] {symbol}: BỎ QUA do 'No-Fly Zone' tin HIGH ({event['currency']}-{event.get('event','?')})."); return

        # --- Xác định Chiến lược & Range ---
        market_condition = plan.get("market_condition", "TRENDING")
        identified_range = plan.get("identified_range", {})
        range_high = identified_range.get("high"); range_low = identified_range.get("low")
        range_poc = identified_range.get("poc"); range_type = identified_range.get("type", "Static S/R")

        execute_trade_flag = False; final_trigger_reason = ""
        m1_data = await dh.mt5_get_rates(symbol, mt5.TIMEFRAME_M1, count=100)
        if m1_data.empty or len(m1_data) < 5: return # Cần nhiều nến hơn để check vol

        confirmation_candle_idx = -1; trigger_candle_idx = -2; prev_trigger_candle_idx = -3
        # Đảm bảo index hợp lệ
        if abs(confirmation_candle_idx) > len(m1_data) or abs(trigger_candle_idx) > len(m1_data) or abs(prev_trigger_candle_idx) > len(m1_data):
             print(f"⚠️ [TACTICAL] {symbol}: Không đủ nến M1 ({len(m1_data)}) để phân tích sequence."); return

        confirmation_candle = m1_data.iloc[confirmation_candle_idx]
        trigger_candle = m1_data.iloc[trigger_candle_idx]
        prev_trigger_candle = m1_data.iloc[prev_trigger_candle_idx]

        # --- Logic cho Thị trường SIDEWAYS ---
        if market_condition == "SIDEWAYS" and range_high and range_low:
            print(f"🚦 [TACTICAL] {symbol}: SIDEWAYS ({range_type} Range {range_low}-{range_high}). Tìm Deviation/Reversal...")
            sideways_trigger = False; sideways_direction = None; trigger_reason_base = ""
            # 1. Kiểm tra Range Deviation
            sweep_high = trigger_candle['high'] > range_high and trigger_candle['close'] < range_high
            sweep_low = trigger_candle['low'] < range_low and trigger_candle['close'] > range_low
            symbol_info_sideways = mt5.symbol_info(symbol); digits_r = symbol_info_sideways.digits if symbol_info_sideways else 5 # Lấy digits để format
            if action == "SELL" and sweep_high: sideways_trigger = True; sideways_direction = "SELL"; trigger_reason_base = f"Quét {range_type} High ({range_high:.{digits_r}f})"
            elif action == "BUY" and sweep_low: sideways_trigger = True; sideways_direction = "BUY"; trigger_reason_base = f"Quét {range_type} Low ({range_low:.{digits_r}f})"

            # 2. NẾU CÓ SWEEP DEVIATION -> KIỂM TRA VSA/DELTA CONFIRMATION
            if sideways_trigger:
                 vsa_delta_confirmed, vsa_delta_reason = await check_sideways_confirmation(symbol, sideways_direction, trigger_candle_idx, m1_data)
                 if vsa_delta_confirmed:
                      print(f"👍 [SIDEWAYS CONFIRM] {symbol}: {trigger_reason_base} confirmed by {vsa_delta_reason}.")
                      # 3. CHỜ NẾN XÁC NHẬN M1
                      is_confirmed, confirmation_reason = await asyncio.to_thread(is_confirmation_candle, m1_data.tail(2), sideways_direction)
                      if is_confirmed:
                           execute_trade_flag = True
                           final_trigger_reason = f"{trigger_reason_base} ({vsa_delta_reason}) + {confirmation_reason} (SIDEWAYS Strategy)."
                      # else: print(f"⏳ [SIDEWAYS] {symbol}: Đã quét & confirm VSA/Delta, chờ nến M1 xác nhận...")
                 # else: print(f"👎 [SIDEWAYS REJECT] {symbol}: {trigger_reason_base} KHÔNG được VSA/Delta xác nhận.")

            # (Có thể thêm logic Value Area Mean Reversion ở đây)

        # --- Logic cho Thị trường TRENDING (Fractal Entry cũ, đã có Refined M1) ---
        if not execute_trade_flag and market_condition == "TRENDING":
            # (Logic Bước 1 & 2: Tìm POI H4, Chờ giá vào, Tìm CHoCH M15)
            liquidity_analysis_h4 = plan.get('liquidity_analysis_h4', {}); poi_zone_h4 = None;
            ob_list_h4 = liquidity_analysis_h4.get('bullish_obs', []) if action == "BUY" else liquidity_analysis_h4.get('bearish_obs', [])
            valid_obs_h4 = [ob for ob in ob_list_h4 if ob.get('status') == 'unmitigated' and ob.get('score', 0) >= MIN_OB_SCORE_H4]
            if valid_obs_h4:
                extreme_obs = [ob for ob in valid_obs_h4 if "Extreme POI" in ob.get("reasons", [])];
                if extreme_obs: poi_zone_h4 = sorted(extreme_obs, key=lambda x: x.get('score', 0), reverse=True)[0]
                else: poi_zone_h4 = sorted(valid_obs_h4, key=lambda x: x.get('score', 0), reverse=True)[0]
            if not poi_zone_h4: return

            m15_data = await dh.mt5_get_rates(symbol, mt5.TIMEFRAME_M15, count=150);
            if m15_data.empty or len(m15_data) < 50: return
            last_low_m15 = m15_data['low'].iloc[-1]; last_high_m15 = m15_data['high'].iloc[-1]; price_in_poi = False;
            atr_h4 = 0.0; price_data_h4 = pre_analyzed_data.get('price_data') # Lấy lại price data H4
            try:
                 # Cần thêm kiểm tra price_data_h4 không phải None và là DataFrame
                 if price_data_h4 is not None and isinstance(price_data_h4, pd.DataFrame) and not price_data_h4.empty:
                      atr_h4 = calculate_atr(price_data_h4.copy())
                 else:
                     print(f"⚠️ [TACTICAL] Không có price_data_h4 hợp lệ để tính ATR.")
            except Exception as e_atr_h4: print(f"⚠️ Lỗi tính ATR H4: {e_atr_h4}")
            symbol_info_t = mt5.symbol_info(symbol)
            poi_buffer = atr_h4 * 0.1 if atr_h4 > 0 else symbol_info_t.point * 5 if symbol_info_t else 0.00005
            poi_top = poi_zone_h4.get('top'); poi_bottom = poi_zone_h4.get('bottom')
            if poi_top is not None and poi_bottom is not None:
                if action == "BUY" and last_low_m15 <= poi_top + poi_buffer and last_high_m15 >= poi_bottom - poi_buffer: price_in_poi = True
                elif action == "SELL" and last_high_m15 >= poi_bottom - poi_buffer and last_low_m15 <= poi_top + poi_buffer: price_in_poi = True
            if not price_in_poi: return

            m15_structure = await asyncio.to_thread(tra.analyze_trend_rhythm, m15_data.copy());
            last_event_m15 = m15_structure.get("last_event", ""); m15_choch_confirmed = False
            if action == "BUY" and "Bullish CHoCH" in last_event_m15: m15_choch_confirmed = True
            elif action == "SELL" and "Bearish CHoCH" in last_event_m15: m15_choch_confirmed = True
            if not m15_choch_confirmed: return

            # (Logic Bước 3: Tìm Tín hiệu M1 Ban đầu + Nến Xác nhận)
            m1_liquidity_data = m1_data.head(len(m1_data)-1)
            m1_liquidity = await asyncio.to_thread(la.analyze_liquidity, m1_liquidity_data.copy(), lookback=50)
            entry_trigger_found = False; trigger_reason_base = ""
            # (Sweep M1)
            is_bullish_sweep = trigger_candle['low'] < prev_trigger_candle['low'] and trigger_candle['close'] > prev_trigger_candle['low']
            is_bearish_sweep = trigger_candle['high'] > prev_trigger_candle['high'] and trigger_candle['close'] < prev_trigger_candle['high']
            digits_t = symbol_info_t.digits if symbol_info_t else 5
            if action == "BUY" and is_bullish_sweep: entry_trigger_found = True; trigger_reason_base = f"M1 Bullish Sweep tại {prev_trigger_candle['low']:.{digits_t}f}"
            elif action == "SELL" and is_bearish_sweep: entry_trigger_found = True; trigger_reason_base = f"M1 Bearish Sweep tại {prev_trigger_candle['high']:.{digits_t}f}"
            # (FVG Mit M1)
            if not entry_trigger_found:
                 unfilled_fvgs_m1 = [fvg for fvg in m1_liquidity.get("fvgs", []) if fvg.get('status') != "Fully Filled"]
                 if unfilled_fvgs_m1:
                     relevant_fvgs_m1 = [fvg for fvg in unfilled_fvgs_m1 if (action == "BUY" and fvg.get('type') == 'bullish') or (action == "SELL" and fvg.get('type') == 'bearish')]
                     if relevant_fvgs_m1:
                         relevant_fvgs_m1.sort(key=lambda x: min(abs(trigger_candle['close'] - x.get('top',np.inf)), abs(trigger_candle['close'] - x.get('bottom',-np.inf))))
                         closest_fvg_m1 = relevant_fvgs_m1[0]
                         mitigated = (action == "BUY" and trigger_candle['low'] <= closest_fvg_m1.get('top', np.inf)) or \
                                     (action == "SELL" and trigger_candle['high'] >= closest_fvg_m1.get('bottom', -np.inf))
                         if mitigated: entry_trigger_found = True; trigger_reason_base = f"M1 FVG Mit ({closest_fvg_m1.get('bottom',0):.{digits_t}f}-{closest_fvg_m1.get('top',0):.{digits_t}f})"
            # (OB Touch M1)
            if not entry_trigger_found:
                 ob_list_m1 = m1_liquidity.get('bullish_obs', []) if action == "BUY" else m1_liquidity.get('bearish_obs', [])
                 valid_obs_m1 = [ob for ob in ob_list_m1 if ob.get('status') == 'unmitigated' and ob.get('score', 0) >= MIN_OB_SCORE_M1]
                 if valid_obs_m1:
                     valid_obs_m1.sort(key=lambda x: min(abs(trigger_candle['close'] - x.get('top',np.inf)), abs(trigger_candle['close'] - x.get('bottom',-np.inf))))
                     entry_zone_m1 = valid_obs_m1[0]
                     price_touched_m1_ob = (action == "BUY" and trigger_candle['low'] <= entry_zone_m1.get('top', np.inf) and trigger_candle['high'] >= entry_zone_m1.get('bottom', -np.inf)) or \
                                           (action == "SELL" and trigger_candle['high'] >= entry_zone_m1.get('bottom', -np.inf) and trigger_candle['low'] <= entry_zone_m1.get('top', np.inf))
                     if price_touched_m1_ob: entry_trigger_found = True; trigger_reason_base = f"Chạm M1 OB ({entry_zone_m1.get('bottom',0):.{digits_t}f}-{entry_zone_m1.get('top',0):.{digits_t}f})"

            # Kiểm tra nến xác nhận
            if entry_trigger_found:
                is_confirmed, confirmation_reason = await asyncio.to_thread(is_confirmation_candle, m1_data.tail(2), action)
                if is_confirmed:
                    execute_trade_flag = True # Đặt cờ để thực thi
                    final_trigger_reason = f"{trigger_reason_base} + {confirmation_reason} (TRENDING Strategy)."
                # else: print(f"⏳ [TRENDING] {symbol}: Đã có '{trigger_reason_base}', chờ nến M1 xác nhận...")

        # --- Bước 4: Kiểm tra Biến động Tức thời & Thực thi Lệnh ---
        if execute_trade_flag:
            # --- Bộ lọc Biến động Tức thời Thích ứng ---
            vol_check_cfg = mandate.get("tactical_filters", {}).get("instant_volatility_check", {})
            vol_check_enabled = vol_check_cfg.get("enabled", False)
            vol_check_passed = True # Mặc định là vượt qua nếu bị tắt

            if vol_check_enabled:
                vol_check_tf_str = vol_check_cfg.get("timeframe", "M1").upper()
                vol_check_tf = mt5.TIMEFRAME_M1
                if vol_check_tf_str == "M5": vol_check_tf = mt5.TIMEFRAME_M5
                # (Thêm các timeframe khác nếu muốn)

                vol_check_bars = 30; vol_check_period = vol_check_cfg.get("atr_period", 14)
                vol_check_ma_period = vol_check_cfg.get("atr_ma_period", 20)
                # Lấy ngưỡng dựa trên H4 Regime từ plan
                h4_vol_regime = plan.get('volatility_analysis', {}).get('volatility_regime', 'MEDIUM')
                threshold_map = vol_check_cfg.get("threshold_by_h4_regime", {"LOW": 2.5, "MEDIUM": 3.5, "HIGH": 4.5})
                vol_check_threshold = threshold_map.get(h4_vol_regime, 3.5) # Default là MEDIUM

                # Lấy dữ liệu cho khung check vol
                vol_data = m1_data if vol_check_tf == mt5.TIMEFRAME_M1 else \
                           await dh.mt5_get_rates(symbol, vol_check_tf, count=vol_check_period + vol_check_ma_period + 5) # Lấy dư

                if not vol_data.empty and len(vol_data) >= vol_check_period + vol_check_ma_period:
                    try:
                        # Hàm calc_vol_check để chạy trong thread
                        def calc_vol_check(df_vol):
                            df_vol = df_vol.copy() # Tạo bản sao
                            ohlc_map_vol = {'open': 'Open', 'high': 'High', 'low': 'Low', 'close': 'Close'}
                            df_vol.rename(columns={k: v for k, v in ohlc_map_vol.items() if k in df_vol.columns}, inplace=True)
                            if not all(c in df_vol.columns for c in ['Open','High','Low','Close']): return None, None
                            # Tính ATR bằng pandas_ta
                            try: # Bọc try-except cho ta.atr
                                atr_df = df_vol.ta.atr(length=vol_check_period, append=False) # Không gắn vào df gốc
                                if atr_df is None or atr_df.empty: return None, None
                                # Tên cột ATR có thể thay đổi tùy phiên bản pandas_ta
                                atr_col_name = next((col for col in atr_df.columns if col.startswith(f'ATRr_{vol_check_period}')), None)
                                if not atr_col_name: return None, None # Không tìm thấy cột ATR
                                current = atr_df[atr_col_name].iloc[-1]
                                # Tính SMA của ATR
                                atr_sma = atr_df[atr_col_name].rolling(window=vol_check_ma_period).mean()
                                average = atr_sma.iloc[-1]
                                return current if pd.notna(current) else None, average if pd.notna(average) else None
                            except Exception as e_ta_atr:
                                 print(f"⚠️ Lỗi ta.atr: {e_ta_atr}")
                                 return None, None

                        current_atr, average_atr = await asyncio.to_thread(calc_vol_check, vol_data)

                        if current_atr is not None and average_atr is not None and average_atr > 1e-9: # Thêm kiểm tra > 0 nhỏ
                             symbol_info_v = mt5.symbol_info(symbol); digits_vol = symbol_info_v.digits if symbol_info_v else 5
                             if current_atr > average_atr * vol_check_threshold:
                                 print(f"🚫 [TACTICAL/Vol Filter] {symbol}: BỎ QUA do Vol {mt5.timeframe_to_string(vol_check_tf)} cao! (ATR {current_atr:.{digits_vol}f} > {average_atr:.{digits_vol}f} * {vol_check_threshold} [H4:{h4_vol_regime}])")
                                 vol_check_passed = False # Đánh dấu không vượt qua
                        # else: print(f"ℹ️ [TACTICAL] Không đủ dữ liệu ATR SMA cho {symbol} {mt5.timeframe_to_string(vol_check_tf)}.")

                    except Exception as e_atr: print(f"⚠️ Lỗi tính ATR {mt5.timeframe_to_string(vol_check_tf)}: {e_atr}")
                # else: print(f"ℹ️ [TACTICAL] Không đủ dữ liệu {mt5.timeframe_to_string(vol_check_tf)} để check vol.")
            # --- Kết thúc bộ lọc biến động ---

            # --- Thực thi Lệnh ---
            if vol_check_passed:
                if system_state.get_status() == "ACTIVE_TRADING":
                    print(f"🚀 [EXECUTOR] Trạng thái ACTIVE. Gửi lệnh {action} {symbol}...")
                    result = await te.execute_trade(symbol=symbol, action=action, mandate=mandate, entry_analysis=plan)
                    # Gửi thông báo Telegram
                    if context and chat_id:
                        result_status = result.get("status", "error"); result_msg = result.get("message", "N/A")
                        icon = "✅" if result_status == "success" else "⚠️" if result_status in ["skipped", "warning", "simulated"] else "❌"
                        text = ( f"<b>{icon} BÁO CÁO BẮN TỈA {icon}</b>\n"
                                 f"<b>Tài sản:</b> <code>{symbol}</code>\n"
                                 f"<b>Hành động:</b> <code>{action}</code>\n"
                                 f"<b>Lý do:</b> <i>{final_trigger_reason}</i>\n"
                                 f"<b>Executor:</b> {result_status.upper()} - {result_msg}" )
                        if len(text) > 4000: text = text[:4000] + "..."
                        notify = result_status not in ["simulated", "warning", "skipped"]
                        await context.bot.send_message(chat_id=chat_id, text=text, parse_mode=ParseMode.HTML, disable_notification=not notify)
                    # Xóa khỏi cache nếu lệnh được xử lý (gửi, skip, lỗi...)
                    if symbol in strategy_cache.STRATEGY_CACHE and result_status != "pending": # Giữ lại nếu đang chờ xử lý
                        del strategy_cache.STRATEGY_CACHE[symbol]; print(f"🗑️ Đã xóa {symbol} khỏi cache.")
                else: print(f"ℹ️ Tín hiệu {action} {symbol} bị bỏ qua do trạng thái '{system_state.get_status()}'.")

    # Xử lý lỗi Exception tổng quát
    except Exception as e:
        print(f"❌ [TACTICAL] Lỗi nghiêm trọng xử lý {symbol}: {e}")
        # Ghi lỗi vào cache
        if symbol in strategy_cache.STRATEGY_CACHE:
             # Đảm bảo plan tồn tại trước khi ghi lỗi
             if "plan" not in strategy_cache.STRATEGY_CACHE[symbol]: strategy_cache.STRATEGY_CACHE[symbol]["plan"] = {}
             # Chỉ ghi lỗi nếu chưa có lỗi trước đó từ engine
             if "error" not in strategy_cache.STRATEGY_CACHE[symbol].get("plan",{}):
                  # Sử dụng setdefault để tạo key nếu chưa có
                  strategy_cache.STRATEGY_CACHE[symbol].setdefault("plan", {})["error"] = f"Tactical Error: {e}"
             # Đánh dấu cũ để engine có thể phân tích lại sớm hơn
             strategy_cache.STRATEGY_CACHE[symbol]["timestamp"] = datetime.now() - timedelta(minutes=15)