# trade_executor.py (Phiên bản Cuối + Slippage Adjustment - LỆNH THẬT ĐÃ KÍCH HOẠT)
# -*- coding: utf-8 -*-
import MetaTrader5 as mt5
import pandas as pd
import numpy as np
from datetime import datetime, timedelta # Import timedelta
import database as db
import json
import asyncio
from data_handler import mt5_get_rates # Import hàm lấy rates
# --- NÂNG CẤP: Import hàm modify_position_sltp từ trade_manager ---
# (Để tránh import vòng tròn, hàm này nên được chuyển sang một file helper riêng,
# nhưng để đơn giản, tạm thời import từ trade_manager)
try:
    from trade_manager import modify_position_sltp
except ImportError:
    print("⚠️ [EXECUTOR] Cảnh báo: Không thể import modify_position_sltp từ trade_manager. Logic điều chỉnh SL/TP sau slippage sẽ bị vô hiệu hóa.")
    # Định nghĩa hàm giả để tránh lỗi
    async def modify_position_sltp(position_ticket: int, symbol: str, sl: float = None, tp: float = None):
        print(" -> Hàm modify_position_sltp giả lập được gọi.")
        await asyncio.sleep(0) # Chỉ để làm nó thành async
        return False # Giả lập thất bại
# --- Kết thúc nâng cấp import ---


async def get_rates_for_atr(symbol, timeframe=mt5.TIMEFRAME_H4, count=20):
    """Hàm phụ trợ lấy dữ liệu giá gần đây để tính ATR."""
    return await mt5_get_rates(symbol, timeframe, count)

def calculate_atr(df: pd.DataFrame, period=14) -> float:
    """Hàm phụ trợ tính Average True Range (ATR)."""
    if df.empty or len(df) < period + 1: return 0.0
    df = df.copy()
    if not all(col in df.columns for col in ['high', 'low', 'close']): return 0.0
    df['high_low'] = df['high'] - df['low']
    df['high_close'] = np.abs(df['high'] - df['close'].shift())
    df['low_close'] = np.abs(df['low'] - df['close'].shift())
    df['tr'] = df[['high_low', 'high_close', 'low_close']].max(axis=1)
    atr = df['tr'].ewm(span=period, adjust=False).mean().iloc[-1]
    return atr if pd.notna(atr) else 0.0

async def execute_trade(symbol: str, action: str, mandate: dict, entry_analysis: dict):
    """
    Thực thi giao dịch, xác nhận khớp lệnh, và TỰ ĐỘNG ĐIỀU CHỈNH SL/TP nếu có trượt giá đáng kể.
    """
    print(f"🚀 [EXECUTOR] Bắt đầu xử lý yêu cầu {action} {symbol} với Slippage Adjustment.")
    # Ngưỡng chấp nhận trượt giá (tính theo % thay đổi rủi ro)
    slippage_risk_tolerance_percent = 10.0 # Ví dụ: Chấp nhận rủi ro thay đổi tối đa 10%

    # --- Lấy thông tin symbol, account, tick (Giữ nguyên) ---
    symbol_info = mt5.symbol_info(symbol)
    if not symbol_info: print(f"❌ [EX] No symbol info {symbol}."); return {"status": "error", "message": f"No symbol info {symbol}."}
    account_info = mt5.account_info()
    if not account_info: print("❌ [EX] No account info."); return {"status": "error", "message": "No account info."}
    tick = mt5.symbol_info_tick(symbol)
    if not tick: print(f"❌ [EX] No tick {symbol}."); return {"status": "error", "message": f"No tick {symbol}."}
    requested_price = tick.ask if action == "BUY" else tick.bid # Lưu lại giá yêu cầu
    if requested_price == 0: print(f"❌ [EX] Invalid price {symbol}."); return {"status": "error", "message": f"Invalid price {symbol}."}
    digits = symbol_info.digits

    # --- Bộ lọc Spread (Nâng cấp 1) ---
    max_spread_points = mandate.get("risk_parameters", {}).get("max_spread_points", 30) # Lấy từ mandate, default 30 points (3 pips)
    current_spread_points = tick.spread
    if current_spread_points > max_spread_points:
        print(f"🚫 [EXECUTOR] Bỏ qua lệnh do Spread quá cao! ({current_spread_points} > {max_spread_points} points)")
        return {"status": "skipped", "message": f"Spread quá cao ({current_spread_points} points)"}
    # --- Kết thúc bộ lọc Spread ---

    # --- Lấy hệ số nhân SL/TP động (Giữ nguyên) ---
    risk_params = mandate.get("risk_parameters", {})
    volatility_analysis = entry_analysis.get('volatility_analysis', {})
    vol_regime = volatility_analysis.get('volatility_regime', 'MEDIUM')
    sl_multiplier = risk_params.get("sl_atr_multiplier", 2.0); tp_multiplier = risk_params.get("tp_atr_multiplier", 3.0)
    is_gold = "XAUUSD" in symbol.upper()
    if is_gold:
        xau_multipliers = risk_params.get("xauusd_specific_multipliers", {})
        regime_key = f"{vol_regime.upper()}_VOL" if vol_regime != "UNKNOWN" else "MEDIUM_VOL"
        regime_settings = xau_multipliers.get(regime_key)
        if regime_settings:
            sl_multiplier = regime_settings.get("sl", sl_multiplier); tp_multiplier = regime_settings.get("tp", tp_multiplier)
            print(f"ℹ️ [EX] Using XAU multipliers ({vol_regime}): SL x{sl_multiplier:.1f}, TP x{tp_multiplier:.1f}")

    # --- Tính ATR H4 và SL/TP ban đầu (Giữ nguyên) ---
    rates_df_h4 = await get_rates_for_atr(symbol, mt5.TIMEFRAME_H4, count=20)
    current_atr_h4 = calculate_atr(rates_df_h4, period=14)
    if current_atr_h4 <= 0.0: print(f"❌ [EX] Cannot calc ATR H4 {symbol}."); return {"status": "error", "message": f"Cannot calc ATR H4 {symbol}."}
    initial_sl_distance_atr = sl_multiplier * current_atr_h4
    initial_stop_loss = requested_price - initial_sl_distance_atr if action == "BUY" else requested_price + initial_sl_distance_atr
    initial_stop_loss = round(initial_stop_loss, digits)
    # (Tính TP động hoặc fallback)
    initial_take_profit = 0.0; liquidity_details = entry_analysis.get('liquidity_analysis_h4', {})
    # (Logic tính TP động giữ nguyên) ...
    if action == "BUY":
        unmitigated_bearish_obs = [ob for ob in liquidity_details.get('bearish_obs', []) if ob.get('status') == 'unmitigated']
        if unmitigated_bearish_obs: initial_take_profit = min(unmitigated_bearish_obs, key=lambda x: x['bottom'])['bottom']
        else:
            buy_liq_levels = liquidity_details.get('structural_buy_liq', []);
            if liquidity_details.get('buy_side_liquidity_eqh'): buy_liq_levels.append(liquidity_details['buy_side_liquidity_eqh'])
            target_liq = [lvl for lvl in sorted(list(set(buy_liq_levels))) if lvl > requested_price]
            if target_liq: initial_take_profit = target_liq[0]
    else: # SELL
        unmitigated_bullish_obs = [ob for ob in liquidity_details.get('bullish_obs', []) if ob.get('status') == 'unmitigated']
        if unmitigated_bullish_obs: initial_take_profit = max(unmitigated_bullish_obs, key=lambda x: x['top'])['top']
        else:
            sell_liq_levels = liquidity_details.get('structural_sell_liq', []);
            if liquidity_details.get('sell_side_liquidity_eql'): sell_liq_levels.append(liquidity_details['sell_side_liquidity_eql'])
            target_liq = [lvl for lvl in sorted(list(set(sell_liq_levels)), reverse=True) if lvl < requested_price]
            if target_liq: initial_take_profit = target_liq[0]
    if initial_take_profit == 0.0 or (action == "BUY" and initial_take_profit <= requested_price) or (action == "SELL" and initial_take_profit >= requested_price):
        print(f"⚠️ [EX] No valid dynamic TP. Using ATR TP x{tp_multiplier:.1f}.")
        initial_tp_distance_atr = tp_multiplier * current_atr_h4
        initial_take_profit = requested_price + initial_tp_distance_atr if action == "BUY" else requested_price - initial_tp_distance_atr
    initial_take_profit = round(initial_take_profit, digits)

    # --- Kiểm tra R:R ban đầu và Tính toán Khối lượng (Giữ nguyên) ---
    initial_sl_distance_price = abs(requested_price - initial_stop_loss)
    min_sl_distance = max(symbol_info.point * 10, current_atr_h4 * 0.1)
    if initial_sl_distance_price < min_sl_distance:
         print(f"🚫 [EX] Initial SL distance too small ({initial_sl_distance_price:.{digits}f}). Adjusting.")
         initial_stop_loss = requested_price - min_sl_distance if action == "BUY" else requested_price + min_sl_distance
         initial_stop_loss = round(initial_stop_loss, digits)
         initial_sl_distance_price = abs(requested_price - initial_stop_loss)
    if initial_sl_distance_price <= 0: print(f"❌ [EX] Invalid SL distance {symbol}."); return {"status": "error", "message": "Invalid SL distance."}

    initial_tp_distance_price = abs(initial_take_profit - requested_price)
    initial_rr_ratio = initial_tp_distance_price / initial_sl_distance_price if initial_sl_distance_price > 0 else 0
    min_rr = 1.0
    if initial_rr_ratio < min_rr: print(f"🚫 [EX] Initial R:R low ({initial_rr_ratio:.2f}:1). Skipping."); return {"status": "skipped", "message": f"R:R low ({initial_rr_ratio:.2f}:1)"}

    # Tính toán khối lượng
    risk_percent = risk_params.get("max_risk_per_trade_percent", 1.0)
    account_balance = account_info.balance
    intended_risk_amount = (risk_percent / 100) * account_balance # Lưu lại rủi ro dự kiến

    tick_value = symbol_info.trade_tick_value; tick_size = symbol_info.trade_tick_size
    contract_size = symbol_info.trade_contract_size; volume_step = symbol_info.volume_step
    min_volume = symbol_info.volume_min; max_volume = symbol_info.volume_max

    # Xử lý tick_value = 0 (Giữ nguyên)
    if tick_value <= 0 and tick_size > 0:
        point = symbol_info.point; profit_mode = symbol_info.profit_mode
        # (Logic xác định tick_value dựa trên profit_mode) ...
        if profit_mode == mt5.SYMBOL_PROFIT_MODE_CFDINDEX: tick_value = contract_size * tick_size
        elif profit_mode == mt5.SYMBOL_PROFIT_MODE_FOREX:
             quote_currency = symbol_info.currency_profit; base_currency = symbol_info.currency_base
             acc_currency = account_info.currency
             if quote_currency == acc_currency: tick_value = point * contract_size
             elif base_currency == acc_currency: tick_value = point * contract_size * requested_price # Use requested price
             else:
                 conv_pair = f"{quote_currency}{acc_currency}"; conv_tick = mt5.symbol_info_tick(conv_pair)
                 if conv_tick: tick_value = point * contract_size * conv_tick.bid
                 else:
                     conv_pair_rev = f"{acc_currency}{quote_currency}"; conv_tick_rev = mt5.symbol_info_tick(conv_pair_rev)
                     if conv_tick_rev and conv_tick_rev.ask > 0: tick_value = (point * contract_size) / conv_tick_rev.ask
                     else: print(f"❌ [EX] No conversion rate {symbol} -> {acc_currency}."); return {"status": "error", "message": f"No conversion rate."}
        elif profit_mode == mt5.SYMBOL_PROFIT_MODE_FUTURES: tick_value = symbol_info.trade_tick_value_loss
        elif profit_mode == mt5.SYMBOL_PROFIT_MODE_STOCKS: tick_value = tick_size
        else: tick_value = contract_size * tick_size # Kim loại etc.
        if tick_value <= 0: print(f"❌ [EX] Invalid tick_value {symbol}."); return {"status": "error", "message": f"Invalid tick_value."}
        else: print(f"ℹ️ [EX] Estimated tick_value {symbol}: {tick_value}")


    initial_risk_per_lot = (initial_sl_distance_price / tick_size) * tick_value if tick_size > 0 else 0
    if initial_risk_per_lot <= 0: print(f"❌ [EX] Invalid risk/lot {symbol}."); return {"status": "error", "message": "Invalid risk/lot."}

    volume = intended_risk_amount / initial_risk_per_lot
    if volume_step > 0: volume = np.floor(volume / volume_step) * volume_step
    volume = round(volume, int(-np.log10(volume_step)) if volume_step > 0 and volume_step < 1 else 2)
    volume = max(min_volume, min(volume, max_volume))

    if volume < min_volume or volume == 0: print(f"⚠️ [EX] Volume too small {symbol}."); return {"status": "skipped", "message": "Volume too small."}

    # Lấy điểm tự tin từ entry_analysis
    conf_analysis = entry_analysis.get('confidence_analysis', {})
    auto_buy = conf_analysis.get('autonomous_buy_score_percent', 0)
    auto_sell = conf_analysis.get('autonomous_sell_score_percent', 0)
    auto_score = auto_buy if action=='BUY' else auto_sell

    # --- Chuẩn bị và Gửi lệnh ---
    request = {
        "action": mt5.TRADE_ACTION_DEAL, "symbol": symbol, "volume": volume,
        "type": mt5.ORDER_TYPE_BUY if action == "BUY" else mt5.ORDER_TYPE_SELL,
        "price": requested_price, "sl": initial_stop_loss, "tp": initial_take_profit,
        "deviation": 20, "magic": 234000,
        "comment": f"GBot H({auto_score}%) RR({initial_rr_ratio:.1f}) V({vol_regime[0]})",
        "type_time": mt5.ORDER_TIME_GTC, "type_filling": mt5.ORDER_FILLING_FOK,
    }

    print(f"✅ [EX] Preparing Request: {action} {volume:.{int(-np.log10(volume_step)) if volume_step > 0 and volume_step < 1 else 2}f} {symbol} @ {requested_price:.{digits}f}, SL={initial_stop_loss:.{digits}f}, TP={initial_take_profit:.{digits}f} (RR {initial_rr_ratio:.2f}:1)")

    # --- GỬI LỆNH THẬT & XÁC NHẬN KHỚP LỆNH & ĐIỀU CHỈNH SLIPPAGE ---
    try:
        # Gửi lệnh
        result = await asyncio.to_thread(mt5.order_send, request)

        if result.retcode != mt5.TRADE_RETCODE_DONE:
            print(f"❌ [EX] Order Send FAILED! Code={result.retcode}, Reason: {result.comment}")
            return {"status": "error", "message": f"Order Send Failed: {result.comment} (Code: {result.retcode})"}

        if result.order > 0:
            print(f"✅ [EX] Order #{result.order} Placed. Waiting for execution details...")
            await asyncio.sleep(3) # Chờ MT5 xử lý & tạo deal/position

            # Lấy thông tin khớp lệnh và position_id
            position_id = 0
            filled_price = requested_price # Mặc định là giá yêu cầu
            open_time_dt = datetime.now() # Thời gian gần đúng

            # Ưu tiên lấy từ deal
            if result.deal > 0:
                # Lấy tất cả deals liên quan đến order này
                deals = await asyncio.to_thread(mt5.history_deals_get, None, None, group=str(result.order))
                # Tìm deal mở lệnh (entry=IN) đầu tiên
                entry_deal = next((d for d in deals if d.order == result.order and d.entry == mt5.DEAL_ENTRY_IN), None) if deals else None
                if entry_deal:
                    position_id = entry_deal.position_id
                    filled_price = entry_deal.price
                    open_time_dt = datetime.fromtimestamp(entry_deal.time)
                    print(f"ℹ️ [EX] Confirmed from Deal #{result.deal}: PosID={position_id}, Price={filled_price:.{digits}f}")
                else: print(f"⚠️ [EX] No IN Deal found for Order #{result.order}. Trying Order history.")

            # Nếu không có deal hoặc không lấy được PosID từ deal, thử từ order
            if position_id == 0:
                history_orders = await asyncio.to_thread(mt5.history_orders_get, ticket=result.order)
                if history_orders and len(history_orders) > 0:
                    order_info = history_orders[0]
                    position_id = order_info.position_id
                    # Kiểm tra xem order có giá khớp lệnh không (chỉ có với lệnh limit/stop đã khớp)
                    if order_info.price_current > 0: filled_price = order_info.price_current
                    open_time_dt = datetime.fromtimestamp(order_info.time_done) if order_info.time_done > 0 else datetime.fromtimestamp(order_info.time_setup)
                    print(f"ℹ️ [EX] Confirmed from Order #{result.order}: PosID={position_id}, Price={filled_price:.{digits}f}")


            if position_id > 0:
                 # --- NÂNG CẤP: Kiểm tra và Điều chỉnh Slippage ---
                 slippage = abs(filled_price - requested_price)
                 actual_sl_distance = abs(filled_price - initial_stop_loss)
                 final_stop_loss = initial_stop_loss # SL cuối cùng để ghi log
                 final_take_profit = initial_take_profit # TP cuối cùng để ghi log

                 if actual_sl_distance <= 0 or tick_size <=0: # Kiểm tra lại phòng lỗi chia cho 0
                      print(f"⚠️ [EX/Slippage] Invalid actual SL distance or tick size after fill. Cannot check slippage effect.")
                 else:
                      actual_risk_per_lot = (actual_sl_distance / tick_size) * tick_value
                      if actual_risk_per_lot > 0:
                          actual_risk_amount = actual_risk_per_lot * volume
                          risk_deviation = actual_risk_amount - intended_risk_amount
                          risk_deviation_percent = (risk_deviation / intended_risk_amount) * 100 if intended_risk_amount > 0 else 0

                          print(f"ℹ️ [EX/Slippage] Slippage: {slippage:.{digits}f}. Risk Dev: {risk_deviation:.2f} ({risk_deviation_percent:.1f}%)")

                          # Kiểm tra nếu độ lệch rủi ro vượt ngưỡng
                          if abs(risk_deviation_percent) > slippage_risk_tolerance_percent:
                              print(f"⚠️ [EX/Slippage] Risk deviation ({risk_deviation_percent:.1f}%) exceeds tolerance ({slippage_risk_tolerance_percent}%). Adjusting SL/TP...")

                              # Tính SL mới để giữ nguyên intended_risk_amount
                              new_sl_distance_price = (intended_risk_amount / volume / tick_value) * tick_size if volume > 0 and tick_value > 0 and tick_size > 0 else initial_sl_distance_price # Fallback
                              if new_sl_distance_price > 0:
                                   adjusted_sl = filled_price - new_sl_distance_price if action == "BUY" else filled_price + new_sl_distance_price
                                   adjusted_sl = round(adjusted_sl, digits)

                                   # Tính TP mới để giữ nguyên R:R ban đầu
                                   adjusted_tp_distance_price = initial_rr_ratio * new_sl_distance_price
                                   adjusted_tp = filled_price + adjusted_tp_distance_price if action == "BUY" else filled_price - adjusted_tp_distance_price
                                   adjusted_tp = round(adjusted_tp, digits)

                                   print(f" -> New Adj SL: {adjusted_sl:.{digits}f}, New Adj TP: {adjusted_tp:.{digits}f}")

                                   # Gửi lệnh sửa đổi SL/TP ngay lập tức
                                   modify_success = await modify_position_sltp(position_id, symbol, sl=adjusted_sl, tp=adjusted_tp)
                                   if modify_success:
                                       final_stop_loss = adjusted_sl # Cập nhật SL cuối cùng
                                       final_take_profit = adjusted_tp # Cập nhật TP cuối cùng
                                       print("✅ [EX/Slippage] SL/TP adjusted successfully.")
                                   else:
                                       print("❌ [EX/Slippage] Failed to adjust SL/TP after slippage!")
                                       # Giữ SL/TP ban đầu nếu không sửa được
                              else:
                                  print("⚠️ [EX/Slippage] Cannot calculate new SL distance. Keeping original SL/TP.")
                          # else: print(" -> Risk deviation within tolerance.") # Log nếu muốn
                      # else: print("⚠️ [EX/Slippage] Actual risk per lot is zero after fill.")
                 # --- Kết thúc nâng cấp Slippage ---

                 # Ghi log vào DB với giá khớp lệnh và SL cuối cùng
                 db.log_new_trade(
                     ticket_id=position_id, symbol=symbol, open_time=open_time_dt,
                     order_type=action, volume=volume, open_price=filled_price, # Giá khớp lệnh
                     initial_sl=final_stop_loss, # SL cuối cùng (có thể đã điều chỉnh)
                     entry_analysis_json=json.dumps(entry_analysis, default=str)
                 )
                 print(f"📖 [DB] Logged OPEN position #{position_id} for {symbol}.")
                 # Trả về TP cuối cùng để Manager có thể sử dụng nếu cần (ít dùng vì TP động theo Liq)
                 return {"status": "success", "message": f"Order {action} {symbol} #{position_id} executed and logged.", "final_tp": final_take_profit}
            else:
                 print(f"❌ [EX] CRITICAL ERROR: Order #{result.order} sent but COULD NOT retrieve Position ID. Manual check required!")
                 # Gửi cảnh báo đặc biệt về Telegram ở đây nếu có thể
                 return {"status": "error", "message": "Order sent but FAILED to retrieve Position ID. Check immediately!"}

    except Exception as e:
        print(f"❌ [EX] Critical error during order execution/confirmation: {e}")
        return {"status": "error", "message": f"Critical execution error: {e}"}

    # Đoạn này thường không bao giờ đạt được nếu lệnh thật được kích hoạt
    # return {"status": "simulated", "message": f"Simulated order {action} {symbol} placed."}