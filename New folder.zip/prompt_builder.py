# prompt_builder.py (Phiên bản cuối + Daily News Narrative)
# -*- coding: utf-8 -*-
from typing import Dict, List
import json
import strategy_cache
from datetime import datetime, timedelta
import numpy as np

# --- Các hàm _format... (Giữ nguyên) ---
def _format_best_ob(ob_list: list, ob_type: str, digits: int = 5) -> str:
    unmitigated_obs = [ob for ob in ob_list if isinstance(ob, dict) and ob.get('status') == "unmitigated"]
    if not unmitigated_obs: return f"Không có vùng {ob_type} 'mới'."
    unmitigated_obs.sort(key=lambda x: (x.get('score', 0), -x.get('bottom', 0) if ob_type=="Cầu" else x.get('top', 0)), reverse=True)
    best_ob = unmitigated_obs[0]
    score = best_ob.get('score', 'N/A'); reasons = ", ".join(best_ob.get('reasons', []))
    bottom_str = f"{best_ob.get('bottom', 0):.{digits}f}"; top_str = f"{best_ob.get('top', 0):.{digits}f}"
    status_detail = best_ob.get('status', 'unmitigated')
    if status_detail == "mt_mitigated": status_detail = "Đã chạm 50% (MT)"
    elif status_detail == "edge_mitigated": status_detail = "Đã chạm mép (Edge)"
    else: status_detail = "Mới (Unmitigated)"
    return (f"Vùng {ob_type} hạng A ({score}/10) tại {bottom_str} - {top_str}. Status: {status_detail}. Lý do: {reasons}")

def _format_closest_fvg(fvg_list: list, current_price: float, digits: int = 5) -> str:
    unfilled_fvgs = [fvg for fvg in fvg_list if isinstance(fvg, dict) and fvg.get('status') != "Fully Filled"]
    if not unfilled_fvgs: return "Không có FVG."
    closest_fvg = min(unfilled_fvgs, key=lambda x: min(abs(current_price - x.get('top',np.inf)), abs(current_price - x.get('bottom',-np.inf))))
    fvg_type = "Tăng" if closest_fvg.get('type') == 'bullish' else "Giảm"; status = closest_fvg.get('status', 'N/A')
    bottom_str = f"{closest_fvg.get('bottom', 0):.{digits}f}"; top_str = f"{closest_fvg.get('top', 0):.{digits}f}"
    ce_mitigated = closest_fvg.get('ce_mitigated', False)
    status_detail = f"{status}{' (Đã chạm 50%)' if ce_mitigated and status != 'Unfilled' else ''}"
    return (f"FVG {fvg_type} tại {bottom_str} - {top_str}. Status: {status_detail}.")

def _format_volume_profile(vp_analysis: dict, digits: int = 5) -> str:
    if not vp_analysis or vp_analysis.get('error'): return f"Lỗi Vol Profile: {vp_analysis.get('error', 'N/A')}"
    if not vp_analysis.get('profile_shape'): return "Không đủ dữ liệu Vol Profile."
    shape = vp_analysis.get('profile_shape', 'N/A'); dynamics = vp_analysis.get('dynamics_implication', 'N/A')
    poc = vp_analysis.get('poc', 0); poc_delta = vp_analysis.get('poc_delta', 0)
    hvns = vp_analysis.get('hvns', []); lvns = vp_analysis.get('lvns', [])
    poc_delta_str = "Dương (>0)" if poc_delta > 0 else "Âm (<0)" if poc_delta < 0 else "Cân bằng (0)"
    poc_str = f"{poc:.{digits}f}"
    hvns_str = ", ".join([f"{p:.{digits}f}" for p in hvns]) if hvns else "N/A"
    lvns_str = ", ".join([f"{p:.{digits}f}" for p in lvns]) if lvns else "N/A"
    vah = vp_analysis.get('vah', 0); val = vp_analysis.get('val', 0)
    va_str = f"VA: {val:.{digits}f} - {vah:.{digits}f}"
    return (f"Hình thái: {shape}. Động lực: {dynamics}\n    {va_str}\n    POC: {poc_str} (Delta {poc_delta_str})\n    HVNs (Cản/Hỗ trợ): {hvns_str}\n    LVNs (Vùng trống): {lvns_str}")


def prompt_create_ultimate(
    symbol: str, network_analysis: dict, flow_analysis: str, technical_analysis: dict,
    cycle_analysis: dict, narrative_analysis: dict, regime_analysis: dict,
    rhythm_analysis: dict, recent_trades: List[dict], vsa_analysis: dict, # VSA H4
    d1_vsa_analysis: dict, # VSA D1
    mtf_analysis: dict,
    liquidity_analysis: dict,
    upcoming_events: list,
    volume_profile_analysis: dict,
    volatility_analysis: dict,
    range_analysis: dict,
    session_info: dict,
    intermarket_trends: dict,
    risk_sentiment_trends: dict,
    market_condition: str,
    daily_news_narrative: str # <-- Thêm bối cảnh ngày
) -> str:

    # Lấy digits và current_price an toàn
    digits_prompt = 5; current_price = 0; tech_details = {}
    if isinstance(technical_analysis, dict):
        tech_details = technical_analysis.get('details', {})
        current_price = tech_details.get('current_price', 0)
        symbol_info_temp = tech_details.get('symbol_info')
        if isinstance(symbol_info_temp, dict) and 'digits' in symbol_info_temp: digits_prompt = symbol_info_temp['digits']
        elif current_price > 0:
             try:
                 price_str = f"{current_price:.8f}".rstrip('0')
                 if '.' in price_str: digits_prompt = len(price_str.split('.')[-1])
             except: pass
    else: technical_analysis = {}

    # Format các thành phần
    bullish_ob_str = _format_best_ob(liquidity_analysis.get("bullish_obs", []), "Cầu", digits_prompt)
    bearish_ob_str = _format_best_ob(liquidity_analysis.get("bearish_obs", []), "Cung", digits_prompt)
    fvg_str = _format_closest_fvg(liquidity_analysis.get("fvgs", []), current_price, digits_prompt)
    volume_profile_str = _format_volume_profile(volume_profile_analysis, digits_prompt)

    crt_str = "N/A CRT Data."
    if isinstance(range_analysis, dict) and range_analysis.get('equilibrium', 0) > 0:
        eq_str = f"{range_analysis.get('equilibrium', 0):.{digits_prompt}f}"; low_str = f"{range_analysis.get('htf_range_low', 0):.{digits_prompt}f}"; high_str = f"{range_analysis.get('htf_range_high', 0):.{digits_prompt}f}"
        crt_str = (f"Giá ở vùng **{range_analysis.get('current_zone')}** (D1 Range: {low_str} - {high_str}, EQ: {eq_str}).")

    idm_buy = liquidity_analysis.get('inducement_buy_side'); idm_sell = liquidity_analysis.get('inducement_sell_side'); idm_str = "N/A IDM."
    if idm_buy and idm_sell: idm_str = (f"IDM gần nhất: Buy-side {idm_buy:.{digits_prompt}f}, Sell-side {idm_sell:.{digits_prompt}f}.")
    elif idm_buy: idm_str = f"IDM gần nhất: Buy-side {idm_buy:.{digits_prompt}f}."
    elif idm_sell: idm_str = f"IDM gần nhất: Sell-side {idm_sell:.{digits_prompt}f}."

    sweep_event = liquidity_analysis.get('recent_liquidity_event'); sweep_str = "Không có."
    if sweep_event: sweep_str = f"!!! **{sweep_event['type']}** tại {sweep_event.get('price', 0):.{digits_prompt}f} !!!\n    Hàm ý: {sweep_event.get('implication','N/A')}"

    session_str = f"Phiên: **{session_info.get('current_session', 'N/A')}** ({session_info.get('current_time_utc', '')})."
    asia_high = session_info.get('asia_range_high'); asia_low = session_info.get('asia_range_low')
    if asia_high and asia_low: session_str += f"\n    Asia Range: {asia_low:.{digits_prompt}f} - {asia_high:.{digits_prompt}f}."

    dxy_trend = intermarket_trends.get('DXY_Trend', 0); us10y_trend = intermarket_trends.get('US10Y_Trend', 0)
    dxy_status = "Tăng" if dxy_trend > 2 else "Giảm" if dxy_trend < -2 else "Ngang"; us10y_status = "Tăng" if us10y_trend > 2 else "Giảm" if us10y_trend < -2 else "Ngang"
    intermarket_str = f"DXY H4: **{dxy_status}** ({dxy_trend}/10), US10Y H4: **{us10y_status}** ({us10y_trend}/10)."

    vix_trend = risk_sentiment_trends.get('VIX_Trend', 0); us30_trend = risk_sentiment_trends.get('US30_Trend', 0)
    vix_status = "Tăng" if vix_trend > 1 else "Giảm" if vix_trend < -1 else "Ngang"; us30_status = "Tăng" if us30_trend > 1 else "Giảm" if us30_trend < -1 else "Ngang"
    risk_sentiment = "NEUTRAL";
    if vix_trend > 2 and us30_trend < -2: risk_sentiment = "RISK_OFF (Sợ hãi)"
    elif vix_trend < -2 and us30_trend > 2: risk_sentiment = "RISK_ON (Tham lam)"
    risk_sentiment_str = f"VIX H4: **{vix_status}** ({vix_trend}/10), US30 H4: **{us30_status}** ({us30_trend}/10). Tâm lý: **{risk_sentiment}**."

    memory_info = "Chưa có giao dịch gần đây."
    if recent_trades:
        trade_lines = [f"- Lệnh {t.get('order_type')} gần đây {'Thắng' if t.get('profit', 0) > 0 else 'Thua'}. Luận điểm: '{t.get('thesis', 'N/A')}'" for t in recent_trades if isinstance(t, dict)]
        if trade_lines: memory_info = "\n".join(trade_lines)
    events_str = "Không có sự kiện quan trọng sắp tới."
    if upcoming_events:
        event_lines = [f"- {e['time'].strftime('%H:%M')} {e['currency']}: {e['event']} ({e.get('impact','N/A')[0]})" for e in upcoming_events if isinstance(e, dict) and all(k in e for k in ['time', 'currency', 'event'])]
        if event_lines: events_str = "\n".join(event_lines)
    recent_impacts_list = strategy_cache.get_recent_impacts(minutes=15)
    # Cập nhật logic news_impact_str
    if recent_impacts_list:
        # Lấy hàm ý từ dict (giờ đã chứa xau_impact_bias)
        news_lines = []
        for impact in recent_impacts_list:
             if isinstance(impact, dict):
                  news_lines.append(f"- {impact.get('implication', 'N/A')} (Tác động XAU: {impact.get('xau_impact_bias', 'N/A')})")
        news_impact_str = "\n".join(news_lines) if news_lines else "Không có."
    else: news_impact_str = "Không có."


    special_instructions = ""
    narrative_succeeded = isinstance(narrative_analysis, dict) and narrative_analysis.get("success", False)
    bot_headlines = narrative_analysis.get("headlines", "Bot không tìm thấy tin tức.") if isinstance(narrative_analysis, dict) else "Lỗi narrative analysis."
    if narrative_succeeded:
        special_instructions = f"""
    **HƯỚNG DẪN ĐẶC BIỆT: VAI TRÒ TỔNG BIÊN TẬP**
    Nhiệm vụ của bạn là kết hợp thông tin từ hai nguồn để có được cái nhìn toàn diện nhất về tường thuật thị trường cho {symbol.upper()}.

    **1. Dữ liệu Bot Cung cấp:** Các tiêu đề tin tức tự động thu thập (có thể bị trễ hoặc thiếu sót):
    ```
    {bot_headlines if bot_headlines else 'Không có tiêu đề nào.'}
    ```

    **2. Nhiệm vụ của bạn:**
    a. **Tự tìm kiếm:** Chủ động tìm kiếm Google về "{symbol.upper()} news analysis" để tìm tin tức và phân tích nóng nhất trong vài giờ qua (từ Reuters, Bloomberg, FXStreet...).
    b. **So sánh & Đánh giá:** So sánh thông tin bạn tìm được với danh sách bot cung cấp. Có đồng thuận/mâu thuẫn không? Tin nào quan trọng hơn?
    c. **Tổng hợp:** Dựa trên sự tổng hợp của cả hai nguồn, xây dựng một "câu chuyện thị trường" (main_narrative) chính xác nhất và tích hợp nó vào luận điểm chính (primary_thesis).
        """
    else:
        special_instructions = f"""
    **HƯỚNG DẪN ĐẶC BIỆT: TỰ NGHIÊN CỨU DO LỖI DỮ LIỆU**
    CẢNH BÁO: Module thu thập tin tức của bot đã thất bại hoặc trả về lỗi.
    1.  **Tự tìm kiếm:** Bạn BẮT BUỘC phải tự mình tìm kiếm Google về "{symbol.upper()} news analysis" để tìm ra câu chuyện chính đang diễn ra.
    2.  **Ưu tiên nguồn uy tín:** Tập trung vào tin tức và phân tích từ Reuters, Bloomberg, FXStreet... trong vài giờ qua.
    3.  **Xây dựng Luận điểm:** Dựa hoàn toàn vào kết quả tìm kiếm của bạn để xây dựng luận điểm về bối cảnh thị trường (primary_thesis).
        """

    default_entry_strategy = "SMC Fractal Entry (H4 POI -> M15 CHoCH -> M1 Refined Confirm)"
    sideways_entry_strategy = "Range Deviation/Value Area Reversal (H4 Range/VA -> M1 Sweep/VSA + Confirm)"
    entry_strategy_suggestion = sideways_entry_strategy if market_condition == "SIDEWAYS" else default_entry_strategy
    json_structure = { "asset": f"{symbol.upper()}", "primary_thesis": "...",
        "confidence_analysis": {"ai_confidence_score_percent": 0, "key_factors_supporting": [], "key_factors_against": []},
        "risk_analysis": {"main_risk": "...", "mitigation": "..."},
        "trade_plan": {"action": "BUY / SELL / STAND_ASIDE", "entry_strategy": entry_strategy_suggestion, "alternative_scenario": "..."} }
    formatted_json_structure = json.dumps(json_structure, indent=2, ensure_ascii=False)

    vol_status = volatility_analysis.get('status', 'N/A'); vol_regime = volatility_analysis.get('volatility_regime', 'UNKNOWN')
    vol_percentile = volatility_analysis.get('bbw_percentile'); vol_percentile_str = f"({vol_percentile}%)" if vol_percentile is not None else ""

    mtf_bias = mtf_analysis.get('final_bias', 'NEUTRAL')
    mtf_indicator_align = mtf_analysis.get('indicator_alignment', 'N/A')
    mtf_structure_align = mtf_analysis.get('structure_alignment', 'N/A')

    range_high_sr = tech_details.get('key_resistance'); range_low_sr = tech_details.get('key_support')
    range_high_va = volume_profile_analysis.get('vah'); range_low_va = volume_profile_analysis.get('val')
    range_high_final = range_high_va if market_condition == "SIDEWAYS" and range_high_va else range_high_sr
    range_low_final = range_low_va if market_condition == "SIDEWAYS" and range_low_va else range_low_sr
    range_type_final = "Volume Profile VA" if market_condition == "SIDEWAYS" and range_high_va else "Static S/R Peaks"
    range_str = f"Biên độ H4 ({range_type_final}): {range_low_final:.{digits_prompt}f} - {range_high_final:.{digits_prompt}f}" if range_high_final and range_low_final else "Chưa xác định rõ biên độ H4."

    pdh = liquidity_analysis.get('previous_day_high'); pdl = liquidity_analysis.get('previous_day_low')
    old_hl_str = f"PDH: {pdh:.{digits_prompt}f}, PDL: {pdl:.{digits_prompt}f}" if pdh and pdl else "N/A PDH/L."
    multi_eqh = liquidity_analysis.get('multiple_eqh', []); multi_eql = liquidity_analysis.get('multiple_eql', [])
    multi_eq_str = ""
    if multi_eqh: multi_eq_str += f"Multiple EQH tại: {', '.join([f'{p:.{digits_prompt}f}' for p in multi_eqh])}. "
    if multi_eql: multi_eq_str += f"Multiple EQL tại: {', '.join([f'{p:.{digits_prompt}f}' for p in multi_eql])}."
    if not multi_eq_str: multi_eq_str = "Không có Multiple EQH/L."

    return f"""
    Bạn là AI Chiến lược gia Định lượng (SMC/ICT, Volume Profile, VSA, Intermarket, Risk Sentiment) cho {symbol.upper()}.

    ### PHẦN 0: BẢNG CHÚ GIẢI
    - **OB, BOS/CHoCH, CRT, Mitigation(Edge/MT), Unmitigated, IDM, Sweep/Grab, Volume Profile, POC, VAH/VAL, HVN/LVN, Delta, VSA, Intermarket, Session, Volatility Regime, Range Deviation/VA Trading, Risk Sentiment, PDH/PDL, Multi EQH/L:** (Như định nghĩa trước)
    - **News Narrative (Bối cảnh Tin tức):** Tóm tắt các sự kiện kinh tế quan trọng trong ngày.

    ---
    {special_instructions}
    ---

    **HỒ SƠ PHÂN TÍCH: {symbol.upper()}**
    ============================================
    **TÌNH TRẠNG THỊ TRƯỜNG (H4): {market_condition}**
    {range_str}
    **BỐI CẢNH TIN TỨC HÀNG NGÀY:** {daily_news_narrative}
    ============================================

    ### PHẦN I: BỐI CẢNH

    **⚡ FLASH EVENT (H4)?** {sweep_str}
    **⚡ TIN TỨC NÓNG (Tác động XAU)?** {news_impact_str}

    **1. Liên thị trường & Tâm lý Rủi ro:**
    - **Intermarket (Ảnh hưởng Vàng):** {intermarket_str}
    - **Risk Sentiment (Ảnh hưởng Vàng):** {risk_sentiment_str}
    - **Phiên giao dịch:** {session_str}
    - **Kinh tế Sắp tới (No-Fly Zone):** {events_str}

    **2. MTF (D1/H4 - Ưu tiên Cấu trúc):**
    - **Thiên vị Tổng hợp:** **{mtf_bias}**
    - **Đồng thuận Cấu trúc (D1/H4):** **{mtf_structure_align}** (QUAN TRỌNG)
    - **Đồng thuận EMA (D1/H4):** {mtf_indicator_align} (Phụ)
    - **Hàm ý MTF:** {mtf_analysis.get('implication', 'N/A')}

    **3. Tâm lý (Chu kỳ & Lịch sử):**
    - **Tường thuật:** (Bạn tổng hợp...)
    - **Chế độ Thị trường (H4):** {regime_analysis.get('regime', 'N/A')}
    - **Chu kỳ D1/H4:** D1:{cycle_analysis.get('d1_zone', 'N/A')}, H4:{cycle_analysis.get('h4_zone', 'N/A')}, Đồng thuận:{cycle_analysis.get('alignment_status', 'N/A')}
    - **Lịch sử Giao dịch:**\n{memory_info}

    ### PHẦN II: KỸ THUẬT (H4, trừ CRT/VSA D1)

    - **Cấu trúc H4:** {rhythm_analysis.get('structure', 'N/A')}. Sự kiện cuối: **{rhythm_analysis.get('last_event', 'N/A')}**
       - Protected High: {rhythm_analysis.get('details',{}).get('protected_high')}, Protected Low: {rhythm_analysis.get('details',{}).get('protected_low')}
       - Target High: {rhythm_analysis.get('details',{}).get('target_high')}, Target Low: {rhythm_analysis.get('details',{}).get('target_low')}
    - **CRT D1:** {crt_str}
    - **Thanh khoản Chính H4:**
       - IDM: {idm_str}
       - Old H/L: {old_hl_str}
       - Multi EQ: {multi_eq_str}
    - **SMC POI H4 (Unmitigated):**
       - Cung (Bearish OB): {bearish_ob_str}
       - Cầu (Bullish OB): {bullish_ob_str}
       - FVG: {fvg_str}
    - **VSA D1:** **{d1_vsa_analysis.get('signal', 'N/A')}** (Conf: {d1_vsa_analysis.get('confidence', 'Low')})
    - **VSA H4:** **{vsa_analysis.get('signal', 'N/A')}** (Conf: {vsa_analysis.get('confidence', 'Low')})
    - **Volatility H4:** **{vol_status}** {vol_percentile_str}. Chế độ: **{vol_regime}**.
    - **Volume Profile (24h):** \n{volume_profile_str}

    ============================================
    **NHIỆM VỤ (Đặc biệt cho Vàng - XAUUSD):**
    1.  **Xác định Chiến lược:** Dựa vào **TÌNH TRẠNG THỊ TRƯỜNG** và **BỐI CẢNH TIN TỨC HÀNG NGÀY**.
    2.  **Tổng hợp & Đánh giá:** Kết hợp TOÀN BỘ. **Ưu tiên cao nhất:** Bối cảnh Tin tức, Risk Sentiment, Intermarket, MTF Structure, Sweep (đặc biệt quét Asia/PDH/PDL/Multi EQ), POI được HVN/Delta xác nhận.
    3.  **Lập Kế hoạch:** Hành động (BUY/SELL/STAND_ASIDE).

    **ĐỊNH DẠNG TRẢ LỜI (JSON):**
    ```json
    {formatted_json_structure}
    ```
    """