# system_state.py (Phiên bản Nâng cấp - Tự động chạy)
# -*- coding: utf-8 -*-
import json
import os

STATE_FILE = "system_state.json"

# Các trạng thái hoạt động có thể có của bot
POSSIBLE_STATES = ["ACTIVE_TRADING", "CLOSE_ONLY", "PAUSED"]

# --- THAY ĐỔI CHÍNH NẰM Ở ĐÂY ---
# Trạng thái mặc định nếu không có file lưu trữ
DEFAULT_STATE = {
    # Mặc định là ACTIVE_TRADING để bot tự động giao dịch ngay khi mở lần đầu
    "trading_status": "ACTIVE_TRADING", 
    "last_update": ""
}
# --------------------------------

def load_state() -> dict:
    """Tải trạng thái từ file JSON khi bot khởi động."""
    if not os.path.exists(STATE_FILE):
        print("⚠️ Không tìm thấy file trạng thái. SỬ DỤNG TRẠNG THÁI MẶC ĐỊNH: ACTIVE_TRADING.")
        return DEFAULT_STATE.copy()
    try:
        with open(STATE_FILE, 'r') as f:
            state = json.load(f)
            # Đảm bảo trạng thái tải lên là hợp lệ
            if state.get("trading_status") in POSSIBLE_STATES:
                print(f"✅ Đã tải trạng thái hệ thống: {state.get('trading_status')}")
                return state
            else:
                print(f"🔥 Trạng thái không hợp lệ trong file. Quay về mặc định.")
                return DEFAULT_STATE.copy()

    except Exception as e:
        print(f"❌ Lỗi khi tải file trạng thái: {e}. Sử dụng trạng thái mặc định.")
        return DEFAULT_STATE.copy()

def save_state(state: dict):
    """Lưu trạng thái hiện tại vào file JSON."""
    try:
        with open(STATE_FILE, 'w') as f:
            json.dump(state, f, indent=2)
    except Exception as e:
        print(f"❌ Lỗi khi lưu file trạng thái: {e}")

# --- Các hàm để module khác tương tác ---

# Khởi tạo trạng thái toàn cục khi module được import
CURRENT_STATE = load_state()

def get_status() -> str:
    """Lấy trạng thái giao dịch hiện tại."""
    return CURRENT_STATE.get("trading_status", "PAUSED")

def set_status(new_status: str) -> bool:
    """Thiết lập một trạng thái giao dịch mới và lưu lại."""
    if new_status not in POSSIBLE_STATES:
        print(f"❌ Cảnh báo: Cố gắng đặt trạng thái không hợp lệ '{new_status}'")
        return False
    
    from datetime import datetime
    CURRENT_STATE["trading_status"] = new_status
    CURRENT_STATE["last_update"] = datetime.now().isoformat()
    save_state(CURRENT_STATE)
    print(f"✅ Trạng thái hệ thống đã được cập nhật thành: {new_status}")
    return True