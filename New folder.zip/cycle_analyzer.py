# cycle_analyzer.py (Phiên bản Nâng cấp MTF Cycle Analysis)
# -*- coding: utf-8 -*-
import pandas as pd
import json
import re
import gemini_client as gc
import numpy as np
import asyncio
from data_handler import mt5_get_rates
import MetaTrader5 as mt5

STRATEGIC_ZONES = {
    "Accumulation Zone (Vùng Tích lũy)": "Giai đoạn đáy thị trường, giá đi ngang sau một đợt giảm mạnh. Tâm lý cực kỳ bi quan. Hàm ý: Tìm kiếm các tín hiệu đảo chiều tăng giá sớm, rủi ro cao.",
    "Participation Zone (Vùng Tham gia / Xu hướng tăng)": "Giai đoạn xu hướng tăng được xác lập, đỉnh sau cao hơn đỉnh trước, đáy sau cao hơn đáy trước. Tâm lý lạc quan. Hàm ý: Ưu tiên các chiến lược Mua khi giá điều chỉnh.",
    "Distribution Zone (Vùng Phân phối)": "Giai đoạn đỉnh thị trường, giá chững lại và biến động mạnh sau một đợt tăng dài. Tâm lý hưng phấn cực độ. Hàm ý: Tìm kiếm các tín hiệu đảo chiều giảm giá, tránh các lệnh Mua mới.",
    "Panic Zone (Vùng Hoảng loạn / Xu hướng giảm)": "Giai đoạn xu hướng giảm được xác lập, giá phá vỡ các mức hỗ trợ. Tâm lý sợ hãi. Hàm ý: Ưu tiên các chiến lược Bán khi giá hồi phục."
}

def calculate_indicators(df: pd.DataFrame):
    """Tính toán các chỉ báo phụ trợ để phân tích tâm lý."""
    df = df.copy()
    # Tính RSI
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss
    df['rsi'] = 100 - (100 / (1 + rs))
    
    # Tính Volume tương đối
    df['volume_ma'] = df['tick_volume'].rolling(window=20).mean()
    df['relative_volume'] = df['tick_volume'] / df['volume_ma']
    
    # Tính ATR
    df['tr'] = pd.DataFrame([df['high'] - df['low'], abs(df['high'] - df['close'].shift()), abs(df['low'] - df['close'].shift())]).max(axis=0)
    df['atr'] = df['tr'].ewm(span=14, adjust=False).mean()
    df['normalized_atr'] = (df['atr'] / df['close']) * 100
    
    return df

async def _analyze_single_tf_cycle(symbol: str, price_data: pd.DataFrame) -> dict:
    """
    Hàm nội bộ để phân tích chu kỳ trên một khung thời gian duy nhất.
    """
    if price_data.empty or len(price_data) < 100:
        return {"zone": "Không xác định", "reasoning": "Không đủ dữ liệu."}

    df = calculate_indicators(price_data)
    last_candle = df.iloc[-1]
    
    context_data = {
        "Giá đóng cửa gần nhất": f"{last_candle['close']:.5f}",
        "Giá cao nhất 200 nến": f"{df['high'].tail(200).max():.5f}",
        "Giá thấp nhất 200 nến": f"{df['low'].tail(200).min():.5f}",
        "RSI (14)": f"{last_candle['rsi']:.2f}",
        "Volume tương đối (so với MA20)": f"{last_candle['relative_volume']:.2f}x",
        "Biến động ATR chuẩn hóa": f"{last_candle['normalized_atr']:.3f}%"
    }

    prompt = f"""
    Bạn là một chuyên gia phân tích tâm lý thị trường dày dặn kinh nghiệm.
    Nhiệm vụ của bạn là xác định xem tài sản {symbol.upper()} đang ở trong Vùng Chiến lược nào.

    Dưới đây là định nghĩa và hàm ý của 4 Vùng Chiến lược:
    {json.dumps(STRATEGIC_ZONES, indent=2, ensure_ascii=False)}

    Và đây là các dữ liệu thị trường mới nhất của {symbol.upper()}:
    {json.dumps(context_data, indent=2, ensure_ascii=False)}

    DỰA TRÊN TOÀN BỘ DỮ LIỆU TRÊN, hãy phân tích và chọn ra Vùng Chiến lược phù hợp nhất.

    TRẢ LỜI THEO ĐỊNH DẠNG JSON SAU:
    ```json
    {{
      "zone": "Tên Vùng Chiến lược",
      "reasoning": "Lý do ngắn gọn của bạn."
    }}
    ```
    """
    
    try:
        response_text = await gc.gemini_get_response(prompt)
        json_match = re.search(r'```json\s*([\s\S]+?)\s*```', response_text)
        if json_match:
            response_json = json.loads(json_match.group(1))
            return response_json
        else:
            # Fallback for cases where Gemini doesn't use the code block
            return json.loads(response_text)
    except Exception as e:
        print(f"Lỗi khi phân tích chu kỳ đơn lẻ: {e}")
        return {"zone": "Lỗi Phân Tích", "reasoning": str(e)}

async def analyze_mtf_cycle(symbol: str) -> dict:
    """
    Hàm điều phối chính: Phân tích chu kỳ trên D1 và H4, sau đó so sánh.
    """
    print(f"🔄 Phân tích chu kỳ đa khung thời gian cho {symbol}...")
    
    # 1. Lấy dữ liệu D1 và H4 song song
    d1_data_task = mt5_get_rates(symbol, mt5.TIMEFRAME_D1, count=250)
    h4_data_task = mt5_get_rates(symbol, mt5.TIMEFRAME_H4, count=250)
    d1_data, h4_data = await asyncio.gather(d1_data_task, h4_data_task)
    
    # 2. Phân tích chu kỳ trên từng khung thời gian song song
    d1_cycle_task = _analyze_single_tf_cycle(symbol, d1_data)
    h4_cycle_task = _analyze_single_tf_cycle(symbol, h4_data)
    d1_result, h4_result = await asyncio.gather(d1_cycle_task, h4_cycle_task)
    
    d1_zone = d1_result.get("zone", "Không xác định")
    h4_zone = h4_result.get("zone", "Không xác định")
    
    # 3. So sánh và đưa ra kết luận cuối cùng
    alignment_status = "Phân kỳ"
    final_implication = "Tín hiệu chu kỳ không rõ ràng, cần cẩn trọng."
    
    d1_is_bullish = "Participation" in d1_zone or "Accumulation" in d1_zone
    h4_is_bullish_context = "Participation" in h4_zone or "Accumulation" in h4_zone
    
    d1_is_bearish = "Distribution" in d1_zone or "Panic" in d1_zone
    h4_is_bearish_context = "Distribution" in h4_zone or "Panic" in h4_zone

    if d1_is_bullish and h4_is_bullish_context:
        alignment_status = "Đồng thuận TĂNG"
        final_implication = "Chu kỳ dài hạn và ngắn hạn cùng ủng hộ xu hướng TĂNG. Ưu tiên các cơ hội Mua."
    elif d1_is_bearish and h4_is_bearish_context:
        alignment_status = "Đồng thuận GIẢM"
        final_implication = "Chu kỳ dài hạn và ngắn hạn cùng ủng hộ xu hướng GIẢM. Ưu tiên các cơ hội Bán."
    elif d1_is_bullish and "Distribution" in h4_zone:
        alignment_status = "Cảnh báo Phân phối Ngắn hạn"
        final_implication = "Cảnh báo: Xu hướng chính vẫn TĂNG, nhưng ngắn hạn có dấu hiệu tạo đỉnh. Tránh Mua mới."
    elif d1_is_bearish and "Participation" in h4_zone:
        alignment_status = "Cảnh báo Hồi phục Ngắn hạn"
        final_implication = "Cảnh báo: Xu hướng chính vẫn GIẢM, nhưng ngắn hạn có dấu hiệu hồi phục. Tránh Bán đuổi."

    return {
        "d1_zone": d1_zone,
        "h4_zone": h4_zone,
        "alignment_status": alignment_status,
        "final_implication": final_implication
    }