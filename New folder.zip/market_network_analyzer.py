# market_network_analyzer.py (Phiên bản Nâng cấp Trực quan hóa)
# -*- coding: utf-8 -*-
import pandas as pd
import MetaTrader5 as mt5
from typing import List, Dict
from data_handler import mt5_get_rates
import networkx as nx
import matplotlib.pyplot as plt

# Ngưỡng tương quan để vẽ một đường nối
CORRELATION_THRESHOLD = 0.6

async def analyzer_market_network(assets: List[str], timeframe=mt5.TIMEFRAME_H4, period=50) -> Dict:
    """
    Phân tích mạng lưới thị trường, tìm nút trung tâm và VẼ biểu đồ mạng lưới.
    """
    # --- Phần 1: Lấy dữ liệu và tính toán (giữ nguyên) ---
    all_data = {}
    for asset in assets:
        df = await mt5_get_rates(asset, timeframe, period)
        if not df.empty:
            all_data[asset] = df['close'].pct_change() # Sử dụng % thay đổi để chuẩn hóa
            
    if not all_data:
        return {"central_node": "Không xác định", "price_dataframe": pd.DataFrame(), "image_path": None}
        
    combined_df = pd.DataFrame(all_data).dropna()
    correlation_matrix = combined_df.corr()
    
    # --- Phần 2: NÂNG CẤP - Vẽ Biểu đồ Mạng lưới ---
    plt.style.use('dark_background')
    fig, ax = plt.subplots(figsize=(16, 12))
    
    G = nx.Graph()
    
    # Thêm các nút (tên tài sản)
    G.add_nodes_from(correlation_matrix.columns)
    
    # Thêm các đường nối dựa trên tương quan
    edges = []
    edge_colors = []
    edge_widths = []
    for i in range(len(correlation_matrix.columns)):
        for j in range(i):
            asset1 = correlation_matrix.columns[i]
            asset2 = correlation_matrix.columns[j]
            correlation = correlation_matrix.iloc[i, j]
            
            if abs(correlation) > CORRELATION_THRESHOLD:
                G.add_edge(asset1, asset2, weight=abs(correlation))
                edge_colors.append('g' if correlation > 0 else 'r') # Xanh cho tương quan thuận, Đỏ cho nghịch
                edge_widths.append(abs(correlation) * 5)

    # Tính toán "tầm ảnh hưởng" của mỗi nút để quyết định kích thước
    try:
        centrality = nx.eigenvector_centrality(G, weight='weight', max_iter=1000)
        node_sizes = [v * 10000 for v in centrality.values()]
    except: # Fallback nếu thuật toán không hội tụ
        centrality = nx.degree_centrality(G)
        node_sizes = [v * 5000 for v in centrality.values()]

    # Vẽ biểu đồ
    pos = nx.spring_layout(G, k=1.5, iterations=50, seed=42)
    nx.draw_networkx_nodes(G, pos, node_size=node_sizes, node_color='skyblue', alpha=0.8, ax=ax)
    nx.draw_networkx_edges(G, pos, width=edge_widths, edge_color=edge_colors, alpha=0.6, ax=ax)
    nx.draw_networkx_labels(G, pos, font_size=12, font_color='white', ax=ax)
    
    ax.set_title("Bản đồ Mạng lưới Thị trường (Market Network Map)", fontsize=20, color='white')
    plt.axis('off')
    
    # Lưu hình ảnh ra file
    image_path = "market_network.png"
    plt.savefig(image_path, bbox_inches='tight', pad_inches=0.1, dpi=100)
    plt.close(fig) # Đóng biểu đồ để giải phóng bộ nhớ
    
    print(f"🗺️  Đã vẽ và lưu Bản đồ Mạng lưới Thị trường tại '{image_path}'")
    
    # Tính toán nút trung tâm (giữ nguyên)
    centrality_sum = correlation_matrix.abs().sum().sort_values(ascending=False)
    central_node = centrality_sum.index[0] if not centrality_sum.empty else "Không xác định"
    
    return {"central_node": central_node, "price_dataframe": combined_df, "image_path": image_path}