# check_models.py
import google.generativeai as genai
from config import GEMINI_API_KEY

try:
    genai.configure(api_key=GEMINI_API_KEY)

    print("Đang lấy danh sách các mô hình có sẵn cho API key của bạn...")
    print("-" * 50)

    model_names = []
    for model in genai.list_models():
        # Chúng ta chỉ quan tâm đến các mô hình có thể tạo nội dung (generateContent)
        if 'generateContent' in model.supported_generation_methods:
            model_names.append(model.name)
            
    # Sắp xếp để dễ nhìn hơn
    model_names.sort()
    for name in model_names:
        print(name)

    print("-" * 50)
    print("Hoàn thành.")

except Exception as e:
    print(f"Đã xảy ra lỗi: {e}")
    print("Vui lòng kiểm tra lại GEMINI_API_KEY trong file config.py")