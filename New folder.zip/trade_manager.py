# trade_manager.py (Phiên bản Cuối: Structure Trail & Liquidity TP - LỆNH THẬT ĐÃ KÍCH HOẠT)
# -*- coding: utf-8 -*-
import MetaTrader5 as mt5
import database as db
import system_state
import pandas as pd
import numpy as np
import asyncio
from datetime import datetime, timedelta # Import timedelta
import json
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from data_handler import mt5_get_rates # Import hàm lấy rates
import trend_rhythm_analyzer as tra # <-- NÂNG CẤP: Import rhythm analyzer

# --- CÁC HÀM PHỤ TRỢ ---

def calculate_atr(df: pd.DataFrame, period=14) -> float:
    """Hàm tính toán ATR từ DataFrame giá."""
    if df.empty or len(df) < period + 1: return 0.0
    df = df.copy()
    # Kiểm tra và tính TR
    if not all(col in df.columns for col in ['high', 'low', 'close']): return 0.0
    df['high_low'] = df['high'] - df['low']
    df['high_close'] = np.abs(df['high'] - df['close'].shift())
    df['low_close'] = np.abs(df['low'] - df['close'].shift())
    df['tr'] = df[['high_low', 'high_close', 'low_close']].max(axis=1)
    # Tính ATR
    atr = df['tr'].ewm(span=period, adjust=False).mean().iloc[-1]
    return atr if pd.notna(atr) else 0.0 # Trả về 0 nếu kết quả là NaN

async def get_trade_history_rates(symbol: str, open_time_dt: datetime, timeframe=mt5.TIMEFRAME_M15, needed_bars=50):
    """Lấy dữ liệu nến kể từ khi lệnh được mở, đảm bảo đủ số lượng nến."""
    # Tính toán thời gian bắt đầu đủ xa để có đủ nến
    # Ước tính thời gian cho needed_bars (ví dụ M15 -> 15 phút/nến)
    timeframe_minutes = 1 # Default M1
    if timeframe == mt5.TIMEFRAME_M5: timeframe_minutes = 5
    elif timeframe == mt5.TIMEFRAME_M15: timeframe_minutes = 15
    elif timeframe == mt5.TIMEFRAME_H1: timeframe_minutes = 60
    # ... (Thêm các timeframe khác nếu cần)
    required_duration = timedelta(minutes=timeframe_minutes * (needed_bars + 5)) # Lấy dư 5 nến
    start_time_dt = min(open_time_dt, datetime.now() - required_duration) # Bắt đầu từ lúc mở lệnh hoặc sớm hơn nếu cần

    start_timestamp = int(start_time_dt.timestamp())
    now_timestamp = int(datetime.now().timestamp()) + 60 # Lấy dư 1 phút

    # print(f"DEBUG: Getting rates for {symbol} TF {timeframe} from {start_time_dt} to now") # Debug log
    rates = await asyncio.to_thread(
        mt5.copy_rates_range,
        symbol,
        timeframe,
        start_timestamp,
        now_timestamp
    )
    if rates is None or len(rates) == 0:
        print(f"⚠️ [MANAGER/Rates] Không lấy được rates lịch sử cho {symbol} TF {timeframe} từ {start_time_dt}")
        return pd.DataFrame()

    df = pd.DataFrame(rates)
    df['time'] = pd.to_datetime(df['time'], unit='s')
    # Đảm bảo đủ cột và đủ số lượng nến
    if not all(col in df.columns for col in ['time', 'open', 'high', 'low', 'close', 'tick_volume']):
        print(f"❌ [MANAGER/Rates] Dữ liệu rates {symbol} TF {timeframe} thiếu cột.")
        return pd.DataFrame()
    # print(f"DEBUG: Got {len(df)} bars for {symbol} TF {timeframe}") # Debug log
    return df

async def modify_position_sltp(position_ticket: int, symbol: str, sl: float = None, tp: float = None):
    """Hàm gửi yêu cầu sửa đổi SL/TP cho một lệnh (Đã có kiểm tra stop level)."""
    # Lấy thông tin symbol để làm tròn SL/TP và kiểm tra stop level
    symbol_info = mt5.symbol_info(symbol)
    if not symbol_info:
        print(f"❌ [MANAGER] Không lấy được symbol info {symbol} để sửa lệnh.")
        return False
    digits = symbol_info.digits

    # Lấy thông tin position hiện tại
    try:
        position_info = await asyncio.to_thread(mt5.positions_get, ticket=position_ticket)
        if not position_info:
            # print(f"ℹ️ [MANAGER] Không tìm thấy lệnh #{position_ticket} để sửa (có thể đã đóng).")
            return True # Coi như thành công nếu lệnh đã đóng
        position = position_info[0]
    except Exception as e_pos:
         print(f"❌ [MANAGER] Lỗi khi lấy thông tin lệnh #{position_ticket}: {e_pos}")
         return False


    # Xác định giá trị SL/TP mới, làm tròn theo digits
    new_sl = position.sl
    is_sl_modified = False
    if sl is not None:
        proposed_sl = round(sl, digits)
        # Chỉ cập nhật nếu SL mới khác SL cũ (tránh gửi lệnh thừa)
        if proposed_sl != position.sl:
            # Đảm bảo SL mới hợp lệ (không quá gần giá hiện tại)
            tick = mt5.symbol_info_tick(symbol)
            if not tick: print(f"⚠️ [MANAGER] Không lấy được tick {symbol} để check SL."); return False

            min_stop_distance = symbol_info.trade_stops_level * symbol_info.point
            current_market_price_ask = tick.ask
            current_market_price_bid = tick.bid

            valid_sl = True
            if position.type == mt5.ORDER_TYPE_BUY: # Lệnh Buy
                # SL mới phải thấp hơn giá Bid trừ đi khoảng cách tối thiểu
                if proposed_sl >= current_market_price_bid - min_stop_distance:
                    # print(f"⚠️ [MANAGER] SL Buy mới {proposed_sl} quá gần giá bid {current_market_price_bid}. Giữ SL cũ.")
                    valid_sl = False
            else: # Lệnh Sell
                # SL mới phải cao hơn giá Ask cộng thêm khoảng cách tối thiểu (hoặc bằng 0)
                if proposed_sl != 0.0 and proposed_sl <= current_market_price_ask + min_stop_distance:
                    # print(f"⚠️ [MANAGER] SL Sell mới {proposed_sl} quá gần giá ask {current_market_price_ask}. Giữ SL cũ.")
                    valid_sl = False

            if valid_sl:
                new_sl = proposed_sl
                is_sl_modified = True
            # else: # Giữ SL cũ nếu không hợp lệ
            #     new_sl = position.sl

    new_tp = position.tp
    is_tp_modified = False
    if tp is not None:
        proposed_tp = round(tp, digits)
        if proposed_tp != position.tp:
            # (Có thể thêm kiểm tra TP hợp lệ tương tự SL nếu cần)
            new_tp = proposed_tp
            is_tp_modified = True

    # Chỉ gửi yêu cầu nếu có thay đổi thực sự ở SL hoặc TP
    if not is_sl_modified and not is_tp_modified:
        return True # Thành công vì không cần thay đổi

    request = {
        "action": mt5.TRADE_ACTION_SLTP,
        "position": position_ticket,
        "symbol": symbol,
        "sl": new_sl,
        "tp": new_tp,
        "magic": 234001, # Magic number riêng cho việc quản lý
    }

    print(f" MODIFYING #{position_ticket}: SL={new_sl}, TP={new_tp}")
    try:
        result = await asyncio.to_thread(mt5.order_send, request)
    except Exception as e_send:
         print(f"❌ [MANAGER] Exception khi gửi lệnh sửa #{position_ticket}: {e_send}")
         return False


    if result and result.retcode == mt5.TRADE_RETCODE_DONE:
        print(f"✅ [MANAGER] Sửa lệnh #{position_ticket} thành công: SL={new_sl}, TP={new_tp}")
        return True
    else:
        error_code = result.retcode if result else "N/A"
        error_comment = result.comment if result else "Không có phản hồi từ server"
        print(f"❌ [MANAGER] Lỗi khi sửa lệnh #{position_ticket}: Code={error_code}, Reason: {error_comment}")
        if error_code == 10016: print(f" -> Lỗi Invalid Stops: Giá SL/TP không hợp lệ.")
        elif error_code == 10027: print(f" -> Lỗi Auto Trading Disabled.")
        # Thêm mã lỗi 130: invalid stops (thường gặp khi SL/TP quá gần)
        elif error_code == 130: print(f" -> Lỗi Invalid Stops (130): Giá SL/TP quá gần.")
        return False

# --- HÀM QUẢN LÝ CHÍNH ---

async def manage_open_trades(mandate: dict, context: ContextTypes.DEFAULT_TYPE, chat_id: str):
    """Quản lý các lệnh đang mở: Hòa vốn, Chốt lời Thanh khoản, Trailing Cấu trúc."""
    if system_state.get_status() == "PAUSED": return

    try:
        positions = await asyncio.to_thread(mt5.positions_get)
        if positions is None: print("⚠️ [MANAGER] Không thể lấy vị thế."); return
    except Exception as e_pos: print(f"❌ Lỗi lấy vị thế: {e_pos}"); return

    if not positions: return

    mgm_params = mandate.get("position_management", {})
    enable_breakeven = mgm_params.get("enable_breakeven", False)
    breakeven_trigger_rr = mgm_params.get("breakeven_trigger_rr", 1.0)
    enable_partial_tp = mgm_params.get("enable_partial_tp", False)
    # Không còn dùng partial_tp_targets từ mandate, sẽ dùng liquidity targets
    enable_trailing_stop = mgm_params.get("enable_atr_trailing_stop", False) # Vẫn dùng cờ này, nhưng logic là structure
    # trailing_stop_atr_multiplier = mgm_params.get("trailing_stop_atr_multiplier", 2.5) # Không dùng trực tiếp nữa

    tasks = []
    for position in positions:
        tasks.append(manage_single_trade(
            position, mandate, mgm_params, context, chat_id,
            enable_breakeven, breakeven_trigger_rr,
            enable_partial_tp, # Vẫn truyền cờ bật/tắt
            enable_trailing_stop # Vẫn truyền cờ bật/tắt
        ))

    await asyncio.gather(*tasks)

async def manage_single_trade(
    position, mandate, mgm_params, context, chat_id,
    enable_breakeven, breakeven_trigger_rr,
    enable_partial_tp, # Cờ bật/tắt Partial TP
    enable_trailing_stop # Cờ bật/tắt Trailing
):
    """Hàm quản lý logic cho một lệnh đơn lẻ (Structure Trail & Liquidity TP)."""
    ticket = position.ticket
    symbol = position.symbol

    # Lấy thông tin lệnh từ DB
    try:
        trade_info = await asyncio.to_thread(db.get_trade_by_ticket, ticket)
    except Exception as e_db:
         print(f"❌ [MANAGER] Lỗi DB khi lấy thông tin lệnh #{ticket}: {e_db}")
         return

    if not trade_info or trade_info['status'] != 'open': return

    management_status = trade_info['management_status']
    initial_sl = trade_info['initial_sl']
    open_price = position.price_open
    current_sl = position.sl
    position_type = position.type
    initial_volume = trade_info['initial_volume']
    open_time_str = trade_info['open_time']
    # --- NÂNG CẤP: Lấy entry_analysis để đọc liquidity targets ---
    entry_analysis_json = trade_info.get('entry_analysis_json', '{}')
    entry_analysis = {}
    h4_liquidity_targets = []
    try:
        entry_analysis = json.loads(entry_analysis_json) if entry_analysis_json else {}
        # Trích xuất các mục tiêu thanh khoản H4 phù hợp với hướng lệnh
        liquidity_h4 = entry_analysis.get('liquidity_analysis_h4', {})
        if position_type == mt5.ORDER_TYPE_BUY: # Lệnh Mua -> Mục tiêu là Buy-side Liq phía trên
            targets = liquidity_h4.get('structural_buy_liq', [])
            if liquidity_h4.get('buy_side_liquidity_eqh'):
                 targets.append(liquidity_h4['buy_side_liquidity_eqh'])
            # Lọc các mục tiêu phía trên giá vào lệnh và sắp xếp tăng dần
            h4_liquidity_targets = sorted([t for t in list(set(targets)) if t > open_price])
        else: # Lệnh Bán -> Mục tiêu là Sell-side Liq phía dưới
            targets = liquidity_h4.get('structural_sell_liq', [])
            if liquidity_h4.get('sell_side_liquidity_eql'):
                 targets.append(liquidity_h4['sell_side_liquidity_eql'])
            # Lọc các mục tiêu phía dưới giá vào lệnh và sắp xếp giảm dần
            h4_liquidity_targets = sorted([t for t in list(set(targets)) if t < open_price], reverse=True)

    except json.JSONDecodeError:
        print(f"⚠️ [MANAGER] Lệnh #{ticket}: Không thể parse entry_analysis_json.")
    except Exception as e_json:
         print(f"❌ [MANAGER] Lỗi xử lý JSON lệnh #{ticket}: {e_json}")

    try: # Chuyển đổi open_time
        try: open_time_dt = datetime.fromisoformat(open_time_str)
        except ValueError: open_time_dt = datetime.strptime(open_time_str, '%Y-%m-%d %H:%M:%S')
    except Exception as e_time: print(f"❌ Lỗi chuyển đổi open_time #{ticket}: {e_time}"); return

    if not initial_sl or initial_sl == 0.0: return # Bỏ qua nếu không có SL ban đầu

    # Lấy giá hiện tại
    tick = mt5.symbol_info_tick(symbol)
    if not tick: print(f"⚠️ Không lấy được tick {symbol} #{ticket}."); return
    current_price = tick.ask if position_type == mt5.ORDER_TYPE_SELL else tick.bid
    entry_price = open_price

    # Tính toán R multiple (vẫn dùng cho Breakeven)
    initial_risk_price = abs(entry_price - initial_sl)
    current_profit_price = (current_price - entry_price) if position_type == mt5.ORDER_TYPE_BUY else (entry_price - current_price)
    r_multiple = current_profit_price / initial_risk_price if initial_risk_price > 0 else 0

    # --- Logic quản lý ---

    # 1. Dời SL về hòa vốn (chỉ làm 1 lần khi status là PENDING)
    if enable_breakeven and management_status == "PENDING" and r_multiple >= breakeven_trigger_rr:
        print(f"🔒 [MANAGER] Lệnh #{ticket} ({symbol}) đạt {r_multiple:.2f}R >= {breakeven_trigger_rr}R. Dời SL về hòa vốn...")
        if await modify_position_sltp(ticket, symbol, sl=entry_price):
            await asyncio.to_thread(db.update_trade_management_status, ticket, "BREAKEVEN")
            if context and chat_id:
                text = f"🔒 <b>Dời SL về hòa vốn</b> cho <code>{symbol}</code> #{ticket}."
                await context.bot.send_message(chat_id=chat_id, text=text, parse_mode=ParseMode.HTML, disable_notification=True)
        return # Kết thúc

    # --- NÂNG CẤP: Chốt lời Từng phần Dựa trên Mục tiêu Thanh khoản ---
    if enable_partial_tp and h4_liquidity_targets:
        # Xác định xem đã chốt lời ở mức nào rồi (ví dụ: PARTIAL_LIQ_1 -> next target là index 1)
        next_target_index = 0
        if management_status.startswith("PARTIAL_LIQ_"):
            try: next_target_index = int(management_status.replace("PARTIAL_LIQ_", ""))
            except: next_target_index = 0 # Nếu lỗi, thử lại từ target đầu tiên

        # Kiểm tra target tiếp theo nếu có
        if next_target_index < len(h4_liquidity_targets):
            next_liq_target = h4_liquidity_targets[next_target_index]
            target_level = next_target_index + 1 # Số thứ tự target (1, 2, ...)

            # Tính ATR M15 để xác định ngưỡng "tiếp cận"
            atr_m15 = 0.0
            try:
                rates_m15_atr = await get_trade_history_rates(symbol, open_time_dt, mt5.TIMEFRAME_M15, needed_bars=20)
                if not rates_m15_atr.empty: atr_m15 = calculate_atr(rates_m15_atr, period=14)
            except Exception as e_atr_tp: print(f"⚠️ Lỗi tính ATR M15 cho TP #{ticket}: {e_atr_tp}")

            # Ngưỡng tiếp cận (ví dụ: 0.5 ATR M15 hoặc tối thiểu vài pip)
            symbol_info_tp = mt5.symbol_info(symbol)
            min_approach_pips = symbol_info_tp.point * 10 if symbol_info_tp else 0.0001
            approach_threshold = max(atr_m15 * 0.5, min_approach_pips) if atr_m15 > 0 else min_approach_pips

            price_reached_target = False
            if position_type == mt5.ORDER_TYPE_BUY and current_price >= next_liq_target - approach_threshold:
                price_reached_target = True
            elif position_type == mt5.ORDER_TYPE_SELL and current_price <= next_liq_target + approach_threshold:
                price_reached_target = True

            if price_reached_target:
                # Xác định % chốt lời (có thể cố định hoặc cấu hình theo từng target)
                # Ví dụ: Chốt 50% ở target 1, 30% ở target 2...
                close_percent = 50 # Mặc định chốt 50%
                # (Có thể thêm logic đọc % chốt lời từ mandate nếu muốn cấu hình chi tiết hơn)

                close_volume = round(initial_volume * (close_percent / 100), 2)
                # Làm tròn volume theo volume_step
                symbol_info_vol = mt5.symbol_info(symbol)
                vol_step = symbol_info_vol.volume_step if symbol_info_vol else 0.01
                if vol_step > 0: close_volume = round(close_volume / vol_step) * vol_step
                close_volume = round(max(symbol_info_vol.volume_min if symbol_info_vol else 0.01, close_volume), 2) # Đảm bảo > min_vol

                # Đảm bảo volume đóng hợp lệ
                if close_volume > 0 and position.volume >= close_volume * 0.99: # Cho phép sai số nhỏ
                    # Đảm bảo không đóng hết nếu đây không phải target cuối
                    if target_level < len(h4_liquidity_targets) and close_volume >= position.volume:
                         close_volume = round(position.volume - vol_step, 2) # Để lại vol tối thiểu
                         if close_volume < (symbol_info_vol.volume_min if symbol_info_vol else 0.01):
                              print(f"ℹ️ [MANAGER] Lệnh #{ticket}: Không thể chốt lời TP{target_level} vì volume còn lại quá nhỏ.")
                              return # Không chốt nếu không thể để lại volume tối thiểu


                    print(f"💰 [MANAGER/LIQ TP] Lệnh #{ticket} ({symbol}) tiếp cận Mục tiêu Thanh khoản #{target_level} ({next_liq_target:.{position.digits}f}). Đóng {close_percent}% ({close_volume} lots)...")

                    # --- LOGIC ĐÓNG LỆNH MỘT PHẦN ---
                    close_request = {
                        "action": mt5.TRADE_ACTION_DEAL, "symbol": symbol, "volume": close_volume,
                        "type": mt5.ORDER_TYPE_SELL if position_type == mt5.ORDER_TYPE_BUY else mt5.ORDER_TYPE_BUY,
                        "position": ticket,
                        "price": tick.bid if position_type == mt5.ORDER_TYPE_BUY else tick.ask,
                        "deviation": 20, "magic": 234002,
                        "comment": f"Partial Liq TP{target_level} for #{ticket}",
                        "type_time": mt5.ORDER_TIME_GTC, "type_filling": mt5.ORDER_FILLING_IOC,
                    }
                    # BỎ COMMENT ĐỂ CHỐT LỜI THẬT
                    close_result = await asyncio.to_thread(mt5.order_send, close_request)

                    if close_result and close_result.retcode == mt5.TRADE_RETCODE_DONE:
                        print(f"✅ [MANAGER] Chốt lời TP Thanh khoản #{target_level} thành công cho lệnh #{ticket}.")
                        new_management_status = f"PARTIAL_LIQ_{target_level}"
                        await asyncio.to_thread(db.update_trade_management_status, ticket, new_management_status)
                        if context and chat_id:
                            text = f"💰 <b>Chốt lời TP Thanh khoản #{target_level}</b> ({close_percent}%) cho <code>{symbol}</code> #{ticket}: Đã đóng {close_volume} lots."
                            await context.bot.send_message(chat_id=chat_id, text=text, parse_mode=ParseMode.HTML, disable_notification=True)
                        # Chuyển sang trailing sau khi chốt lời
                        if enable_trailing_stop:
                             await asyncio.to_thread(db.update_trade_management_status, ticket, "TRAILING_STRUCT")
                    else:
                        error_code = close_result.retcode if close_result else "N/A"; error_comment = close_result.comment if close_result else "N/A"
                        print(f"❌ Lỗi chốt lời TP Thanh khoản #{target_level} lệnh #{ticket}: Code={error_code}, Reason: {error_comment}")
                    # Không break, để logic trailing có thể chạy ngay
                # else: print(f"ℹ️ Lệnh #{ticket}: Volume đóng TP Liq {target_level} không hợp lệ.")
            # else: print(f"ℹ️ Lệnh #{ticket}: Chưa tiếp cận TP Liq {target_level} ({next_liq_target}).")


    # --- NÂNG CẤP: Dừng lỗ động theo Cấu trúc (Structure-Based Trailing Stop) ---
    # Chỉ chạy trailing nếu trạng thái cho phép (sau BE hoặc Partial)
    allowed_trailing_statuses = ["BREAKEVEN", "TRAILING_STRUCT"] + [f"PARTIAL_LIQ_{i}" for i in range(1, 10)] # Bao gồm các mức partial liq
    if enable_trailing_stop and management_status in allowed_trailing_statuses:
        trail_tf = mt5.TIMEFRAME_M15 # Khung thời gian để tìm cấu trúc trailing
        needed_bars_trail = 50 # Số nến M15 cần để phân tích cấu trúc

        # Lấy dữ liệu M15 kể từ khi mở lệnh (hoặc đủ để phân tích)
        trade_rates_trail = await get_trade_history_rates(symbol, open_time_dt, trail_tf, needed_bars=needed_bars_trail)

        if not trade_rates_trail.empty and len(trade_rates_trail) >= needed_bars_trail:
            try:
                # Chạy phân tích cấu trúc trong thread
                structure_analysis = await asyncio.to_thread(tra.analyze_trend_rhythm, trade_rates_trail.copy())
                # Lấy đỉnh/đáy xoay từ kết quả (cần sửa trend_rhythm_analyzer để trả về)
                # Giả sử hàm trả về list các swing points trong 'details': {'swing_points': [{'price': P, 'type': 'high/low', 'index': I}]}
                swing_points = structure_analysis.get('details', {}).get('swing_points', [])
                if not swing_points: swing_points = [] # Đảm bảo là list

                new_potential_sl = 0.0
                trailing_point_price = None

                if position_type == mt5.ORDER_TYPE_BUY:
                    # Tìm đáy xoay ('low') gần nhất đã hình thành (trước nến cuối)
                    confirmed_lows = [p for p in swing_points if p['type'] == 'low' and p['index'] < len(trade_rates_trail) - 2] # Trước 2 nến cuối
                    if confirmed_lows:
                        last_confirmed_low = max(confirmed_lows, key=lambda p: p['index']) # Lấy cái mới nhất
                        trailing_point_price = last_confirmed_low['price']
                        # Đặt SL dưới đáy xoay một khoảng buffer (ví dụ 5 pips)
                        symbol_info_sl = mt5.symbol_info(symbol)
                        buffer = symbol_info_sl.point * 5 if symbol_info_sl else 0.00005
                        new_potential_sl = trailing_point_price - buffer

                        # Đảm bảo SL mới > SL cũ VÀ > Giá vào lệnh
                        if new_potential_sl > current_sl and new_potential_sl > entry_price:
                            print(f"📈 [TRAIL STRUCT] Lệnh MUA #{ticket} ({symbol}): Dời SL lên {new_potential_sl:.{position.digits}f} (dưới Swing Low M15 tại {trailing_point_price:.{position.digits}f})")
                            if await modify_position_sltp(ticket, symbol, sl=new_potential_sl):
                               await asyncio.to_thread(db.update_trade_management_status, ticket, "TRAILING_STRUCT")

                elif position_type == mt5.ORDER_TYPE_SELL:
                    # Tìm đỉnh xoay ('high') gần nhất đã hình thành
                    confirmed_highs = [p for p in swing_points if p['type'] == 'high' and p['index'] < len(trade_rates_trail) - 2]
                    if confirmed_highs:
                        last_confirmed_high = max(confirmed_highs, key=lambda p: p['index'])
                        trailing_point_price = last_confirmed_high['price']
                        # Đặt SL trên đỉnh xoay một khoảng buffer
                        symbol_info_sl = mt5.symbol_info(symbol)
                        buffer = symbol_info_sl.point * 5 if symbol_info_sl else 0.00005
                        new_potential_sl = trailing_point_price + buffer

                        # Đảm bảo SL mới < SL cũ (nếu SL cũ != 0) VÀ < Giá vào lệnh
                        if (current_sl == 0.0 or new_potential_sl < current_sl) and new_potential_sl < entry_price:
                            print(f"📉 [TRAIL STRUCT] Lệnh BÁN #{ticket} ({symbol}): Dời SL xuống {new_potential_sl:.{position.digits}f} (trên Swing High M15 tại {trailing_point_price:.{position.digits}f})")
                            if await modify_position_sltp(ticket, symbol, sl=new_potential_sl):
                                await asyncio.to_thread(db.update_trade_management_status, ticket, "TRAILING_STRUCT")
            except Exception as e_struct_trail:
                 print(f"❌ [MANAGER] Lỗi khi xử lý Trailing Stop theo cấu trúc cho #{ticket}: {e_struct_trail}")
        # else: print(f"ℹ️ [MANAGER] Lệnh #{ticket}: Không đủ dữ liệu {mt5.timeframe_to_string(trail_tf)} để trailing theo cấu trúc.")

    return # Kết thúc quản lý cho lệnh này