# candlestick_analyzer.py (Phiên bản Nâng cấp Ngữ cảnh)
# -*- coding: utf-8 -*-
import pandas as pd
import pandas_ta as ta

def analyze_patterns_with_context(
    df: pd.DataFrame, 
    trend_status: str, 
    key_support: float, 
    key_resistance: float
) -> dict:
    """
    Phân tích các mẫu hình nến và đánh giá chúng trong ngữ cảnh của thị trường
    (xu hướng, hỗ trợ/kháng cự) để tạo ra tín hiệu chất lượng cao.
    """
    if len(df) < 20:
        return {}

    signals = {}
    last_candle = df.iloc[-1]
    
    # --- Phần 1: Sử dụng pandas-ta để nhận dạng TẤT CẢ các mẫu hình ---
    # `df.ta.cdl_pattern(name="all")` sẽ quét và thêm các cột cho mỗi mẫu hình
    # Giá trị dương (100) là Tăng giá, âm (-100) là Giảm giá, 0 là không có mẫu.
    df.ta.cdl_pattern(name="all", append=True)
    
    # Lấy cột kết quả của cây nến cuối cùng
    pattern_results = df.filter(like="CDL").iloc[-1] 
    
    # Lọc ra các mẫu hình đang hoạt động
    active_bullish_patterns = pattern_results[pattern_results > 0].index.tolist()
    active_bearish_patterns = pattern_results[pattern_results < 0].index.tolist()

    # --- Phần 2: Đánh giá các mẫu hình trong Ngữ cảnh ---
    
    # Kịch bản 1: Mẫu hình TĂNG giá xuất hiện trong bối cảnh HỖ TRỢ
    if active_bullish_patterns:
        close_price = last_candle['close']
        is_near_support = abs(close_price - key_support) / close_price < 0.005 # Gần hỗ trợ trong vòng 0.5%
        
        # Tín hiệu MUA mạnh nhất: Mẫu hình tăng giá xuất hiện gần vùng Hỗ trợ trong một xu hướng TĂNG
        if trend_status == "TĂNG" and is_near_support:
            signals['STRONG_BULLISH_REVERSAL'] = {
                "patterns": active_bullish_patterns,
                "reason": f"Mẫu hình tăng giá xuất hiện gần vùng Hỗ trợ {key_support} trong một xu hướng tăng."
            }
        # Tín hiệu MUA tiềm năng: Mẫu hình tăng giá xuất hiện gần vùng Hỗ trợ (có thể là đảo chiều)
        elif is_near_support:
             signals['POTENTIAL_BULLISH_REVERSAL'] = {
                "patterns": active_bullish_patterns,
                "reason": f"Mẫu hình đảo chiều tăng giá xuất hiện gần vùng Hỗ trợ quan trọng {key_support}."
            }

    # Kịch bản 2: Mẫu hình GIẢM giá xuất hiện trong bối cảnh KHÁNG CỰ
    if active_bearish_patterns:
        close_price = last_candle['close']
        is_near_resistance = abs(close_price - key_resistance) / close_price < 0.005 # Gần kháng cự trong vòng 0.5%

        # Tín hiệu BÁN mạnh nhất: Mẫu hình giảm giá xuất hiện gần vùng Kháng cự trong một xu hướng GIẢM
        if trend_status == "GIẢM" and is_near_resistance:
            signals['STRONG_BEARISH_REVERSAL'] = {
                "patterns": active_bearish_patterns,
                "reason": f"Mẫu hình giảm giá xuất hiện gần vùng Kháng cự {key_resistance} trong một xu hướng giảm."
            }
        # Tín hiệu BÁN tiềm năng: Mẫu hình giảm giá xuất hiện gần vùng Kháng cự (có thể là đảo chiều)
        elif is_near_resistance:
            signals['POTENTIAL_BEARISH_REVERSAL'] = {
                "patterns": active_bearish_patterns,
                "reason": f"Mẫu hình đảo chiều giảm giá xuất hiện gần vùng Kháng cự quan trọng {key_resistance}."
            }

    return signals