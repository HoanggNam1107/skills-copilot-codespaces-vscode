# range_analyzer.py
# -*- coding: utf-8 -*-
import pandas as pd
import MetaTrader5 as mt5
from data_handler import mt5_get_rates
import asyncio

async def analyze_htf_range(symbol: str, current_price: float, timeframe=mt5.TIMEFRAME_D1) -> dict:
    """
    Phân tích Lý thuyết Phạm vi Nến (Candle Range Theory) trên khung thời gian cao (HTF).
    Lấy cây nến HTF *đã đóng* gần nhất (ví dụ: nến Ngày hôm qua) để xác định
    các vùng Premium, Discount và Equilibrium.
    """
    
    # Lấy 2 nến HTF (nến hôm qua và nến hôm nay)
    df = await mt5_get_rates(symbol, timeframe, count=2)
    
    if df.empty or len(df) < 2:
        return {
            "status": "Không đủ dữ liệu HTF",
            "premium_level": 0,
            "discount_level": 0,
            "equilibrium": 0,
            "current_zone": "Không xác định"
        }

    # Lấy cây nến *trước đó* (nến đã đóng)
    prev_candle = df.iloc[0] 
    
    prev_high = prev_candle['high']
    prev_low = prev_candle['low']
    
    # Tính toán các mức
    equilibrium = round((prev_high + prev_low) / 2, 5)
    
    # Xác định vùng giá hiện tại
    current_zone = "Equilibrium"
    if current_price > equilibrium:
        current_zone = "Premium (Đắt)"
    elif current_price < equilibrium:
        current_zone = "Discount (Rẻ)"

    return {
        "status": f"Dựa trên phạm vi nến {timeframe} trước đó.",
        "htf_range_high": prev_high,
        "htf_range_low": prev_low,
        "equilibrium": equilibrium,
        "current_zone": current_zone
    }