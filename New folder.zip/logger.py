# logger.py (Phiên bản Nâng cấp Log Rotation)
# -*- coding: utf-8 -*-
import logging
import sys
from logging.handlers import RotatingFileHandler

def setup_logger():
    """
    Thiết lập một logger chuyên nghiệp với các tính năng:
    - Ghi ra console để theo dõi trực tiếp (chỉ từ INFO trở lên).
    - Ghi vào file với tính năng tự động xoay vòng (ghi tất cả từ DEBUG).
    """
    # Định dạng cho log message
    log_format = logging.Formatter(
        '%(asctime)s - [%(levelname)s] - (%(filename)s:%(lineno)d) - %(message)s'
    )

    # Lấy logger gốc và đặt ở cấp độ thấp nhất để bắt tất cả các loại log
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # --- Console Handler (Chỉ hiển thị thông tin quan trọng) ---
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(log_format)
    console_handler.setLevel(logging.INFO) # <-- Chỉ hiển thị từ INFO trở lên
    logger.addHandler(console_handler)

    # --- File Handler (Ghi lại mọi thứ và tự động xoay vòng) ---
    # File log sẽ tự động xoay vòng khi đạt 5MB, và giữ lại 5 file backup.
    file_handler = RotatingFileHandler(
        "trading_bot.log", 
        maxBytes=5*1024*1024, # 5 Megabytes
        backupCount=5, 
        encoding='utf-8'
    )
    file_handler.setFormatter(log_format)
    file_handler.setLevel(logging.DEBUG) # <-- Ghi lại tất cả mọi thứ vào file
    logger.addHandler(file_handler)

    logging.info("Logger chuyên nghiệp đã được thiết lập.")
    return logger

# Tạo một instance logger để các module khác có thể import và sử dụng
log = setup_logger()