# volatility_analyzer.py (Nâng cấp %B Width, Breakout & Regime)
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np

def analyze_volatility(
    price_data: pd.DataFrame,
    bb_period=20, bb_std=2.0, kc_period=20, kc_mult=1.5,
    mom_period=12, bbw_lookback=50, atr_ma_period=50, breakout_threshold=2.5
) -> dict:
    """
    Phân tích biến động: TTM Squeeze, BBW Percentile, Volatility Breakout,
    VÀ NÂNG CẤP: Phân loại Chế độ Biến động (Volatility Regime).
    """
    # --- Input Validation and Basic Calcs ---
    if price_data.empty or len(price_data) < max(kc_period + 10, bbw_lookback, atr_ma_period):
        return {
            "status": "Không đủ dữ liệu", "potential_direction": "N/A", "implication": "",
            "bbw_percentile": None, "is_volatility_breakout": False, "volatility_regime": "UNKNOWN" # Thêm regime default
        }

    df = price_data.copy()

    # --- Bollinger Bands & BBW Percentile ---
    df['sma'] = df['close'].rolling(window=bb_period).mean()
    df['std'] = df['close'].rolling(window=bb_period).std()
    df['upper_bb'] = df['sma'] + (df['std'] * bb_std)
    df['lower_bb'] = df['sma'] - (df['std'] * bb_std)
    # Normalized BB Width (Width / SMA) để so sánh giữa các cặp tiền
    df['bb_width'] = (df['upper_bb'] - df['lower_bb']) / df['sma']
    # Tính percentile rank của bb_width hiện tại so với 'bbw_lookback' nến trước đó
    df['bbw_percentile'] = df['bb_width'].rolling(window=bbw_lookback).apply(lambda x: pd.Series(x).rank(pct=True).iloc[-1] * 100, raw=False)
    last_bbw_percentile = round(df['bbw_percentile'].iloc[-1], 1) if pd.notna(df['bbw_percentile'].iloc[-1]) else None

    # --- Keltner Channels & TTM Squeeze ---
    df['ema_kc'] = df['close'].ewm(span=kc_period, adjust=False).mean()
    # Tính True Range (TR)
    df['high_low'] = df['high'] - df['low']
    df['high_close'] = np.abs(df['high'] - df['close'].shift())
    df['low_close'] = np.abs(df['low'] - df['close'].shift())
    df['tr'] = df[['high_low', 'high_close', 'low_close']].max(axis=1)
    # Tính Average True Range (ATR)
    df['atr'] = df['tr'].ewm(span=kc_period, adjust=False).mean() # Dùng cùng span với KC cho nhất quán
    df['upper_kc'] = df['ema_kc'] + (df['atr'] * kc_mult)
    df['lower_kc'] = df['ema_kc'] - (df['atr'] * kc_mult)
    # Phát hiện Tín hiệu "Squeeze"
    is_squeeze = (df['lower_bb'] > df['lower_kc']) & (df['upper_bb'] < df['upper_kc'])
    last_is_squeeze = is_squeeze.iloc[-1]

    # --- Momentum Direction ---
    x = np.arange(mom_period)
    y = df['close'].tail(mom_period).to_numpy()
    if len(y) < mom_period: # Xử lý trường hợp thiếu dữ liệu ở đầu DataFrame
         slope = 0
         direction = "NEUTRAL"
    else:
        # Tính độ dốc của đường hồi quy tuyến tính
        slope, intercept = np.polyfit(x, y, 1)
        # Chuẩn hóa độ dốc bằng cách chia cho giá trung bình để so sánh giữa các cặp tiền
        normalized_slope = slope / np.mean(y) if np.mean(y) != 0 else 0
        # Xác định hướng dựa trên độ dốc chuẩn hóa (thay vì độ dốc tuyệt đối)
        # Đặt ngưỡng nhỏ để tránh nhiễu
        if normalized_slope > 0.0001: direction = "UP"
        elif normalized_slope < -0.0001: direction = "DOWN"
        else: direction = "NEUTRAL"

    # --- Volatility Breakout ---
    is_vol_breakout = False
    vol_breakout_direction = "N/A"
    last_atr = 0.0
    last_atr_ma = 0.0
    if 'atr' in df.columns and len(df) > atr_ma_period:
        df['atr_ma'] = df['atr'].rolling(window=atr_ma_period).mean()
        last_atr = df['atr'].iloc[-1]
        last_atr_ma = df['atr_ma'].iloc[-1]
        # Thêm kiểm tra last_atr_ma > 0 để tránh chia cho 0
        if last_atr_ma > 0 and last_atr > last_atr_ma * breakout_threshold:
            is_vol_breakout = True
            last_candle = df.iloc[-1]
            # Xác định hướng bùng nổ dựa trên nến cuối
            vol_breakout_direction = "UP" if last_candle['close'] > last_candle['open'] else "DOWN" if last_candle['close'] < last_candle['open'] else "N/A"

    # --- Phân loại Volatility Regime ---
    volatility_regime = "MEDIUM" # Mặc định
    if last_bbw_percentile is not None:
        if last_bbw_percentile <= 25: # Ví dụ: Dưới hoặc bằng 25% -> LOW
            volatility_regime = "LOW"
        elif last_bbw_percentile >= 75: # Ví dụ: Trên hoặc bằng 75% -> HIGH
            volatility_regime = "HIGH"

    # --- Diễn giải Kết quả ---
    status = "Biến động Bình thường"
    implication = f"Thị trường đang trong chế độ biến động {volatility_regime}."

    if is_vol_breakout:
        status = f"BÙNG NỔ BIẾN ĐỘNG ({vol_breakout_direction})"
        atr_ratio = round(last_atr / last_atr_ma, 1) if last_atr_ma > 0 else 0
        implication = f"ATR tăng đột biến ({atr_ratio}x so với MA{atr_ma_period}), xác nhận phá vỡ mạnh theo hướng {vol_breakout_direction}. Chế độ: {volatility_regime}."
        # Tín hiệu bùng nổ thường quan trọng hơn các tín hiệu khác
    elif last_is_squeeze:
        status = "SQUEEZE (Nén Lò Xo)"
        implication = f"Thị trường đang tích lũy năng lượng (Chế độ: {volatility_regime}), chuẩn bị đột phá. Momentum: {direction}."
    elif volatility_regime == "LOW": # Chỉ kiểm tra nếu không phải Squeeze hay Breakout
        status = "NÉN CỰC ĐẠI (Max Compression)"
        implication = f"Biến động cực thấp ({last_bbw_percentile}%), rủi ro đột phá mạnh sắp xảy ra (Chế độ: LOW). Momentum: {direction}."
    elif volatility_regime == "HIGH": # Chỉ kiểm tra nếu không phải Squeeze hay Breakout
         status = "GIÃN NỞ CỰC ĐẠI (Max Expansion)"
         implication = f"Biến động cực cao ({last_bbw_percentile}%), có thể sắp có đảo chiều hoặc kiệt sức (Chế độ: HIGH)."

    # Xác định hướng tiềm năng cuối cùng
    potential_direction_final = "N/A"
    if is_vol_breakout:
        potential_direction_final = vol_breakout_direction
    elif last_is_squeeze or volatility_regime == "LOW":
        potential_direction_final = direction

    return {
        "status": status,
        "potential_direction": potential_direction_final, # Hướng tiềm năng cuối cùng
        "implication": implication,
        "bbw_percentile": last_bbw_percentile, # %B Width Percentile
        "is_volatility_breakout": is_vol_breakout, # Cờ bùng nổ ATR
        "volatility_regime": volatility_regime # Chế độ LOW/MEDIUM/HIGH
    }