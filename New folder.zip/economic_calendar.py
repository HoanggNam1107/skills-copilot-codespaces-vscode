# economic_calendar.py (Phiên bản Selenium Scraper + Tự động Set Giờ UTC)
# -*- coding: utf-8 -*-
import asyncio
from datetime import datetime, timedelta, date, time
import pandas as pd
import pytz
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options as ChromeOptions
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.ui import Select # <-- NÂNG CẤP: Cần để chọn dropdown
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import time as sleep_time # Đổi tên để tránh trùng lặp
import re
from config import SELENIUM_HEADLESS, SELENIUM_TIMEOUT
import atexit

# --- Khởi tạo WebDriver ---
_driver = None
_driver_lock = asyncio.Lock()
_ff_timezone_set = False # <-- NÂNG CẤP: Cờ để đánh dấu đã set giờ FF

async def get_webdriver():
    """Khởi tạo hoặc trả về instance WebDriver đã có (có lock)."""
    global _driver
    async with _driver_lock:
        if _driver is None:
            print("🚀 [SELENIUM] Khởi tạo WebDriver...")
            options = ChromeOptions()
            if SELENIUM_HEADLESS: options.add_argument("--headless")
            options.add_argument("--no-sandbox"); options.add_argument("--disable-dev-shm-usage")
            options.add_argument("--disable-gpu"); options.add_argument("window-size=1920x1080")
            options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/5.37.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
            options.add_experimental_option('excludeSwitches', ['enable-logging'])
            try:
                service = ChromeService(ChromeDriverManager().install())
                _driver = webdriver.Chrome(service=service, options=options)
                _driver.set_page_load_timeout(SELENIUM_TIMEOUT)
                print("✅ [SELENIUM] WebDriver đã sẵn sàng.")
            except Exception as e:
                print(f"❌ [SELENIUM] Lỗi khởi tạo WebDriver: {e}"); _driver = None
    return _driver

def close_webdriver():
    """Đóng WebDriver."""
    global _driver
    if _driver:
        print("🌙 [SELENIUM] Đóng WebDriver...")
        try: _driver.quit()
        except Exception as e: print(f"⚠️ [SELENIUM] Lỗi khi đóng WebDriver: {e}")
        _driver = None
atexit.register(close_webdriver)


# --- Hàm Cào dữ liệu Investing.com (Giữ nguyên) ---
async def scrape_investing_calendar(driver) -> list:
    """Cào lịch kinh tế từ Investing.com cho hôm nay và ngày mai."""
    if not driver: return []
    print(" scraping Investing.com...")
    events = []
    url = "https://www.investing.com/economic-calendar/"
    try:
        await asyncio.to_thread(driver.get, url)
        # Chờ bảng lịch xuất hiện
        try:
             WebDriverWait(driver, SELENIUM_TIMEOUT).until(EC.presence_of_element_located((By.ID, "economicCalendarData")))
        except Exception as e_wait:
             print(f"⏳ [INVESTING] Timeout khi chờ bảng: {e_wait}")
             if "economicCalendarData" not in await asyncio.to_thread(lambda: driver.page_source):
                  print("❌ [INVESTING] Không tìm thấy bảng dữ liệu."); return []
        
        # (Click filter thời gian/impact nếu cần)
        # ...

        table_html = await asyncio.to_thread(driver.find_element(By.ID, "economicCalendarData").get_attribute, 'outerHTML')
        soup = BeautifulSoup(table_html, 'lxml')
        rows = soup.find_all("tr", class_=re.compile(r"js-event-item"))
        
        # Xác định múi giờ của Investing (thường nó tự động theo IP hoặc cài đặt)
        # Tạm giả định là giờ VN (Asia/Ho_Chi_Minh) - Đây là điểm yếu của Investing
        local_tz = pytz.timezone("Asia/Ho_Chi_Minh") 
        current_date_obj = datetime.now(local_tz).date() # Lấy ngày hiện tại theo giờ VN

        for row in rows:
            try:
                # Xử lý dòng ngày
                date_row = row.find("td", class_="theDay")
                if date_row:
                     if "Tomorrow" in date_row.text: current_date_obj = date.today() + timedelta(days=1)
                     elif "Today" in date_row.text: current_date_obj = date.today()
                     continue 

                event_id = row.get('id', ''); if not event_id: continue
                time_str = row.find("td", class_="time").text.strip()
                currency = row.find("td", class_="flagCur").text.strip()
                impact_cell = row.find("td", class_="sentiment");
                impact_stars = len(impact_cell.find_all("i", class_="grayFullBullishIcon")) if impact_cell else 0
                event_name = row.find("td", class_="event").text.strip()
                actual = row.find("td", id=re.compile(r"eventActual_")).text.strip()
                forecast = row.find("td", id=re.compile(r"eventForecast_")).text.strip()
                previous = row.find("td", id=re.compile(r"eventPrevious_")).text.strip()

                impact = "LOW";
                if impact_stars == 2: impact = "MEDIUM"
                elif impact_stars >= 3: impact = "HIGH"

                # Chuyển đổi thời gian (Giả sử Investing đang hiển thị giờ VN)
                try:
                    time_obj = datetime.strptime(time_str, "%H:%M").time()
                    event_dt_local = local_tz.localize(datetime.combine(current_date_obj, time_obj))
                    event_dt_utc = event_dt_local.astimezone(pytz.utc)
                except ValueError: continue # Bỏ qua "All Day", "Tentative"

                events.append({"source": "Investing", "time_utc": event_dt_utc, "currency": currency, "event": event_name,
                               "impact": impact, "actual": actual if actual not in [' ', ''] else None,
                               "forecast": forecast if forecast not in [' ', ''] else None,
                               "previous": previous if previous not in [' ', ''] else None})
            except Exception as e_row: print(f"⚠️ [INVESTING] Lỗi xử lý dòng: {e_row}")
    except Exception as e: print(f"❌ [INVESTING] Lỗi cào dữ liệu: {e}")
    print(f"✅ [INVESTING] Hoàn thành, tìm thấy {len(events)} sự kiện."); return events


# --- Hàm Cào dữ liệu Forex Factory ---
async def scrape_forexfactory_calendar(driver) -> list:
    """Cào lịch kinh tế từ Forex Factory (Đã nâng cấp set múi giờ UTC)."""
    global _ff_timezone_set
    if not driver: return []
    print(" scraping Forex Factory...")
    events = []
    url = "https://www.forexfactory.com/calendar"

    try:
        await asyncio.to_thread(driver.get, url)

        # --- NÂNG CẤP: Tự động Set Múi giờ về UTC ---
        if not _ff_timezone_set:
            try:
                print("🕰️ [FF] Đang thử đặt múi giờ về UTC...")
                # 1. Click vào đồng hồ
                clock_element = WebDriverWait(driver, SELENIUM_TIMEOUT).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, "div.calendar__timezone > a.calendar__timezone-display-icon"))
                )
                await asyncio.to_thread(clock_element.click)
                
                # 2. Chờ Hộp thoại Timezone xuất hiện
                WebDriverWait(driver, SELENIUM_TIMEOUT).until(
                    EC.presence_of_element_located((By.ID, "calendarTimezoneForm"))
                )
                
                # 3. Chọn "(GMT) Coordinated Universal Time" từ dropdown
                select_element = Select(driver.find_element(By.NAME, "timezone"))
                await asyncio.to_thread(select_element.select_by_value, "0") # Giá trị "0" là UTC
                
                # 4. Click nút "Save Settings"
                save_button = driver.find_element(By.CSS_SELECTOR, "form#calendarTimezoneForm input[type='submit']")
                await asyncio.to_thread(save_button.click)
                
                # 5. Chờ trang tải lại
                WebDriverWait(driver, SELENIUM_TIMEOUT).until(
                     EC.staleness_of(save_button) # Chờ cho đến khi nút "Save" biến mất
                )
                _ff_timezone_set = True
                print("✅ [FF] Đã đặt múi giờ thành công về UTC (GMT+0).")
                await asyncio.sleep(2) # Chờ 2s để trang ổn định
            except Exception as e_tz:
                print(f"⚠️ [FF] Lỗi khi tự động đặt múi giờ: {e_tz}. Sẽ tiếp tục với múi giờ hiện tại (có thể sai).")
        # --- Kết thúc nâng cấp Timezone ---

        # Chờ bảng lịch xuất hiện
        try:
             WebDriverWait(driver, SELENIUM_TIMEOUT).until(EC.presence_of_element_located((By.CLASS_NAME, "calendar__table")))
        except Exception as e_wait:
             print(f"⏳ [FF] Timeout khi chờ bảng dữ liệu: {e_wait}"); return []

        table_html = await asyncio.to_thread(driver.find_element(By.CLASS_NAME, "calendar__table").get_attribute, 'outerHTML')
        soup = BeautifulSoup(table_html, 'lxml')
        rows = soup.find_all("tr", class_=re.compile(r"calendar__row"))

        current_event_date = date.today() # Bắt đầu với hôm nay (UTC)

        for row in rows:
            try:
                # Xử lý dòng ngày
                date_cell = row.find("td", class_="calendar__date")
                if date_cell and "calendar__date" in ' '.join(date_cell.get('class', [])):
                     # Cập nhật ngày
                     date_str = date_cell.text.strip()
                     # (Logic parse ngày phức tạp, tạm giả định nó tuần tự)
                     # Ví dụ: Nếu thấy "Tomorrow", set ngày là +1
                     if "Tomorrow" in date_str: current_event_date = date.today() + timedelta(days=1)
                     elif "Today" in date_str: current_event_date = date.today()
                     continue # Bỏ qua dòng ngày

                time_cell = row.find("td", class_="calendar__time"); currency_cell = row.find("td", class_="calendar__currency")
                impact_cell = row.find("td", class_="calendar__impact"); event_cell = row.find("td", class_="calendar__event")
                actual_cell = row.find("td", class_="calendar__actual"); forecast_cell = row.find("td", class_="calendar__forecast"); previous_cell = row.find("td", class_="calendar__previous")

                if not all([time_cell, currency_cell, impact_cell, event_cell, actual_cell, forecast_cell, previous_cell]): continue
                time_str = time_cell.text.strip(); currency = currency_cell.text.strip()
                impact_title = impact_cell.find("span", class_="icon--ff-impact")['title'] if impact_cell.find("span", class_="icon--ff-impact") else ''
                event_name = event_cell.text.strip(); actual = actual_cell.text.strip(); forecast = forecast_cell.text.strip(); previous = previous_cell.text.strip()
                if not time_str or time_str.lower() == "all day" or not currency: continue

                impact = "LOW";
                if "Medium Impact Expected" in impact_title: impact = "MEDIUM"
                elif "High Impact Expected" in impact_title: impact = "HIGH"

                try: # Vì đã set UTC, giờ là giờ UTC
                    time_obj = datetime.strptime(time_str.replace(" ",""), "%I:%M%p").time() # Parse am/pm
                    event_dt_utc = pytz.utc.localize(datetime.combine(current_event_date, time_obj)) # Giờ đã là UTC
                except ValueError:
                     try: # Thử format 24h (nếu có)
                          time_obj = datetime.strptime(time_str, "%H:%M").time()
                          event_dt_utc = pytz.utc.localize(datetime.combine(current_event_date, time_obj))
                     except ValueError: continue

                events.append({"source": "ForexFactory", "time_utc": event_dt_utc, "currency": currency, "event": event_name,
                               "impact": impact, "actual": actual if actual not in [' ', ''] else None,
                               "forecast": forecast if forecast not in [' ', ''] else None,
                               "previous": previous if previous not in [' ', ''] else None})
            except Exception as e_row: print(f"⚠️ [FF] Lỗi xử lý dòng: {e_row}")
    except Exception as e: print(f"❌ [FF] Lỗi cào dữ liệu: {e}")
    print(f"✅ [FF] Hoàn thành, tìm thấy {len(events)} sự kiện."); return events


# --- Hàm Kết hợp và Lọc Trùng ---
async def get_combined_calendar_data(driver) -> pd.DataFrame:
    """Lấy dữ liệu từ cả hai nguồn và kết hợp, lọc trùng."""
    if not driver: return pd.DataFrame()
    print("🔄 [CALENDAR] Bắt đầu lấy dữ liệu từ các nguồn...")
    # Chạy tuần tự để tránh lỗi driver
    investing_events = await scrape_investing_calendar(driver)
    await asyncio.sleep(2) # Nghỉ ngắn
    ff_events = await scrape_forexfactory_calendar(driver)

    all_events = investing_events + ff_events
    if not all_events: print("⚠️ [CALENDAR] Không lấy được sự kiện nào."); return pd.DataFrame()

    df = pd.DataFrame(all_events)
    df.sort_values(by="time_utc", inplace=True)

    # Logic Lọc Trùng
    df['time_rounded'] = df['time_utc'].dt.round('15min') # Làm tròn 15 phút
    df['event_lower'] = df['event'].str.lower().str.strip().str.replace(r'[^a-z0-9]', '', regex=True) # Chuẩn hóa tên
    df['unique_key'] = df['time_rounded'].astype(str) + '_' + df['currency'] + '_' + df['event_lower']
    df['priority'] = df['source'].apply(lambda x: 1 if x == 'ForexFactory' else 2) # Ưu tiên FF
    df.sort_values(by=['unique_key', 'priority'], inplace=True)
    df_deduplicated = df.drop_duplicates(subset=['unique_key'], keep='first')

    print(f"✅ [CALENDAR] Kết hợp và lọc trùng: {len(all_events)} -> {len(df_deduplicated)} sự kiện.")
    # Trả về các cột chuẩn hóa (bao gồm cả 'previous')
    return df_deduplicated[['time_utc', 'currency', 'event', 'impact', 'actual', 'forecast', 'previous']]


# --- Hàm Lấy Tất cả Sự kiện trong Ngày ---
async def get_all_day_events(day: str = "today") -> list:
    """Lấy *tất cả* các sự kiện (HIGH, MEDIUM) trong ngày (today/tomorrow)."""
    driver = await get_webdriver()
    if not driver: return []
    # Đảm bảo driver đang khóa trước khi dùng
    async with _driver_lock:
         combined_df = await get_combined_calendar_data(driver) # Chạy có lock
    if combined_df.empty: return []

    target_date = datetime.now(pytz.utc).date() # Lấy ngày UTC
    if day == "tomorrow": target_date = target_date + timedelta(days=1)

    daily_df = combined_df[
        (combined_df['time_utc'].dt.date == target_date) &
        (combined_df['impact'].isin(["HIGH", "MEDIUM"]))
    ].copy()

    events_list = []
    for _, row in daily_df.iterrows():
        events_list.append({
            "time": row['time_utc'].to_pydatetime().strftime("%H:%M UTC"),
            "currency": row['currency'],
            "event": row['event'],
            "impact": row['impact']
        })
    print(f"✅ [CALENDAR] Đã lấy {len(events_list)} sự kiện HIGH/MEDIUM cho {day} (UTC).")
    return events_list


# --- Hàm Lấy Sự Kiện Sắp Tới (Dùng cho No-Fly Zone) ---
async def get_upcoming_events(rules_config: dict) -> list:
    """Lấy các sự kiện sắp diễn ra từ dữ liệu cào và lọc theo quy tắc."""
    driver = await get_webdriver()
    if not driver: return []
    # Đảm bảo driver đang khóa trước khi dùng
    async with _driver_lock:
         combined_df = await get_combined_calendar_data(driver) # Chạy có lock
    if combined_df.empty: return []

    lookahead_minutes = rules_config.get("pause_trading_before_event_minutes", 30)
    rules = sorted(rules_config.get("rules", []), key=lambda x: x.get('priority', 99))

    now_utc = datetime.now(pytz.utc)
    lookahead_time_utc = now_utc + timedelta(minutes=lookahead_minutes)

    flagged_events = []
    upcoming_df = combined_df[
        (combined_df['time_utc'] >= now_utc) &
        (combined_df['time_utc'] <= lookahead_time_utc)
    ].copy()

    def event_matches(event_row: pd.Series, rule: dict) -> bool:
        if "currency" in rule and rule["currency"] != "ANY" and event_row['currency'] != rule["currency"]:
             if rule["currency"] == "EUR" and event_row['currency'] != "EUR": return False
             elif rule["currency"] != "EUR" and event_row['currency'] != rule["currency"]: return False
        if "impact" in rule and rule["impact"] != "ANY" and event_row['impact'] != rule["impact"]: return False
        if "event_keyword" in rule:
            event_name = event_row['event'].lower()
            if not any(keyword.lower() in event_name for keyword in rule["event_keyword"]): return False
        return True

    processed_indices = set()
    for rule in rules:
        action = rule.get("action", "IGNORE")
        if action == "IGNORE": continue
        matching_events = upcoming_df[
            (~upcoming_df.index.isin(processed_indices)) &
            (upcoming_df.apply(lambda row: event_matches(row, rule), axis=1))
        ]
        if not matching_events.empty:
            impact_rule = rule.get("impact", "ANY")
            for index, event_row in matching_events.iterrows():
                impact_final = event_row['impact']
                if impact_rule in ["HIGH", "MEDIUM", "LOW"]: impact_final = impact_rule
                flagged_events.append({
                    "time": event_row['time_utc'].to_pydatetime(), # datetime object
                    "currency": event_row['currency'],
                    "event": event_row['event'],
                    "impact": impact_final, "action": action
                })
                processed_indices.add(index)
    flagged_events.sort(key=lambda x: x['time'])
    return flagged_events


# --- Hàm Lấy Kết Quả Sự Kiện ---
async def get_event_result(event_to_find: dict) -> dict:
    """Cố gắng tìm kết quả (actual) cho một sự kiện đã diễn ra bằng cách cào lại."""
    driver = await get_webdriver()
    if not driver: return None
    print(f"🔄 [CALENDAR RESULT] Đang thử cào lại tìm kết quả cho: {event_to_find['event']} ({event_to_find['currency']})")
    # Đảm bảo driver đang khóa
    async with _driver_lock:
         combined_df = await get_combined_calendar_data(driver) # Chạy có lock
    if combined_df.empty: return None

    target_time_utc = event_to_find['time'].astimezone(pytz.utc)
    target_currency = event_to_find['currency']
    target_event_name = event_to_find['event'].lower().strip()

    time_tolerance = timedelta(minutes=5)
    lower_bound = target_time_utc - time_tolerance
    upper_bound = target_time_utc + time_tolerance
    potential_matches = combined_df[
        (combined_df['time_utc'] >= lower_bound) &
        (combined_df['time_utc'] <= upper_bound) &
        (combined_df['currency'] == target_currency)
    ].copy()

    if potential_matches.empty:
        print(f"ℹ️ [CALENDAR RESULT] Không tìm thấy sự kiện khớp thời gian/tiền tệ."); return None

    potential_matches['event_lower'] = potential_matches['event'].str.lower().str.strip()
    exact_match = potential_matches[potential_matches['event_lower'] == target_event_name]

    found_event = None
    if not exact_match.empty:
        found_event = exact_match.iloc[0]; print("✅ [CALENDAR RESULT] Tìm thấy khớp chính xác.")
    else:
        target_event_regex = re.escape(target_event_name).replace(r'\\ ', r'[\s\W_]+')
        partial_matches = potential_matches[potential_matches['event_lower'].str.contains(target_event_regex, na=False, regex=True)]
        if not partial_matches.empty:
            partial_matches['time_diff'] = (partial_matches['time_utc'] - target_time_utc).abs()
            found_event = partial_matches.loc[partial_matches['time_diff'].idxmin()]
            print(f"⚠️ [CALENDAR RESULT] Tìm thấy khớp tương đối: '{found_event['event']}'.")
        else: print(f"ℹ️ [CALENDAR RESULT] Không tìm thấy sự kiện khớp tên."); return None

    if found_event is not None:
        def parse_numeric(value):
            if value is None or value == "": return None
            try: return float(str(value).replace('%','').replace('K','e3').replace('M','e6').replace('B','e9').replace(',','').strip())
            except (ValueError, TypeError): return value
        return {
            "time": int(found_event['time_utc'].timestamp()),
            "country": found_event['currency'], # Trả về key 'country'
            "event": found_event['event'],
            "impact": found_event['impact'],
            "actual": parse_numeric(found_event['actual']),
            "forecast": parse_numeric(found_event['forecast']),
            "prev": parse_numeric(found_event['previous']) # Trả về key 'prev'
        }
    return None