# database.py (Phiên bản Nâng cấp Performance Analytics)
# -*- coding: utf-8 -*-
import sqlite3
from config import DATABASE_FILE
import json
from datetime import datetime

def db_initialize():
    """Khởi tạo cơ sở dữ liệu và các bảng cần thiết."""
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS trade_journal (
        ticket_id INTEGER PRIMARY KEY, 
        symbol TEXT, 
        open_time TIMESTAMP, 
        close_time TIMESTAMP,
        order_type TEXT, 
        initial_volume REAL, 
        open_price REAL, 
        close_price REAL, 
        profit REAL,
        status TEXT, -- 'open' hoặc 'closed'
        management_status TEXT, -- 'PENDING', 'BREAKEVEN', 'PARTIAL_TP1', 'TRAILING'
        initial_sl REAL,
        entry_analysis_json TEXT,
        commission REAL, -- <-- SỬA ĐỔI: Thêm cột commission
        swap REAL -- <-- SỬA ĐỔI: Thêm cột swap
    );
    """)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS equity_history (
        timestamp TIMESTAMP PRIMARY KEY, balance REAL, equity REAL
    );
    """)
    
    # <-- SỬA ĐỔI: Thêm bảng theo dõi trạng thái đồng bộ hóa mà journaler.py cần
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sync_status (
        id INTEGER PRIMARY KEY DEFAULT 1,
        last_sync_time TIMESTAMP
    );
    """)
    # <-- SỬA ĐỔI: Khởi tạo giá trị ban đầu cho sync_status để tránh lỗi
    cursor.execute("""
    INSERT OR IGNORE INTO sync_status (id, last_sync_time) 
    VALUES (1, ?);
    """, (datetime.now() - timedelta(days=7),)) # Mặc định quét lại 7 ngày trước
    
    conn.commit()
    conn.close()
    print("🗃️ Cơ sở dữ liệu đã được khởi tạo (đã bao gồm sync_status).")

def log_new_trade(ticket_id: int, symbol: str, open_time: datetime, order_type: str, volume: float, open_price: float, initial_sl: float, entry_analysis_json: str):
    """Ghi lại thông tin ban đầu của một giao dịch, bao gồm cả SL ban đầu."""
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()
    try:
        cursor.execute(
            """INSERT OR REPLACE INTO trade_journal 
               (ticket_id, symbol, open_time, order_type, initial_volume, open_price, status, management_status, initial_sl, entry_analysis_json)
               VALUES (?, ?, ?, ?, ?, ?, 'open', 'PENDING', ?, ?)""",
            (ticket_id, symbol, open_time, order_type, volume, open_price, initial_sl, entry_analysis_json)
        )
        conn.commit()
        print(f"📖 [DB] Đã ghi nhận lệnh MỞ #{ticket_id} cho {symbol} với SL ban đầu là {initial_sl}.")
    finally:
        conn.close()

# <-- SỬA ĐỔI: Thêm hàm log_closed_trade() bị thiếu -->
def log_closed_trade(ticket_id: int, close_time: datetime, close_price: float, profit: float, commission: float, swap: float):
    """Cập nhật một giao dịch đã đóng."""
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()
    try:
        cursor.execute(
            """UPDATE trade_journal 
               SET status = 'closed', close_time = ?, close_price = ?, profit = ?, commission = ?, swap = ?
               WHERE ticket_id = ? AND status = 'open'""",
            (close_time, close_price, profit, commission, swap, ticket_id)
        )
        conn.commit()
        if cursor.rowcount > 0:
            print(f"💰 [DB] Đã ghi nhận lệnh ĐÓNG #{ticket_id}. Lợi nhuận: {profit}")
    finally:
        conn.close()
# <-- KẾT THÚC SỬA ĐỔI -->

def update_trade_management_status(ticket_id: int, new_status: str):
    """Cập nhật trạng thái quản lý của một lệnh (ví dụ: đã dời về hòa vốn)."""
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE trade_journal SET management_status = ? WHERE ticket_id = ?",
            (new_status, ticket_id)
        )
        conn.commit()
        print(f"🛡️ [DB] Đã cập nhật trạng thái quản lý cho lệnh #{ticket_id} thành {new_status}.")
    finally:
        conn.close()

def get_trade_management_status(ticket_id: int) -> str:
    """Lấy trạng thái quản lý hiện tại của một lệnh."""
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT management_status FROM trade_journal WHERE ticket_id = ?", (ticket_id,))
        result = cursor.fetchone()
        return result[0] if result else "NOT_FOUND"
    finally:
        conn.close()

def get_trade_by_ticket(ticket_id: int) -> dict:
    """Lấy tất cả thông tin của một giao dịch từ DB bằng ticket_id."""
    conn = sqlite3.connect(DATABASE_FILE)
    conn.row_factory = sqlite3.Row # Giúp trả về kết quả dạng dictionary
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM trade_journal WHERE ticket_id = ?", (ticket_id,))
        result = cursor.fetchone()
        return dict(result) if result else None
    finally:
        conn.close()

def get_recent_trades(symbol: str, limit: int = 3) -> list:
    # Hàm này có thể được phát triển thêm để lấy các giao dịch đã đóng gần đây
    return []

def get_all_closed_trades() -> list:
    """Lấy tất cả các giao dịch đã đóng từ journal để phân tích hiệu suất."""
    conn = sqlite3.connect(DATABASE_FILE)
    conn.row_factory = sqlite3.Row # Giúp trả về kết quả dạng dictionary
    cursor = conn.cursor()
    try:
        # Lấy các giao dịch có trạng thái là 'closed' và đã có lợi nhuận được ghi nhận
        cursor.execute("SELECT * FROM trade_journal WHERE status = 'closed' AND profit IS NOT NULL ORDER BY close_time ASC")
        results = cursor.fetchall()
        return [dict(row) for row in results]
    finally:
        conn.close()