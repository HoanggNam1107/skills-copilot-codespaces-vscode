# mtf_analyzer.py (Phiên bản Nâng cấp Alignment D1/H4 - EMA Phụ trợ)
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import MetaTrader5 as mt5
from data_handler import mt5_get_rates
import trend_rhythm_analyzer as tra # Import rhythm analyzer
import asyncio

# --- Hàm phân tích xu hướng và cấu trúc trên 1 khung thời gian (Giữ nguyên) ---
async def analyze_single_tf(symbol: str, timeframe, price_data: pd.DataFrame, ema_fast=21, ema_slow=50, atr_period=14) -> dict:
    # ... (Giữ nguyên code của hàm này) ...
    if price_data.empty or len(price_data) < max(ema_slow, 50):
        return {
            "timeframe": mt5.timeframe_to_string(timeframe), "trend_dir": "NEUTRAL", "trend_score": 0,
            "vol_percentile": 50, "structure": "UNKNOWN", "last_event": "UNKNOWN",
            "error": "Không đủ dữ liệu"
        }
    df = price_data.copy()
    vol_percentile = 50; last_atr = 1e-9
    try: # Tính Volatility
        df['tr'] = pd.DataFrame([ df['high'] - df['low'], abs(df['high'] - df['close'].shift()), abs(df['low'] - df['close'].shift()) ]).max(axis=0)
        df['atr'] = df['tr'].ewm(span=atr_period, adjust=False).mean()
        last_atr = df['atr'].iloc[-1];
        if last_atr == 0: last_atr = 1e-9
        df['atr_pct_rank'] = df['atr'].rolling(window=ema_slow).rank(pct=True) * 100
        vol_percentile = df['atr_pct_rank'].iloc[-1] if pd.notna(df['atr_pct_rank'].iloc[-1]) else 50
    except Exception as e_vol: print(f"⚠️ Lỗi Vol {mt5.timeframe_to_string(timeframe)}: {e_vol}")
    trend_dir = "NEUTRAL"; trend_score = 0
    try: # Tính EMA
        df['ema_fast'] = df['close'].ewm(span=ema_fast, adjust=False).mean()
        df['ema_slow'] = df['close'].ewm(span=ema_slow, adjust=False).mean()
        last_close = df['close'].iloc[-1]; ema_f = df['ema_fast'].iloc[-1]; ema_s = df['ema_slow'].iloc[-1]
        if last_close > ema_f > ema_s: trend_dir = "UP"
        elif last_close < ema_f < ema_s: trend_dir = "DOWN"
        trend_score = round(np.clip(((ema_f - ema_s) / last_atr) * 5, -10, 10), 1)
    except Exception as e_ema: print(f"⚠️ Lỗi EMA {mt5.timeframe_to_string(timeframe)}: {e_ema}")
    structure_analysis = {"structure": "UNKNOWN", "last_event": "UNKNOWN"}
    try: # Tính Rhythm
        structure_analysis = await asyncio.to_thread(tra.analyze_trend_rhythm, df.copy())
    except Exception as e_rhythm: print(f"⚠️ Lỗi Rhythm {mt5.timeframe_to_string(timeframe)}: {e_rhythm}")
    return {
        "timeframe": mt5.timeframe_to_string(timeframe), "trend_dir": trend_dir,
        "trend_score": trend_score, "vol_percentile": round(vol_percentile, 1),
        "structure": structure_analysis.get('structure', 'UNKNOWN'),
        "last_event": structure_analysis.get('last_event', 'UNKNOWN'), "error": None
    }
# --- Kết thúc hàm analyze_single_tf ---


async def analyze_mtf(symbol: str, h4_data: pd.DataFrame) -> dict:
    """
    Phân tích Đa Khung Thời gian D1/H4, ƯU TIÊN sự ĐỒNG THUẬN CẤU TRÚC.
    EMA chỉ đóng vai trò phụ trợ.
    """
    print(f"--- [MTF ALIGNMENT D1/H4 - Structure Focused] Phân tích Đồng thuận cho {symbol} ---")

    tf_map = {"D1": mt5.TIMEFRAME_D1, "H4": mt5.TIMEFRAME_H4}
    required_bars = {"D1": 150, "H4": 250}

    # Lấy dữ liệu D1
    d1_data = pd.DataFrame()
    try: d1_data = await mt5_get_rates(symbol, tf_map["D1"], required_bars["D1"])
    except Exception as e_d1_data: print(f"❌ Lỗi lấy data D1 {symbol}: {e_d1_data}")
    price_data = {"H4": h4_data, "D1": d1_data}

    # Chạy phân tích D1, H4 song song
    tasks_analyze = []
    for tf_str, tf_mt5 in tf_map.items():
         if tf_str in price_data and not price_data[tf_str].empty:
             tasks_analyze.append(analyze_single_tf(symbol, tf_mt5, price_data[tf_str]))
         else:
              tasks_analyze.append(asyncio.sleep(0, result={"timeframe": tf_str, "error": "Missing Data"}))
    tf_analyses_list = await asyncio.gather(*tasks_analyze)
    tf_analyses = {res.get('timeframe', f'UNKNOWN_{i}'): res for i, res in enumerate(tf_analyses_list) if isinstance(res, dict)}


    # Đánh giá sự Đồng thuận (Ưu tiên Cấu trúc)
    d1 = tf_analyses.get("D1", {})
    h4 = tf_analyses.get("H4", {})

    # 1. Đồng thuận Cấu trúc (Market Structure - D1/H4) - Yếu tố chính
    struct_alignment = "Phân kỳ (Mixed)"
    d1_struct = d1.get("structure", "UNKNOWN")
    h4_struct = h4.get("structure", "UNKNOWN")
    if "Tăng" in d1_struct and "Tăng" in h4_struct:
        struct_alignment = "Đồng thuận TĂNG (Bullish Structure)"
    elif "Giảm" in d1_struct and "Giảm" in h4_struct:
        struct_alignment = "Đồng thuận GIẢM (Bearish Structure)"
    # Thêm trường hợp D1 đi ngang, H4 có xu hướng
    elif "Đi ngang" in d1_struct and "Tăng" in h4_struct:
         struct_alignment = "D1 Ngang / H4 Tăng"
    elif "Đi ngang" in d1_struct and "Giảm" in h4_struct:
         struct_alignment = "D1 Ngang / H4 Giảm"

    # 2. Đồng thuận Hướng (EMA Direction D1/H4) - Yếu tố phụ
    dir_alignment = "Phân kỳ (Mixed)"
    if d1.get("trend_dir") == "UP" and h4.get("trend_dir") == "UP":
        dir_alignment = "EMA Đồng thuận TĂNG (UP)"
    elif d1.get("trend_dir") == "DOWN" and h4.get("trend_dir") == "DOWN":
        dir_alignment = "EMA Đồng thuận GIẢM (DOWN)"

    # 3. Tính Điểm Xu hướng Tổng hợp (D1/H4) - Giảm trọng số EMA
    weights = {'D1': 0.6, 'H4': 0.4}
    total_trend_score = (d1.get('trend_score', 0) * weights['D1'] +
                         h4.get('trend_score', 0) * weights['H4'])

    # 4. Diễn giải Kết quả Cuối cùng (Ưu tiên Cấu trúc)
    implication = "Tín hiệu MTF D1/H4 không rõ ràng hoặc phân kỳ cấu trúc."
    final_bias = "NEUTRAL"

    # Ưu tiên số 1: Đồng thuận cấu trúc
    if struct_alignment == "Đồng thuận TĂNG (Bullish Structure)":
        implication = "ĐỒNG THUẬN TĂNG D1/H4 (Cấu trúc): Ưu tiên lệnh MUA."
        final_bias = "STRONG_BUY"
        # Kiểm tra thêm EMA phụ trợ
        if dir_alignment != "EMA Đồng thuận TĂNG (UP)":
             implication += " (Lưu ý: EMA chưa hoàn toàn đồng thuận)."
             final_bias = "BUY" # Giảm mức độ mạnh nếu EMA chưa thuận
    elif struct_alignment == "Đồng thuận GIẢM (Bearish Structure)":
        implication = "ĐỒNG THUẬN GIẢM D1/H4 (Cấu trúc): Ưu tiên lệnh BÁN."
        final_bias = "STRONG_SELL"
        if dir_alignment != "EMA Đồng thuận GIẢM (DOWN)":
             implication += " (Lưu ý: EMA chưa hoàn toàn đồng thuận)."
             final_bias = "SELL" # Giảm mức độ mạnh

    # Trường hợp D1 Ngang, H4 có xu hướng cấu trúc
    elif struct_alignment == "D1 Ngang / H4 Tăng":
         implication = "THIÊN VỀ MUA (D1 Ngang / H4 Tăng): Cấu trúc H4 tăng, D1 tích lũy. Tìm cơ hội Mua theo H4."
         final_bias = "BUY"
         if dir_alignment == "EMA Đồng thuận GIẢM (DOWN)": final_bias = "NEUTRAL" # Nếu EMA giảm mạnh -> trung lập
    elif struct_alignment == "D1 Ngang / H4 Giảm":
         implication = "THIÊN VỀ BÁN (D1 Ngang / H4 Giảm): Cấu trúc H4 giảm, D1 phân phối. Tìm cơ hội Bán theo H4."
         final_bias = "SELL"
         if dir_alignment == "EMA Đồng thuận TĂNG (UP)": final_bias = "NEUTRAL" # Nếu EMA tăng mạnh -> trung lập

    # Trường hợp cấu trúc phân kỳ hoàn toàn -> NEUTRAL
    elif struct_alignment == "Phân kỳ (Mixed)":
         implication = "PHÂN KỲ CẤU TRÚC D1/H4: Tín hiệu không rõ ràng, nên đứng ngoài hoặc giảm rủi ro."
         final_bias = "NEUTRAL"


    return {
        "final_bias": final_bias,
        "implication": implication,
        "indicator_alignment": dir_alignment, # Vẫn trả về để tham khảo
        "structure_alignment": struct_alignment, # Yếu tố chính
        "total_trend_score": round(total_trend_score, 2), # Chỉ để tham khảo
        "details": {
            "D1": d1,
            "H4": h4,
        }
    }