# volume_profile_analyzer.py (Phiên bản Nâng cấp Delta & HVN/LVN)
# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import MetaTrader5 as mt5
try:
    from scipy.signal import find_peaks
except ImportError:
    print("Cảnh báo: scipy chưa được cài đặt. pip install scipy")
    def find_peaks(series, **kwargs):
        return np.array([]), {}

def _calculate_profile(df_period: pd.DataFrame, num_bins: int) -> dict:
    """
    Hàm nội bộ để tính toán profile chi tiết, bao gồm cả Delta.
    """
    if df_period.empty: return {}
    min_price, max_price = df_period['last'].min(), df_period['last'].max()
    if min_price == max_price: return {}
    
    bins = np.linspace(min_price, max_price, num_bins)
    df_period['price_bin'] = np.digitize(df_period['last'], bins)
    
    # --- NÂNG CẤP: Tính toán Delta ---
    # 1. Phân loại volume Mua/Bán dựa trên cờ (flags)
    df_period['buy_volume'] = df_period.apply(lambda r: r['volume'] if (r['flags'] & mt5.TICK_FLAG_BUY) else 0, axis=1)
    df_period['sell_volume'] = df_period.apply(lambda r: r['volume'] if (r['flags'] & mt5.TICK_FLAG_SELL) else 0, axis=1)

    # 2. Nhóm theo từng mức giá (bin)
    grouped = df_period.groupby('price_bin')
    volume_groups = grouped['volume'].sum()
    buy_volume_groups = grouped['buy_volume'].sum()
    sell_volume_groups = grouped['sell_volume'].sum()
    
    # Tạo DataFrame Profile
    profile_df = pd.DataFrame({
        'price': bins[volume_groups.index - 1],
        'total_volume': volume_groups,
        'buy_volume': buy_volume_groups,
        'sell_volume': sell_volume_groups,
        'delta': buy_volume_groups - sell_volume_groups
    }).dropna()

    if profile_df.empty: return {}

    # 3. Tìm POC (Point of Control)
    poc_row = profile_df.loc[profile_df['total_volume'].idxmax()]
    poc_price = poc_row['price']
    poc_delta = poc_row['delta']

    # 4. Tìm Vùng Giá trị (Value Area - 70% Volume)
    total_volume = profile_df['total_volume'].sum()
    target_volume = total_volume * 0.7
    
    poc_index = profile_df['total_volume'].idxmax()
    current_volume = profile_df.loc[poc_index, 'total_volume']
    vah_index, val_index = poc_index, poc_index

    while current_volume < target_volume and (val_index > profile_df.index.min() or vah_index < profile_df.index.max()):
        vol_up = profile_df.get(vah_index + 1, {}).get('total_volume', 0)
        vol_down = profile_df.get(val_index - 1, {}).get('total_volume', 0)
        
        if vol_up > vol_down:
            current_volume += vol_up
            vah_index += 1
        else:
            current_volume += vol_down
            val_index -= 1
            
    vah_price = profile_df.get(vah_index, poc_row)['price']
    val_price = profile_df.get(val_index, poc_row)['price']

    # --- NÂNG CẤP: Tìm HVN (High Volume Nodes) và LVN (Low Volume Nodes) ---
    # Sử dụng find_peaks trên dữ liệu volume
    avg_volume = profile_df['total_volume'].mean()
    peaks_idx, _ = find_peaks(profile_df['total_volume'], prominence=avg_volume)
    valleys_idx, _ = find_peaks(-profile_df['total_volume'], prominence=avg_volume)

    hvns = sorted(profile_df.iloc[peaks_idx]['price'].tolist(), reverse=True)
    lvns = sorted(profile_df.iloc[valleys_idx]['price'].tolist(), reverse=True)

    return {
        "poc": poc_price, "vah": vah_price, "val": val_price,
        "poc_delta": poc_delta,
        "total_delta": profile_df['delta'].sum(),
        "hvns": hvns,
        "lvns": lvns
    }

def analyze_volume_profile(tick_data: pd.DataFrame, num_bins=50) -> dict:
    """
    Phân tích dữ liệu tick để xây dựng và phân tích hình thái, động lực của Volume Profile,
    BAO GỒM CẢ DELTA và các Nút Khối lượng (HVN/LVN).
    """
    if tick_data.empty or 'flags' not in tick_data.columns or len(tick_data) < 200:
        return {"error": "Không đủ dữ liệu tick hoặc thiếu cột 'flags' để phân tích Delta."}

    # Chia dữ liệu thành 2 nửa: quá khứ và hiện tại
    midpoint = len(tick_data) // 2
    prev_period_df = tick_data.iloc[:midpoint].copy()
    curr_period_df = tick_data.iloc[midpoint:].copy()

    # Tính toán profile cho cả 2 giai đoạn
    prev_profile = _calculate_profile(prev_period_df, num_bins)
    curr_profile = _calculate_profile(curr_period_df, num_bins)

    if not prev_profile or not curr_profile:
        return _calculate_profile(tick_data.copy(), num_bins) # Fallback về phân tích tĩnh

    # --- Phân tích Hình thái (Profile Shape) - (Giữ nguyên logic cũ) ---
    profile_shape = "Chưa xác định"
    value_area_range = curr_profile['vah'] - curr_profile['val']
    if value_area_range > 0:
        poc_position_in_va = (curr_profile['poc'] - curr_profile['val']) / value_area_range
        if 0.40 <= poc_position_in_va <= 0.60: profile_shape = "D-shape (Cân bằng)"
        elif poc_position_in_va < 0.40: profile_shape = "P-shape (Mất cân bằng Tăng)"
        else: profile_shape = "b-shape (Mất cân bằng Giảm)"

    # --- Phân tích Động lực (Dynamics) - (Kết hợp Delta) ---
    poc_migration = "Đi ngang"
    if curr_profile['poc'] > prev_profile['poc'] * 1.0005: poc_migration = "Đi lên"
    elif curr_profile['poc'] < prev_profile['poc'] * 0.9995: poc_migration = "Đi xuống"

    va_shift = "Không đổi"
    if curr_profile['val'] > prev_profile['val'] and curr_profile['vah'] > prev_profile['vah']: va_shift = "Dịch chuyển lên"
    elif curr_profile['val'] < prev_profile['val'] and curr_profile['vah'] < prev_profile['vah']: va_shift = "Dịch chuyển xuống"

    # --- NÂNG CẤP: Diễn giải Delta ---
    delta_implication = "Delta cân bằng."
    poc_delta = curr_profile['poc_delta']
    total_delta = curr_profile['total_delta']
    
    if poc_delta > 0 and total_delta > 0:
        delta_implication = "Phe Mua chủ động (Aggressive Buyers) đang kiểm soát."
    elif poc_delta < 0 and total_delta < 0:
        delta_implication = "Phe Bán chủ động (Aggressive Sellers) đang kiểm soát."
    elif poc_delta > 0 and total_delta < 0:
        delta_implication = "Hấp thụ Bán (Sell Absorption) - Phe Bán đang yếu đi."
    elif poc_delta < 0 and total_delta > 0:
        delta_implication = "Hấp thụ Mua (Buy Absorption) - Phe Mua đang yếu đi."

    dynamics_implication = (
        f"POC đang {poc_migration}, Vùng Giá trị đang {va_shift}. "
        f"{delta_implication}"
    )
    
    # Kết hợp kết quả
    analysis = curr_profile
    analysis['profile_shape'] = profile_shape
    analysis['dynamics_implication'] = dynamics_implication
    
    # Làm tròn HVN/LVN để dễ đọc
    analysis['hvns'] = [round(p, 5) for p in analysis.get('hvns', [])]
    analysis['lvns'] = [round(p, 5) for p in analysis.get('lvns', [])]
    
    return analysis